class DI_WIFI:  # self.RIO represents a switch, if it is 1, then PLC processes wireless signal.
    def __init__(self):
        self.PLC = 0
        self.RIO1 = 0
        self.RIO2 = 0
        self.RIO3 = 0
        self.RIO4 = 0
        self.RIO5 = 0
        self.RIO6 = 0


class IO_AIN_FIT:  # AIN_FBD and FIT_FBD both use this I/O
    def __init__(self):
        self.W_AI_Value = 0  # sensor return value (wireless or not)
        self.AI_Value = 0
        self.W_AI_Hty = 1    # whether sensor return value is in the defined low and high bounds (wireless or not)
        self.AI_Hty = 1


class IO_MV:
    def __init__(self):
        self.DI_ZSO = 0   # (plant) signal to plc
        self.DI_ZSC = 1
        self.DO_Open = 0  # signal from plc
        self.DO_Close = 0


class IO_PMP_UV:  # PMP_FBD and UV_FBD both use this I/O
    def __init__(self):
        self.DI_Auto = 1   # (plant) signal to plc
        self.DI_Run = 0
        self.DI_Fault = 0
        self.DO_Start = 0  # signal from plc


class IO_SWITCH:
    def __init__(self):
        self.DI_LS = 0


class VSD:
    def __init__(self):
        self.DI_Auto = 1
        self.DI_Run = 0
        self.DI_VSD_PB = 0


class VSD_In:
    def __init__(self):
        self.Faulted = 0
        self.Active = 0
        self.Ready = 0
        self.OutputFreq = 0


class VSD_Out:
    def __init__(self):
        self.ClearFaults = 0
        self.Start = 0
        self.Stop = 0
        self.FreqCommand = 0
