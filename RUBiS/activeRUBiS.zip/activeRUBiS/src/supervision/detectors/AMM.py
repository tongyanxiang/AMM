import random
import numpy as np

from sklearn.linear_model import LinearRegression
from scipy import stats
from cvxopt import matrix, solvers

np.set_printoptions(suppress=True, precision=10, threshold=2000, linewidth=150)
solvers.options['maxiters'] = 20
solvers.options['show_progress'] = False


def degradation_detector(delta):
    # alarm if derived probability of occurring delta value of
    # the managed system's output does not exceed the probability threshold

    # degradation parameters
    loc = 0.0
    scale = 0.1823
    prob_6sigma = 0.999999981  # 6sigma

    if delta <= loc:
        cdf = stats.norm.cdf(delta, loc, scale)
    else:
        cdf = 1.0 - stats.norm.cdf(delta, loc, scale)

    alarm = 0
    if cdf < (1.0 - prob_6sigma) / 2.0:
        alarm = 1

    return alarm


class AMM:
    # Active Monitoring Mechanism

    def __init__(self, logging, auxiliary_signal_trigger_mode, auxiliary_signal_design_mode):
        self.logging = logging
        self.counting = 0

        # "combine_trigger"/"prior_trigger"/"posterior_trigger"/"timing_trigger"
        self.auxiliary_signal_trigger_mode = auxiliary_signal_trigger_mode

        # "optimal_design"/"random_design"
        self.auxiliary_signal_design_mode = auxiliary_signal_design_mode

        # ****************************** knowledge section ******************************
        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        # subject to: x(k) = [x'(k); I], u(k-1) = [u'(k-1); 0]
        #             A = [A', 0; 0, I], B = [B', 0; 0, 0], C = [C', beta]
        # -->
        # x'(k) = A'*x'(k-1) + B'*u'(k-1)
        # y(k) = C'*x'(k) + beta
        # subject to: x'(k) = [x''(k); x''(k-1)], u'(k-1) = [u''(k-1); 0]
        #             A' = [0, 0; A'', 0], B' = [B''; 0], C' = [0, C'']
        self.A_prime = np.array([[0.0, 0.0],
                                 [1.0, 0.0]])

        self.B_prime = np.array([[-0.1042],
                                 [0.0]])

        self.C_prime = np.array([[0.0, 1.0]])

        # deviated model parameter
        self.B_k_prior = np.copy(self.B_prime)  # using copy to avoid change together
        self.P_k_prior = np.array([[1.0e-06, 0.0],
                                   [0.0, 0.0]])
        self.B_k_posterior = np.copy(self.B_prime)
        self.P_k_posterior = np.copy(self.P_k_prior)
        self.B_k_predict = np.copy(self.B_prime)
        self.P_k_predict = np.copy(self.P_k_prior)

        # system state
        self.delta_state_prior = np.zeros((2, 1))
        self.delta_state_var_prior = np.zeros((2, 2))
        self.delta_state_posterior = np.zeros((2, 1))
        self.delta_state_var_posterior = np.zeros((2, 2))

        # uncertainty of model parameter value
        # process noise
        self.Q_prime = np.array([[1.0e-06, 0.0],
                                 [0.0, 0.0]])

        # uncertainty compensation terms
        # delta_x(k) = A*delta_x(k-1) + B*delta_u(k-1) + gamma*delta_a(k) + w(k)
        # delta_y(k) = C*delta_x(k) + v(k)
        # subject to: delta_x(k) = [delta_x'(k); 0], delta_u(k-1) = [delta_u'(k-1); 0], delta_a(k) = [delta_a'(k); 0]
        #             A = [A', 0; 0, I], B = [B', 0; 0, 0], gamma = [gamma', alpha; 0, 0], C = [C', beta]
        #             w(k) = [w'(k); 0]
        # -->
        # delta_x'(k) = A'*delta_x'(k-1) + B'*delta_u'(k-1) + gamma'*delta_a'(k)  + w'(k)
        # delta_y(k) = C'*delta_x'(k) + v(k)
        # subject to: x'(k) = [x''(k); x''(k-1)], u'(k-1) = [u''(k-1); 0], a'(k) = [0; a''(k)],
        #             A' = [0, 0; A'', 0], B' = [B''; 0], gamma' = [0; gamma''], C' = [0, C'']
        #             w'(k) = [0; w''(k)]

        # environment model
        self.gamma_prime = np.array([[0.0],
                                     [0.003]])
        self.W_prime = np.array([[0.0, 0.0],
                                 [0.0, 0.0006]])

        # sensor noise
        self.V = np.array([[2.0e-06]])

        # ****************************** passive decision section ******************************
        # safe region
        self.pole = 0.9
        self.safe_region = [1.0 / (4.0 * (1 - self.pole)) * self.B_prime[0][0], 0.0]  # [2.5B, 0.0]

        # probability threshold
        self.prob_threshold = 0.9973  # 3sigma

        # alarm signal
        self.alarm = 0

        # historical measurements
        self.list_u = []  # historical controller output
        self.list_a = []  # historical environmental input
        self.list_y = []  # historical managed system output

        # ****************************** auxiliary signal trigger section ******************************
        # active flag
        self.active_flag = 0

        # 1) auxiliary_signal_trigger_mode = "combine_trigger"/"prior_trigger"/"posterior_trigger"
        self.prediction_sw = 2

        # use for model prediction
        self.list_B0_k_posterior = [self.B_k_posterior[0][0]]
        self.list_P0_k_posterior = [self.P_k_posterior[0][0]]
        self.list_B0_k_predict = [self.B_k_posterior[0][0]]
        self.list_P0_k_predict = [self.P_k_posterior[0][0]]

        self.prediction_B0_model = [1.00459]
        self.prediction_P0_model = [1.45378]

        self.active_trigger_threshold = 0.9973  # 3sigma

        # 2) auxiliary_signal_trigger_mode = "timing_trigger"
        self.supervision_time_interval = 60
        self.timing_interval = 900
        self.timer = 0

        # ****************************** auxiliary signal design section ******************************
        # 1) auxiliary_signal_design_mode = "optimal_design"
        # constraints
        self.safety_n_sigma = 3
        self.U_constraint = [1, 10]
        self.Y_constraint = [0.0, 0.75]

        # safety auxiliary signal constraints
        self.safety_AS = [-9, 9]

        # action function parameters of the auxiliary signal
        self.T = 1.0
        self.r_C = 1.5

        # safety function parameters of auxiliary signal: 2.0/(Y_low + Y_high)
        self.r_S = 2.0 / (0.0 + 0.75)

        # accuracy enhancement function parameters of auxiliary signal
        self.r_D = 1.0 / abs(self.B_prime[0][0])

        # optimal auxiliary control signal
        self.opt_AS = 0

        # 2) auxiliary_signal_design_mode = "random_design"
        self.rnd_seed = 1

    def deviation_detector(self, u_1, a, y):

        self.counting = self.counting + 1

        if len(self.list_u) < 4:
            self.list_u.append(u_1)
            self.list_a.append(a)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_a.append(a)
            self.list_y.append(y)

            if self.logging:
                print("******************** deviation_detector k=" + str(self.counting) + " ********************")

            # state estimation
            # input: time series observation
            #  [0]     [1]     [2]     [3]     [4]
            # u(k-5), u(k-4), u(k-3), u(k-2), u(k-1)
            # a(k-4), a(k-3), a(k-2), a(k-1), a(k)
            # y(k-4), y(k-3), y(k-2), y(k-1), y(k)
            delta_y_3 = self.list_y[1] - self.list_y[0]
            delta_u_3 = self.list_u[2] - self.list_u[1]
            delta_a_2 = self.list_a[2] - self.list_a[1]

            # output: delta_state_prior, delta_state_var_prior
            self.delta_state_posterior, \
            self.delta_state_var_posterior, \
            self.delta_state_prior, \
            self.delta_state_var_prior = self.observer(self.B_k_posterior,
                                                       self.delta_state_prior,
                                                       self.delta_state_var_prior,
                                                       delta_y_3, delta_u_3, delta_a_2)

            # model parameter estimation and deviation detection
            delta_u_2 = self.list_u[3] - self.list_u[2]

            # input: time series observation
            delta_a_1 = self.list_a[3] - self.list_a[2]
            delta_a_0 = self.list_a[4] - self.list_a[3]
            delta_y_0 = self.list_y[4] - self.list_y[3]

            # output: B_k_posterior, P_k_posterior
            self.B_k_prior, \
            self.P_k_prior, \
            self.B_k_posterior, \
            self.P_k_posterior = self.estimator(self.delta_state_prior,
                                                self.delta_state_var_prior,
                                                self.B_k_prior,
                                                self.P_k_prior,
                                                self.B_k_posterior,
                                                self.P_k_posterior,
                                                delta_u_2, delta_a_1, delta_a_0, delta_y_0)

            if abs(delta_u_2) > 0:
                # passive decision
                passive_alarm = self.deviation_alarmer(self.B_k_posterior, self.P_k_posterior)
                self.alarm = passive_alarm

                # reset auxiliary signal trigger and design
                self.active_flag = 0
                self.opt_AS = 0

                if self.logging:
                    print("\n********** passive decision **********")
                    print("delta_u_2: {}".format(delta_u_2))
                    print("delta_y_0: {}".format(delta_y_0))
                    print("B0_k_prior: {}".format(self.B_k_prior[0][0]))
                    print("P0_k_prior: {}".format(self.P_k_prior[0][0]))
                    print("B0_k_posterior: {}".format(self.B_k_posterior[0][0]))
                    print("P0_k_posterior: {}".format(self.P_k_posterior[0][0]))
                    print("alarm:{}\n".format(self.alarm))

                # store historical model parameters
                self.list_B0_k_posterior.append(self.B_k_posterior[0][0])
                self.list_P0_k_posterior.append(self.P_k_posterior[0][0])
                self.list_B0_k_predict.append(self.B_k_posterior[0][0])
                self.list_P0_k_predict.append(self.P_k_posterior[0][0])

                # remove first point
                if len(self.list_B0_k_posterior) > 2.0 * (self.prediction_sw - 1):
                    del (self.list_B0_k_posterior[0])
                    del (self.list_P0_k_posterior[0])

                if len(self.list_B0_k_predict) > 2.0 * (self.prediction_sw - 1):
                    del (self.list_B0_k_predict[0])
                    del (self.list_P0_k_predict[0])

            else:
                # when no alarm, continue active part
                if self.alarm == 0:
                    # auxiliary signal trigger
                    if self.auxiliary_signal_trigger_mode != "timing_trigger":

                        if self.logging:
                            print("\n********** optimal_trigger **********")

                        if len(self.list_B0_k_posterior) >= 2.0 * (self.prediction_sw - 1):
                            self.update_prediction_model()

                            if self.logging:
                                print("update_prediction_model...")
                                print("list_B0_k_predict:{}".format(self.list_B0_k_predict))
                                print("list_P0_k_predict:{}".format(self.list_P0_k_predict))
                                print("prediction_B0_model:{}".format(self.prediction_B0_model))
                                print("prediction_P0_model:{}\n".format(self.prediction_P0_model))

                        self.active_flag = self.activate_optimal_trigger(self.auxiliary_signal_trigger_mode,
                                                                         self.B_k_prior[0][0],
                                                                         self.P_k_prior[0][0],
                                                                         self.prediction_B0_model,
                                                                         self.prediction_P0_model)

                        if self.logging:
                            print("activate_combine_trigger...")
                            print("delta_u_2:{}".format(delta_u_2))
                            print("delta_y_0:{}".format(delta_y_0))
                            print("B0_k_prior:{}".format(self.B_k_prior[0][0]))
                            print("P0_k_prior:{}".format(self.P_k_prior[0][0]))
                            print("B0_k_predict:{}".format(self.B_k_predict[0][0]))
                            print("P0_k_predict:{}".format(self.P_k_predict[0][0]))
                            print("active_flag:{}\n".format(self.active_flag))

                    elif self.auxiliary_signal_trigger_mode == "timing_trigger":
                        self.active_flag = self.activate_timing_trigger()

                        if self.logging:
                            print("\n********** timing_trigger **********")
                            print("active_flag:{}\n".format(self.active_flag))

                    # auxiliary signal design
                    if self.active_flag == 1:
                        # safety auxiliary signal
                        self.safety_AS = self.calculate_safety_AS(u_1, y, self.B_k_prior[0][0], self.P_k_prior[0][0])

                        # optimal auxiliary signal
                        if self.auxiliary_signal_design_mode == "optimal_design":
                            self.opt_AS = self.calculate_optimal_AS(self.B_k_posterior[0][0])

                            if self.logging:
                                print("\n********** optimal_design **********")
                                print("safety_AS:{}".format(self.safety_AS))
                                print("opt_AS:{}\n".format(self.opt_AS))

                        elif self.auxiliary_signal_design_mode == "random_design":
                            self.opt_AS = self.calculate_random_AS()

                            if self.logging:
                                print("\n********** random_design **********")
                                print("safety_AS:{}".format(self.safety_AS))
                                print("opt_AS:{}\n".format(self.opt_AS))

            # degradation detector
            if abs(delta_u_2) == 0:
                setpoint = 0.3
                delta = self.list_y[4] - setpoint
                self.alarm = degradation_detector(delta)

                if self.logging:
                    print("\n********** degradation decision **********")
                    print("delta: {}".format(delta))
                    print("alarm:{}\n".format(self.alarm))

            # update historical measurements
            self.list_u.remove(self.list_u[0])
            self.list_a.remove(self.list_a[0])
            self.list_y.remove(self.list_y[0])

        return self.B_k_prior[0][0], self.P_k_prior[0][0], self.B_k_posterior[0][0], self.P_k_posterior[0][0], \
               self.B_k_predict[0][0], self.P_k_predict[0][0], self.alarm, self.active_flag, self.opt_AS

    def observer(self, B_k_posterior, delta_state_prior, delta_state_var_prior, delta_y_3, delta_u_3, delta_a_2):
        # refined nominal model
        # delta_y(k-3) = C'*delta_x'(k-3) + v(k-3)
        # delta_x'(k-2) = A'*delta_x'(k-3) + B'*delta_u'(k-3) + gamma'*delta_a'(k-2) + w'(k-2)

        # update process
        # observation model which maps the true state space into the observed space
        H = self.C_prime

        # measurement pre-fit residual
        R_k = delta_y_3 - np.dot(H, delta_state_prior)

        # pre-fit residual variance
        S_k = np.dot(np.dot(H, delta_state_var_prior), H.T) + self.V

        # updated Kalman gain
        K = np.dot(np.dot(delta_state_var_prior, H.T), np.linalg.inv(S_k))

        # updated (a posteriori) state estimate
        delta_state_posterior = delta_state_prior + np.dot(K, R_k)

        # updated (a posteriori) state estimate variance
        delta_state_var_posterior = np.dot((np.eye(len(delta_state_var_prior)) - np.dot(K, H)), delta_state_var_prior)

        # prediction process
        # predicted (a priori) state estimate
        delta_state_prior = np.dot(self.A_prime, delta_state_posterior) + np.dot(B_k_posterior, delta_u_3) + \
                            np.dot(self.gamma_prime, delta_a_2)

        # predicted (a priori) state estimate variance
        delta_state_var_prior = np.dot(np.dot(self.A_prime, delta_state_var_posterior), self.A_prime.T) + self.W_prime

        return delta_state_posterior, delta_state_var_posterior, delta_state_prior, delta_state_var_prior

    def estimator(self, delta_state_prior, delta_state_var_prior, B_k_prior, P_k_prior, B_k_posterior, P_k_posterior,
                  delta_u_2, delta_a_1, delta_a_0, delta_y_0):
        # refined nominal model
        # B'(k) = B'(k-1) + q(k)
        # delta_y(k) = C'*A'*A'*delta_x'(k-2) + C'*A'*B'*delta_u'(k-2) + C'*A'*gamma'*delta_a'(k-1) +
        #              C'*gamma'*delta_a'(k) + C'*A'*w'(k) + C'*w'(k) + v(k)

        # prediction process
        if abs(delta_u_2) > 0.0:
            # predicted (a priori) model parameter estimate
            B_k_prior[0][0] = B_k_posterior[0][0]

            # predicted (a priori) model parameter estimate variance
            P_k_prior[0][0] = P_k_posterior[0][0] + self.Q_prime[0][0]

        else:
            # keep last B_prior
            B_k_prior[0][0] = B_k_prior[0][0]

            # enlarge P_k_prior as time goes on
            P_k_prior[0][0] = P_k_prior[0][0] + self.Q_prime[0][0]

        # print("delta_u_2={}".format(delta_u_2))
        # print("B0_k_posterior={}".format(B_k_posterior[0][0]))
        # print("P0_k_posterior={}".format(P_k_posterior[0][0]))
        # print("B0_k_prior={}".format(B_k_prior[0][0]))
        # print("P0_k_prior={}".format(P_k_prior[0][0]))

        # update process
        # observation model which maps the true model parameter space into the observed space
        H = np.dot(np.dot(self.C_prime, self.A_prime), delta_u_2)
        # print("H: {}".format(H))

        # measurement pre-fit residual
        S1 = np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.A_prime), delta_state_prior)
        # print("S1: {}".format(S1))

        S2 = np.dot(H, B_k_prior)
        # print("S2: {}".format(S2))

        S3 = np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.gamma_prime), delta_a_1)
        # print("S3: {}".format(S3))

        S4 = np.dot(np.dot(self.C_prime, self.gamma_prime), delta_a_0)
        # print("S4: {}".format(S4))

        # print("delta_y_0: {}".format(delta_y_0))
        error = delta_y_0 - (S1 + S2 + S3 + S4)
        # print("error={}".format(error))

        Matrix = np.dot(self.C_prime, np.dot(self.A_prime, self.A_prime))
        S_k = np.dot(np.dot(Matrix, delta_state_var_prior), Matrix.T) + \
              np.dot(np.dot(H, P_k_prior), H.T) + \
              np.dot(np.dot(np.dot(self.C_prime, self.A_prime), self.W_prime), np.dot(self.C_prime, self.A_prime).T) + \
              np.dot(np.dot(self.C_prime, self.W_prime), self.C_prime.T) + self.V

        # updated Kalman gain
        K = np.dot(np.dot(P_k_prior, H.T), np.linalg.inv(S_k))
        # print("k={}".format(K[0][0]))

        # updated (a posteriori) model parameter estimate variance
        if abs(delta_u_2) > 0.0:
            # updated (a posteriori) model parameter estimate
            B_k_posterior[0][0] = B_k_prior[0][0] + K[0][0] * error[0][0]

            # updated (a posteriori) model parameter estimate variance
            P_k_posterior[0][0] = (1.0 - np.dot(K, H)[0][0]) * P_k_prior[0][0]

        else:
            # keep the last model parameter estimate and its variance
            B_k_posterior[0][0] = B_k_posterior[0][0]
            P_k_posterior[0][0] = P_k_posterior[0][0]

        return B_k_prior, P_k_prior, B_k_posterior, P_k_posterior

    def deviation_alarmer(self, B_k_posterior, P_k_posterior):
        # alarm if the derived probability that model parameter value
        # falls into safe region does not exceed the probability threshold

        loc = B_k_posterior[0][0]
        scale = np.sqrt(P_k_posterior[0][0])
        self.cdf = stats.norm.cdf(self.safe_region[1], loc, scale) - stats.norm.cdf(self.safe_region[0], loc, scale)

        alarm = 0
        if self.cdf < self.prob_threshold:
            alarm = 1

        return alarm

    def update_prediction_model(self):

        list_B0_k_posterior = self.list_B0_k_posterior
        list_P0_k_posterior = self.list_P0_k_posterior
        sliding_window = self.prediction_sw

        X1 = []
        X2 = []
        Y1 = []
        Y2 = []
        data_slot_num = int(len(list_B0_k_posterior) / sliding_window)
        for n in range(0, data_slot_num):
            X1.append([])
            X2.append([])

            for i in range(0, self.prediction_sw - 1):
                B_k = list_B0_k_posterior[sliding_window * n + i]
                P_k = list_P0_k_posterior[sliding_window * n + i]
                X1[n].append(B_k)
                X2[n].append(P_k)

            B_k = list_B0_k_posterior[sliding_window * n + sliding_window - 1]
            P_k = list_P0_k_posterior[sliding_window * n + sliding_window - 1]
            Y1.append(B_k)
            Y2.append(P_k)

        # print("X1: {}".format(X1))
        # print("Y1: {}".format(Y1))
        # print("X2: {}".format(X2))
        # print("Y2: {}".format(Y2))

        model_B_k = LinearRegression(fit_intercept=False)
        model_B_k.fit(X1, Y1)

        list_a_i = []
        for i in range(0, sliding_window - 1):
            a_i = round(model_B_k.coef_[0], 5)
            list_a_i.append(a_i)
            # print("a_{}: {}".format(i + 1, a_i))

        model_P_k = LinearRegression(fit_intercept=False)
        model_P_k.fit(X2, Y2)

        list_b_i = []
        for i in range(0, sliding_window - 1):
            b_i = round(model_P_k.coef_[0], 5)
            list_b_i.append(b_i)
            # print("b_{}: {}".format(i + 1, b_i))

        self.prediction_B0_model = list_a_i
        self.prediction_P0_model = list_b_i

        # filter
        threshold_a = 0.01
        threshold_b = 0.01
        if list_a_i[0] > (1.0 + threshold_a):
            list_a_i[0] = 1.0 + threshold_a

        elif list_a_i[0] < (1.0 - threshold_a):
            list_a_i[0] = 1.0 - threshold_a

        if list_b_i[0] > (1.0 + threshold_b):
            list_b_i[0] = 1.0 + threshold_b

        elif list_b_i[0] < (1.0 - threshold_b):
            list_b_i[0] = 1.0 - threshold_b

        # print("update_prediction_model...")
        # print("prediction_B0_model:{}".format(self.prediction_B0_model))
        # print("prediction_P0_model:{}\n".format(self.prediction_P0_model))

    def activate_optimal_trigger(self, trigger_mode, B0_k_prior, P0_k_prior, prediction_B0_model, prediction_P0_model):

        prior_active_flag = 0
        if trigger_mode == "prior_trigger" or trigger_mode == "combine_trigger":
            # calculate the probability of model parameter value falls into safe region
            loc = B0_k_prior
            scale = np.sqrt(P0_k_prior)
            prior_trigger_indicator = stats.norm.cdf(self.safe_region[1], loc, scale) - \
                                      stats.norm.cdf(self.safe_region[0], loc, scale)

            if prior_trigger_indicator < self.active_trigger_threshold:
                prior_active_flag = 1

        predict_active_flag = 0
        if trigger_mode == "posterior_trigger" or trigger_mode == "combine_trigger":
            if len(self.list_B0_k_predict) > 0 and len(self.list_P0_k_predict) > 0:
                # print("list_B0_k_predict: {}".format(self.list_B0_k_posterior))
                # print("list_P0_k_predict: {}".format(self.list_P0_k_posterior))
                B0_k_predict = 0.0
                end = len(self.list_B0_k_predict) - 1
                for i in range(0, len(prediction_B0_model)):
                    B0_k_predict = B0_k_predict + prediction_B0_model[i] * self.list_B0_k_predict[end - i]

                P0_k_predict = 0.0
                for i in range(0, len(prediction_P0_model)):
                    P0_k_predict = P0_k_predict + prediction_P0_model[i] * self.list_P0_k_predict[end - i]

                # update predicted B, P and add to list
                self.B_k_predict[0][0] = B0_k_predict
                self.P_k_predict[0][0] = P0_k_predict
                self.list_B0_k_predict.append(B0_k_predict)
                self.list_P0_k_predict.append(P0_k_predict)

                if len(self.list_B0_k_predict) > 2.0 * (self.prediction_sw - 1):
                    del (self.list_B0_k_predict[0])
                    del (self.list_P0_k_predict[0])

                # calculate the probability of model parameter value falls into safe region
                loc = B0_k_predict
                scale = np.sqrt(P0_k_predict)
                predict_trigger_indicator = stats.norm.cdf(self.safe_region[1], loc, scale) - \
                                            stats.norm.cdf(self.safe_region[0], loc, scale)

                if predict_trigger_indicator < self.active_trigger_threshold:
                    predict_active_flag = 1

        active_flag = 0
        if trigger_mode == "prior_trigger":
            active_flag = prior_active_flag
        elif trigger_mode == "posterior_trigger":
            active_flag = predict_active_flag
        elif trigger_mode == "combine_trigger":
            active_flag = prior_active_flag or predict_active_flag

        return active_flag

    def activate_timing_trigger(self):
        # update timer
        self.timer = self.timer + self.supervision_time_interval
        # print("timer: {}".format(self.timer[i]))

        active_flag = 0
        if self.timer >= self.timing_interval:
            active_flag = 1

            # reset timer
            self.timer = 0.0

        return active_flag

    def calculate_safety_AS(self, u_1, y, B0_k_prior, P0_k_prior):
        # y(k) = C*B_k*u(k) + C*w(k) + v(k)
        # -->
        # u_as_1 = (Y_constraint[0] - y + v(k) + C*w(k))/(C*B_k)
        # u_as_2 = (Y_constraint[1] - y - v(k) - C*w(k))/(C*B_k)

        # model parameter
        C = self.C_prime[0][1]
        # print("C: {}".format(C))

        # max deviation model parameter
        if B0_k_prior > 0:
            max_B_k = B0_k_prior + self.safety_n_sigma * np.sqrt(P0_k_prior)
        else:
            max_B_k = B0_k_prior - self.safety_n_sigma * np.sqrt(P0_k_prior)
        # print("max_B_k: {}".format(max_B_k))

        # possible max measurement error
        max_uncertainty = self.safety_n_sigma * np.sqrt(self.V[0][0]) + \
                          C * self.safety_n_sigma * np.sqrt(self.W_prime[1][1])
        # print("max_uncertainty: {}".format(max_uncertainty))

        # compute safety auxiliary signal
        # if exceed Y_constraint
        if y < self.Y_constraint[0]:
            y = self.Y_constraint[0]
        elif y > self.Y_constraint[1]:
            y = self.Y_constraint[1]

        # consider max_B_k>0 or max_B_k<=0
        Y_constraint_low = -10.0 # respTime > 0
        if max_B_k > 0:
            u_as_1 = (Y_constraint_low - y + max_uncertainty) / (C * max_B_k)
            u_as_2 = (self.Y_constraint[1] - y - max_uncertainty) / (C * max_B_k)
        else:
            u_as_1 = (self.Y_constraint[1] - y - max_uncertainty) / (C * max_B_k)
            u_as_2 = (Y_constraint_low - y + max_uncertainty) / (C * max_B_k)
        # print("u_as_1: {}".format(u_as_1))
        # print("u_as_2: {}".format(u_as_2))

        AS_constraint_low = self.U_constraint[0] - u_1
        AS_constraint_upper = self.U_constraint[1] - u_1
        # print("AS_constraint_low {}".format(AS_constraint_low))
        # print("AS_constraint_upper: {}".format(AS_constraint_upper))

        u_safety_low = max(np.ceil(u_as_1), AS_constraint_low)
        u_safety_high = min(np.floor(u_as_2), AS_constraint_upper)
        safety_AS = [u_safety_low, u_safety_high]
        # print("safety_AS: {}".format(safety_AS))

        return safety_AS

    def calculate_optimal_AS(self, B0_k_posterior):
        # multi-objective optimization:
        # 1) minimize operational cost of auxiliary signal
        #          f_C = T*r_C*u'(k)^2
        # 2) maximize system safety under auxiliary signal
        #          f_U = r_S*(0.5*(y_u+y_L)-y'(k+1))^2
        # 3) maximize expected detection improvement
        #          f_D = r_D*y'(k+1)^2
        # subject to: 1) u'(k) ∈ [safety_AS_min, safety_AS_max]
        #             2) y'(k+1) = C*B(k+1)*u'(k)
        # ->
        # max(u') f = f_D + f_U - f_C
        #           = r_D*y'(k+1)^2 + r_S*y'(k+1)^2 - r_S*(y_u+y_L)*y'(k+1) + 0.25*r_S*(y_u+y_L)^2 - T*r_C*u'(k)^2
        #           = (r_D*C^2*B(k+1)^2 + r_S*C^2*B(k+1)^2 - T*r_C)*u'(k)^2 - r_S*(y_u+y_L)*C*B(k+1)*u'(k+1) + 0.25*r_S*(y_u+y_L)^2
        # subject to: u'(k) ∈ [safety_AS_min, safety_AS_max]
        #
        # convert to the standard form of a QP following CVXOPT
        # min(u') 0.5*(-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + 2.0*T*r_C)*u'(k)^2 + r_S*(y_u+y_L)*C*B(k+1)*u'(k+1)
        # subject to: -u'(k) <= safety_AS_min
        #              u'(k) <= safety_AS_max

        # function parameters
        T = self.T
        r_C = self.r_C
        r_S = self.r_S
        r_D = self.r_D

        # model parameters
        C = self.C_prime[0][1]

        # safety auxiliary signal
        safety_AS_min = self.safety_AS[0]
        safety_AS_max = self.safety_AS[1]
        # print("safety_AS: [{}, {}]".format(safety_AS_min, safety_AS_max))

        # optimization matrices
        # x = [u'(k)]
        # P = [-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + T*r_C]
        P_0_0 = -2.0 * r_D * pow(C, 2) * pow(B0_k_posterior, 2) \
                - 2.0 * r_S * pow(C, 2) * pow(B0_k_posterior, 2) + T * r_C

        P = matrix(np.array([P_0_0]), tc='d')
        # print("P_0_0: {}".format(P_0_0))

        # x = [u'(k)]
        # q = [r_S*(y_u+y_L)*C*B(k+1)]
        y_L = self.Y_constraint[0]
        y_U = self.Y_constraint[1]
        q_0_0 = r_S * (y_U + y_L) * C * B0_k_posterior

        q = matrix(np.array([q_0_0]), tc='d')
        # print("q_0_0: {}".format(q_0_0))

        # inequality matrix
        if abs(safety_AS_min) > 0 and abs(safety_AS_max) > 0:
            # Tips: elements of h to be close to 1.0
            # x = [u'(k)]
            # G = [-1.0/safety_AS_min; 1.0/safety_AS_max], h = [1.0; 1.0]
            G = matrix(np.array([[-1.0/safety_AS_min], [1.0/safety_AS_max]]), tc='d')
            h = matrix(np.array([[1.0], [1.0]]), tc='d')
        else:
            # x = [u'(k)]
            # G = [-1.0; 1.0], h = [safety_AS_min; safety_AS_max]
            G = matrix(np.array([[-1.0], [1.0]]), tc='d')
            h = matrix(np.array([[safety_AS_min], [safety_AS_max]]), tc='d')

        try:
            # cvxopt solver
            # minimize (1/2)*x*P*x + q*x
            # subject to: G*x < h
            sol = solvers.qp(P, q, G, h)

        except Exception as err:
            # print("Exception: {}".format(err))

            # discrete control parameter
            opt_AS = 0
            # print("opt_AS: {}\n".format(opt_AS))

        else:
            # extract optimal value and solution
            status = sol['status']
            opt_AS = sol['x'][0]
            # costFunction = sol['primal objective']
            # print("status: {}".format(status))
            # print("opt_AS: {}".format(opt_AS))
            # print("costFunction: {}\n".format(i, costFunction))

            # discrete control parameter
            if status == "optimal":
                opt_AS = min(max(int(np.ceil(opt_AS)), int(safety_AS_min)), int(safety_AS_max))
            else:
                opt_AS = 0
            # print("opt_AS: {}".format(opt_AS))

        # handling opt_AS = 0 with active_flag = 1
        if self.active_flag > 0 and opt_AS == 0:
            # reset auxiliary signal trigger
            self.active_flag = 0

            # reset B_k_prior and P_k_prior
            self.B_k_prior[0][0] = self.B_k_posterior[0][0]
            self.P_k_prior[0][0] = self.P_k_posterior[0][0]

            # reset B_k_predict and P_k_predict
            self.B_k_predict[0][0] = self.B_k_posterior[0][0]
            self.P_k_predict[0][0] = self.P_k_posterior[0][0]

        return opt_AS

    def calculate_random_AS(self):
        # random select auxiliary signal within its safety range

        # safety auxiliary signal
        safety_AS_min = self.safety_AS[0]
        safety_AS_max = self.safety_AS[1]

        # random select auxiliary signal
        random_AS = random.uniform(safety_AS_min, safety_AS_max)

        # discrete control parameter
        random_AS = int(np.ceil(random_AS))

        # handling random_AS = 0 with active_flag = 1
        if self.active_flag > 0 and random_AS == 0:
            # reset auxiliary signal trigger
            self.active_flag = 0

            # reset B_k_prior and P_k_prior
            self.B_k_prior[0][0] = self.B_k_posterior[0][0]
            self.P_k_prior[0][0] = self.P_k_posterior[0][0]

            # reset B_k_predict and P_k_predict
            self.B_k_predict[0][0] = self.B_k_posterior[0][0]
            self.P_k_predict[0][0] = self.P_k_posterior[0][0]

        return random_AS

    def get_B_k_prior(self):
        return self.B_k_prior[0][0]

    def get_P_k_prior(self):
        return self.P_k_prior[0][0]

    def get_B_k_posterior(self):
        return self.B_k_posterior[0][0]

    def get_P_k_posterior(self):
        return self.P_k_posterior[0][0]

    def get_B_k_predict(self):
        return self.B_k_predict[0][0]

    def get_P_k_predict(self):
        return self.P_k_predict[0][0]

    def get_active_flag(self):
        return self.active_flag

    def get_opt_AS(self):
        return self.opt_AS

    def set_timing_interval(self, timing_interval):
        self.timing_interval = timing_interval

    def set_rnd_seed(self, rnd_seed):
        self.rnd_seed = rnd_seed
        random.seed(self.rnd_seed)


if __name__ == "__main__":
    print("AMM...")

    # "combine_trigger"/"prior_trigger"/"posterior_trigger"/"timing_trigger"
    # "optimal_design"/"random_design"
    detector = AMM(False, "combine_trigger", "optimal_design")

    n = 1080
    max_service_rate = 23.0
    servers = 3
    for k in range(0, n):
        arrival_rate = 63.5833
        respTime = 0.0797847
        print("k={}, servers={}, arrival_rate={}, respTime={}".format(k, servers, arrival_rate, respTime))

        alarm, active_flag, opt_AS = detector.deviation_detector(servers, arrival_rate, respTime)
        if active_flag == 1:
            print("alarm={}, active_flag={}, opt_AS={}".format(alarm, active_flag, opt_AS))
            break