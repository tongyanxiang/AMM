/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICECSWITCHER_H_
#define SERVICECSWITCHER_H_

#include <omnetpp.h>

using namespace omnetpp;

class ServiceCSwitcher : public cSimpleModule
{
  public:
    bool triggerMandatoryCtrl=false;

    bool getSwitcherMode();
    void setSwitcherMode(bool MCtrl);

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
