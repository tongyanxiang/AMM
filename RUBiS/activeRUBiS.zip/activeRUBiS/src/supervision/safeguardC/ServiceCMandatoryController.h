/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICECMANDATORYCONTROLLER_H_
#define SERVICECMANDATORYCONTROLLER_H_

#include <omnetpp.h>
#include "managers/model/ServiceCModel.h"
#include "managers/execution/ServiceCExecutionManager.h"

using namespace omnetpp;

class ServiceCMandatoryController : public cSimpleModule
{
  public:
    ServiceCModel *pModel;
    ServiceCExecutionManager* pExecMgr;

    void setControlParamter();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
