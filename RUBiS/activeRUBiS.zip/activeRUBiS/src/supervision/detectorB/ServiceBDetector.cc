/*******************************************************************************
 * Model Deviation Detector.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/
#include "ServiceBDetector.h"

#include <iostream>
#include <fstream>
#include <stdio.h>
#include <stdio.h>
#include <stdlib.h>
#include <boost/tokenizer.hpp>

Define_Module(ServiceBDetector);

ServiceBDetector::ServiceBDetector() {
}

ServiceBDetector::~ServiceBDetector() {
    if (supervisionTrigger) {
        // finish Python interpreter
        Py_Finalize();
    }
}

void ServiceBDetector::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // supervision
    cXMLElement *supervisionTriggerNode = getParentModule()->par("supervisionTriggerXML").xmlValue();
    supervisionTrigger = string(supervisionTriggerNode->getNodeValue())=="true" ? 1 : 0;

    if (supervisionTrigger) {

        cXMLElement *switchTriggerXMLNode = getParentModule()->par("switchTriggerXML").xmlValue();
        switchTrigger = string(switchTriggerXMLNode->getNodeValue())=="true" ? 1 : 0;

        // initializes python interpreter
        Py_Initialize();

        // import python script and construct the instance
        PyRun_SimpleString("import sys");
        PyRun_SimpleString("sys.path.append('../../src/supervision/detectors')");

        cXMLElement *auxiliarySignalTriggerModeNode = getParentModule()->par("auxiliarySignalTriggerModeXML").xmlValue();
        auxiliarySignalTriggerMode = string(auxiliarySignalTriggerModeNode->getNodeValue());

        cXMLElement *auxiliarySignalDesignModeNode = getParentModule()->par("auxiliarySignalDesignModeXML").xmlValue();
        auxiliarySignalDesignMode = string(auxiliarySignalDesignModeNode->getNodeValue());

        PyObject *pModule = PyImport_ImportModule("AMM");
        if (pModule == nullptr){
               cout <<"[Error] Import module AMM error" << endl;
        }

        PyObject *pClass = PyObject_GetAttrString(pModule, "AMM");
        if (pClass == nullptr){
            cout << "[Error] Import class AMM error" << endl;
        }

        PyObject *initArgs = Py_BuildValue("(bss)", logging, auxiliarySignalTriggerMode.c_str(), auxiliarySignalDesignMode.c_str());
        pInstance = PyObject_Call(pClass, initArgs, nullptr);
        if (pInstance == nullptr){
            cout << "[Error] Initialize instance AMM error" << endl;
        }

        // timing_trigger
        if (auxiliarySignalTriggerMode == "timing_trigger") {
            cXMLElement *timingIntervalNode = getParentModule()->par("timingIntervalXML").xmlValue();
            timingInterval = atoi(timingIntervalNode->getNodeValue());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDetector] timingInterval=" << timingInterval << endl;
            }

            PyObject *args = Py_BuildValue("(i)", timingInterval);
            PyObject *pRet = PyObject_CallMethod(pInstance, "set_timing_interval", "O", args);
            if (pRet == nullptr){
                cout << "[Error] No pRet returned" << endl;
            }
        }

        // random_design
        if (auxiliarySignalDesignMode == "random_design") {
            cXMLElement *rndSeedNode = getParentModule()->par("rndSeedXML").xmlValue();
            rndSeed = atoi(rndSeedNode->getNodeValue());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDetector] rndSeed=" << rndSeed << endl;
            }

            PyObject *args = Py_BuildValue("(i)", rndSeed);
            PyObject *pRet = PyObject_CallMethod(pInstance, "set_rnd_seed", "O", args);
            if (pRet == nullptr){
                cout << "[Error] No pRet returned" << endl;
            }
        }
        cout << "t=" << simTime() << " [ServiceBDetector] AMM module has initialized!" << endl;

        // tracing
        supervisionFilePath = "../traces/serviceBAMMTrace.txt";

        // delete old supervision trace file
        ifstream cpFin(supervisionFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDetector] " << supervisionFilePath << " does not exist" << endl;
            }
        } else {
            remove(supervisionFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDetector] Delete " << supervisionFilePath << endl;
            }
        }

        // first line of supervision trace file
        ofstream out;
        out.open(supervisionFilePath.c_str(), ios::app);
        if (out.is_open()) {
            out << "simTime,";
            out << "controlServers_{k-1},";
            out << "measuredArrivalRate_{k},";
            out << "measuredAvgRespTime_{k},";
            out << "B_k_prior,";
            out << "P_k_prior,";
            out << "B_k_posterior,";
            out << "P_k_posterior,";
            out << "B_k_predict,";
            out << "P_k_predict,";
            out << "alarm,";
            out << "activeFlag,";
            out << "optAS\n";
            out.close();
        }

        pMonitor = check_and_cast<ServiceBSimMonitor*>(getParentModule()->getSubmodule("simMonitorB"));
        pCtrl = check_and_cast<ServiceBPIController*>(getParentModule()->getSubmodule("PIControllerB"));
        pSwitcher = check_and_cast<ServiceBSwitcher*>(getParentModule()->getSubmodule("switcherB"));
    }
}

void ServiceBDetector::handleMessage(cMessage *msg) {

    controlServers = pCtrl->getControlServers();
    measuredArrivalRate =  pMonitor->getMeasuredArrivalRate();
    measuredAvgRespTime = pMonitor->getMeasuredAvgRespTime();

    cout << "t=" << simTime() << " [ServiceBDetector] controlServers[" << num << "]=" << controlServers
                                            << " measuredArrivalRate[" << num << "]=" << measuredArrivalRate
                                            << " measuredAvgRespTime[" << num << "]=" << measuredAvgRespTime << endl;

    bool triggerMandatoryCtrl = pSwitcher->getSwitcherMode();
    if (not triggerMandatoryCtrl) {
        deviationDetector(controlServers, measuredArrivalRate, measuredAvgRespTime);
    }

    send(msg, "out");

    num = num + 1;
}

void ServiceBDetector::deviationDetector(int controlServers, double measuredArrivalRate, double measuredAvgRespTime){

    PyObject *mainArgs = Py_BuildValue("(idd)", controlServers, measuredArrivalRate, measuredAvgRespTime);
    PyObject *mainPRet = PyObject_CallMethod(pInstance, "deviation_detector", "O", mainArgs);
    if (mainPRet == nullptr){
        cout << "[Error] AMM No pRet returned" << endl;
    }

    //returned alarm signal
    PyArg_ParseTuple(mainPRet, "d|d|d|d|d|d|i|i|i", &B_k_prior, &P_k_prior, &B_k_posterior, &P_k_posterior, &B_k_predict, &P_k_predict, &alarm, &activeFlag, &optAS);
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBDetector] B_k_prior[" << num << "]=" << B_k_prior
                                                     << " P_k_prior[" << num << "]=" << P_k_prior
                                                 << " B_k_posterior[" << num << "]=" << B_k_posterior
                                                 << " P_k_posterior[" << num << "]=" << P_k_posterior
                                                   << " B_k_predict[" << num << "]=" << B_k_predict
                                                   << " P_k_predict[" << num << "]=" << P_k_predict
                                                         << " alarm[" << num << "]=" << alarm
                                                    << " activeFlag[" << num << "]=" << activeFlag
                                                         << " optAS[" << num << "]=" << optAS << endl;
    }

    // stop simulation if alarm
//    if (alarm == 1) {
//        getSimulation()->setSimulationTimeLimit(simTime() + 5.0);
//    }

    // active part
    if (activeFlag == 1 and timer > 0) {

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBDetector] activeFlag[" << num << "]=" << activeFlag
                                                              << " optAS[" << num << "]=" << optAS
                                                              << " stable_loop[" << num << "]=" << stable_loop
                                                              << " timer[" << num << "]=" << timer << endl;
        }

        // set auxiliary signal
        if (timer >= stable_loop) {
            // save historic info
            controlServersOld = controlServers;
            measuredArrivalRateOld = measuredArrivalRate;
            historicOptAS = optAS;

            pCtrl->setActiveFlag(activeFlag);
            pCtrl->setOptAS(optAS);

        } else {
            // reset
            optAS = 0;
        }

        //timing
        timer = timer - 1;

    } else if (abs(historicOptAS) > 0) {

       if (timer >= 1) {
           //timing
           timer = timer - 1;

       } else {
            // recovery condition
            int deltaCS = controlServers - controlServersOld;
            double deltaArr = measuredArrivalRate - measuredArrivalRateOld;

            if (abs(deltaArr) < MAX_SERVICE_RATE and deltaCS == historicOptAS){
                recoveryFlag = 1;
                recoveryAS = 0 - historicOptAS;

                // reset
                optAS = 0;
                historicOptAS = 0;
            }

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceBDetector] recoveryFlag[" << num << "]=" << recoveryFlag << " timer[" << num << "]=" << timer << " recoveryAS[" << num << "]=" << recoveryAS << endl;
            }

            // recovery action
            if (recoveryFlag == 1){
                pCtrl->setRecoveryFlag(recoveryFlag);
                pCtrl->setRecoveryAS(recoveryAS);

                // reset
                recoveryAS = 0;
                timer = stable_loop;
            }
        }
    }

    // switch
    if (switchTrigger) {
        // set switcher
        if (alarm == 1) {
            pSwitcher->setSwitcherMode(true);
        }
    }

    // tracing
    writeTrace();
}

void ServiceBDetector::writeTrace() {
    ofstream out;
    out.open(supervisionFilePath.c_str(), ios::app);
    if (out.is_open()) {
        out << simTime();
        out << ",";
        out << controlServers;
        out << ",";
        out << measuredArrivalRate;
        out << ",";
        out << measuredAvgRespTime;
        out << ",";
        out << B_k_prior;
        out << ",";
        out << P_k_prior;
        out << ",";
        out << B_k_posterior;
        out << ",";
        out << P_k_posterior;
        out << ",";
        out << B_k_predict;
        out << ",";
        out << P_k_predict;
        out << ",";
        out << alarm;
        out << ",";
        out << activeFlag;
        out << ",";
        out << optAS;
        out << "\n";
        out.close();
    }
}
