/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEAMANDATORYCONTROLLER_H_
#define SERVICEAMANDATORYCONTROLLER_H_

#include <omnetpp.h>
#include "managers/model/ServiceAModel.h"
#include "managers/execution/ServiceAExecutionManager.h"

using namespace omnetpp;

class ServiceAMandatoryController : public cSimpleModule
{
  public:
    ServiceAModel *pModel;
    ServiceAExecutionManager* pExecMgr;

    void setControlParamter();

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
