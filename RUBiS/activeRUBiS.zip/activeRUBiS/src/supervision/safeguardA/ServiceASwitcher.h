/*******************************************************************************
 * Controller Switcher.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEASWITCHER_H_
#define SERVICEASWITCHER_H_

#include <omnetpp.h>

using namespace omnetpp;

class ServiceASwitcher : public cSimpleModule
{
  public:
    bool triggerMandatoryCtrl=false;

    bool getSwitcherMode();
    void setSwitcherMode(bool MCtrl);

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
