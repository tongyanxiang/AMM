/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceAMandatoryController.h"

Define_Module(ServiceAMandatoryController);

void ServiceAMandatoryController::initialize()
{
    pModel = check_and_cast<ServiceAModel*> (getParentModule()->getSubmodule("modelA"));
    pExecMgr = check_and_cast<ServiceAExecutionManager*> (getParentModule()->getSubmodule("executionManagerA"));
}

void ServiceAMandatoryController::handleMessage(cMessage *msg)
{
    setControlParamter();

    //finish
    delete msg;
}

void ServiceAMandatoryController::setControlParamter() {

    // set low fidelity mode
    pExecMgr->setBrownout(1.0);
    pModel->setBrownoutFactor(1.0);
}
