/*******************************************************************************
 * Mandatory Controller.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceBMandatoryController.h"

Define_Module(ServiceBMandatoryController);

void ServiceBMandatoryController::initialize()
{
    pModel = check_and_cast<ServiceBModel*> (getParentModule()->getSubmodule("modelB"));
    pExecMgr = check_and_cast<ServiceBExecutionManager*> (getParentModule()->getSubmodule("executionManagerB"));
}

void ServiceBMandatoryController::handleMessage(cMessage *msg)
{
    setControlParamter();

    //finish
    delete msg;
}

void ServiceBMandatoryController::setControlParamter() {

    // set low fidelity mode
    pExecMgr->setBrownout(1.0);
    pModel->setBrownoutFactor(1.0);
}
