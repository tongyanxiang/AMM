/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <math.h>
#include <assert.h>
#include "managers/util/ServiceAUtils.h"
#include "managers/execution/ServiceAExecutionManager.h"
#include "ServiceAModel.h"

Define_Module(ServiceAModel);

void ServiceAModel::addExpectedServerChange(double time, ModelServerChange change) {
    ModelServerChangeEvent event;
    event.startTime = simTime().dbl();
    event.time = time;
    event.change = change;
    serverChangeEvents.insert(event);
}

void ServiceAModel::addServer(double bootDelay) {
    addExpectedServerChange(simTime().dbl() + bootDelay, ServiceAModel::SERVER_ONLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] addServer bootDelay=" << bootDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceAModel::removeServer(double offDelay) {
    addExpectedServerChange(simTime().dbl() + offDelay, ServiceAModel::SERVER_OFFLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] removeServer offDelay=" << offDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceAModel::serverBecameActive() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceAModel::SERVER_ONLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server boot change for this
    serverChangeEvents.erase(it);

    activeServers++;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] serverBecameActive"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceAModel::serverBecameShutDown() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceAModel::SERVER_OFFLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server shutdown change for this
    serverChangeEvents.erase(it);

    activeServers--;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] serverBecameShutDown"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

int ServiceAModel::numServerBooting() const {
    int bootingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_ONLINE){
                bootingNum++;
            }
            eventIt++;
        }
   }
    return bootingNum;
}

int ServiceAModel::numServerShutting() const {
    int shuttingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_OFFLINE){
                shuttingNum++;
            }
            eventIt++;
        }
   }
    return shuttingNum;
}

void ServiceAModel::pushServerPool(double time, int id) {
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] push server id=" << id << " time=" << time << endl;
    }

    ModelServerPoolEvent event;
    event.time = time;
    event.id = id;
    serverPoolEvents.insert(event);
}

int ServiceAModel::popServerPool() {
    int id = -1;
    if (!serverPoolEvents.empty()) {
        ModelServerPoolEvents::iterator it = serverPoolEvents.end();
        it--;
        id = it->id;
        serverPoolEvents.erase(it);
    }

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceAModel] pop id=" << id << " time=" << simTime().dbl() << endl;
    }

    return id;
}

std::vector<int> ServiceAModel::getServerPool() {
    serverModuleIds.clear();
    ModelServerPoolEvents::iterator it = serverPoolEvents.begin();
    while (it != serverPoolEvents.end()) {
        serverModuleIds.push_back(it->id);
        it++;
    }
    return serverModuleIds;
}

void ServiceAModel::initialize(int stage) {
    if (stage == 0) {

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

        // servers
        brownoutFactor = getParentModule()->par("brownoutFactor");

        // uncertainty
        bootDelay = ServiceAUtils::getMeanAndVarianceFromParameter(getParentModule()->par("bootDelay"));
        offDelay = ServiceAUtils::getMeanAndVarianceFromParameter(getParentModule()->par("offDelay"));

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAModel] initialize"
                                      << " brownoutFactor=" << brownoutFactor
                                      << " bootDelay="      << bootDelay
                                      << " offDelay="       << offDelay << endl;
        }
    } else {
        // initial servers
        ServiceAExecutionManager* pExecMgr = check_and_cast<ServiceAExecutionManager*> (getParentModule()->getSubmodule("executionManagerA"));

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        int initialServers = atoi(initialServersNode->getNodeValue());

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceAModel] initialServers=" << initialServers << endl;
        }

        while (initialServers > 0) {
            pExecMgr->addServerLatencyOptional(true); // add a server instantaneously
            initialServers--;
        }
    }
}

// servers
double ServiceAModel::getBrownoutFactor() const {
    return brownoutFactor;
}

void ServiceAModel::setBrownoutFactor(double factor) {
    brownoutFactor = factor;
}

int const ServiceAModel::getServers() const {
    return activeServers + numServerBooting()-numServerShutting();
}

int const ServiceAModel::getActiveServers() const {
    return activeServers;
}

int ServiceAModel::getServerThreads() const {
    return serverThreads;
}

void ServiceAModel::setServerThreads(int serverThreads) {
    this->serverThreads = serverThreads;
}

double ServiceAModel::getServiceTimeMean() const {
    return serviceTimeMean;
}

void ServiceAModel::setServiceTime(double serviceTimeMean, double serviceTimeVariance) {
    this->serviceTimeMean = serviceTimeMean;
    this->serviceTimeVariance = serviceTimeVariance;
}

double ServiceAModel::getLowFidelityServiceTimeMean() const {
    return lowFidelityServiceTimeMean;
}

void ServiceAModel::setLowFidelityServiceTime(double lowFidelityServiceTimeMean, double lowFidelityServiceTimeVariance) {
    this->lowFidelityServiceTimeMean = lowFidelityServiceTimeMean;
    this->lowFidelityServiceTimeVariance = lowFidelityServiceTimeVariance;
}

// uncertainty
double ServiceAModel::getBootDelay() const {
    return bootDelay;
}

// utility
double ServiceAModel::getUtility() const {
    return utility;
}

void ServiceAModel::setUtility(double utility) {
    this->utility = utility;
}

// envrionement
const ServiceAEnvironment& ServiceAModel::getEnvironment() const {
    return environment;
}

void ServiceAModel::setEnvironment(const ServiceAEnvironment& environment) {
    this->environment = environment;
}

const ServiceAObservations& ServiceAModel::getObservations() const {
    return observations;
}

void ServiceAModel::setObservations(const ServiceAObservations& observations) {
    this->observations = observations;
}
