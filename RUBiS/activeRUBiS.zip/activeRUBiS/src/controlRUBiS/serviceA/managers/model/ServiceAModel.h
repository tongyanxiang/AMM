/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEAMODEL_H_
#define SERVICEAMODEL_H_

#include <set>
#include <omnetpp.h>
#include "managers/model/ServiceAEnvironment.h"
#include "managers/model/ServiceAObservations.h"

using namespace omnetpp;
using namespace std;

class ServiceAModel : public omnetpp::cSimpleModule {
    /*
     * record server booting and shutting down event (SERVER_ONLINE and SERVER_OFFLINE)
     */
    enum ModelServerChange {
        SERVER_ONLINE,
        SERVER_OFFLINE
    };

    struct ModelServerChangeEvent {
        double startTime;           // when the event was created
        double time;                // when the event will happen
        ModelServerChange change;
    };

    struct ModelServerChangeEventComp {
      bool operator() (const ModelServerChangeEvent& lhs, const ModelServerChangeEvent& rhs) const {
          return lhs.time < rhs.time;
      }
    };

    typedef std::multiset<ModelServerChangeEvent, ModelServerChangeEventComp> ModelServerChangeEvents;

    /*
     * when adding two more servers at one time, the server2 may boot after
     * server3 because of random booting time. thus, we need ModelServerPoolEvent
     * to record active and booting servers with module id not its name.
     */
    struct ModelServerPoolEvent {
        int id;      // server module id
        double time; // when the event will happen
    };

    struct ModelServerPoolEventComp {
      bool operator() (const ModelServerPoolEvent& lhs, const ModelServerPoolEvent& rhs) const {
          return lhs.time < rhs.time;
      }
    };

    typedef std::multiset<ModelServerPoolEvent, ModelServerPoolEventComp> ModelServerPoolEvents;

  protected:
    virtual int numInitStages() const {return 2;}
    virtual void initialize(int stage);

    ModelServerChangeEvents serverChangeEvents;
    ModelServerPoolEvents serverPoolEvents;
    std::vector<int> serverModuleIds;                 // for set dimmer

    ServiceAEnvironment environment;
    ServiceAObservations observations;

    //logging
    bool cmdenvLogging;

    // servers
    double brownoutFactor;
    int activeServers=0;                           /* number of active servers (there is one more powered up if a server is booting) */

    int serverThreads;
    double serviceTimeMean;
    double serviceTimeVariance;
    double lowFidelityServiceTimeMean;
    double lowFidelityServiceTimeVariance;

    // uncertainty
    double bootDelay;
    double offDelay;

    // utility
    double utility = 0;

  public:
    void addExpectedServerChange(double time, ModelServerChange change);
    void addServer(double bootDelay);
    void removeServer(double bootDelay);
    void serverBecameActive();
    void serverBecameShutDown();
    int numServerBooting() const;
    int numServerShutting() const;

    void pushServerPool(double time, int id);
    int popServerPool();
    std::vector<int> getServerPool();

    // servers
    double getBrownoutFactor() const;
    void setBrownoutFactor(double factor);

    int const getServers() const;
    int const getActiveServers() const;

    int getServerThreads() const;
    void setServerThreads(int serverThreads);
    double getServiceTimeMean() const;
    void setServiceTime(double serviceTimeMean, double serviceTimeVariance);
    double getLowFidelityServiceTimeMean() const;
    void setLowFidelityServiceTime(double lowFidelityServiceTimeMean, double lowFidelityServiceTimeVariance);

    // uncertainty
    double getBootDelay() const;

    // utility
    double getUtility()const;
    void setUtility(double utility);

    // environment
    const ServiceAEnvironment& getEnvironment() const;
    virtual void setEnvironment(const ServiceAEnvironment& environment);
    const ServiceAObservations& getObservations() const;
    void setObservations(const ServiceAObservations& observations);
};

#endif
