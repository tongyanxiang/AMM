/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEASIMPROBE_H_
#define SERVICEASIMPROBE_H_

#include "managers/util/ServiceATimeWindowStats.h"
#include "managers/model/ServiceAModel.h"

using namespace omnetpp;
using namespace std;

/**
 * This class collects statistics from the simulated system
 */
class ServiceASimProbe : public omnetpp::cSimpleModule, omnetpp::cListener {

  public:
    //logging
    bool cmdenvLogging;

    //control
    double controlPeriod;

    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const omnetpp::SimTime& t, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, double value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, bool value, cObject *details) override;
    void receiveSignal(omnetpp::cComponent *source, omnetpp::simsignal_t signalID, const char* value, cObject *details) override;

    double getUtilization(const std::string& serverName);

    ServiceAObservations getUpdatedObservations();
    ServiceAEnvironment getUpdatedEnvironment();

  protected:
    /* subscribed arrivalMonitor signals */
    simsignal_t serviceAInterArrivalSignal;

    /* subscribed server signals */
    simsignal_t serverAServiceTimeSignal;

    /* subscribed sink signals */
    simsignal_t serviceALifeTimeSignal;

    /* subscribed server state signals */
    simsignal_t serverABusySignal;
    simsignal_t serverARemovedSignal;

    double window; /* time window in seconds for statistics */
    ServiceATimeWindowStats arrival;
    ServiceATimeWindowStats basicServiceTime;
    ServiceATimeWindowStats optServiceTime;
    ServiceATimeWindowStats basicResponseTime;
    ServiceATimeWindowStats optResponseTime;
    ServiceATimeWindowStats responseTime;

    std::map<std::string, ServiceATimeWindowStats> utilization;

    ServiceAModel* pModel;

    virtual int numInitStages() const override {return 2;}
    virtual void initialize(int stage) override;
    virtual void handleMessage(omnetpp::cMessage *msg) override;
};

#endif
