/*******************************************************************************
 * Load Balancer
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "ServiceARouter.h"

Define_Module(ServiceARouter);

void ServiceARouter::initialize()
{
    rrCounter = 0;
}

void ServiceARouter::handleMessage(cMessage *msg)
{
    int outGateIndex = -1;  // by default we drop the message

    // get new out gate index
    rrCounter = (rrCounter + 1) % gateSize("out");
    outGateIndex = rrCounter;

    // send out if the index is legal
    if (outGateIndex < 0 || outGateIndex >= gateSize("out"))
        throw cRuntimeError("Invalid output gate selected during routing");

    send(msg, "out", outGateIndex);
}
