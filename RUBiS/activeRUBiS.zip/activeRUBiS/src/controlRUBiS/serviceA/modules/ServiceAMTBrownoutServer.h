/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEAMTBROWNOUTSERVER_H_
#define SERVICEAMTBROWNOUTSERVER_H_

#include <map>
#include <list>
#include <string>
#include "Job.h"
#include "IPassiveQueue.h"
#include "SelectionStrategies.h"
#include "IServer.h"

using namespace omnetpp;
using namespace queueing;
using namespace std;

namespace queueing {
    class Job;
    class SelectionStrategy;
}

class ServiceAMTBrownoutServer : public omnetpp::cSimpleModule, public queueing::IServer {
    /**
     * Map to store the request count for each server, even between
     * removals and re-additions.
     */
    static std::map<long, long> requestCount;

    /**
     * Low service requests use DB much less, so caching is not that important
     * If this is true, the are included in the caching effect simulation
     */
    bool cacheLow;

    /**
     * How many requests it takes the system to reach a somewhat stable
     * service time.
     */
    double cacheRequestCount;

    /**
     * The difference in service time between the start of the run and
     * the stable state, for the requests with optional content (or high fidelity)
     */
    double cacheDelta;

    /**
     * The difference in service time between the start of the run and
     * the stable state, for the requests without optional content (or low fidelity)
     */
    double cacheDeltaLow;

    /**
     * This controls how close the exponential decay gets to stable
     * service time, and also controls the shape. This is tuned experimentally so that
     * the decay in the simulated run approximates the real run.
     */
    double cachePrecision;

    /**
     * If false, it makes clearServerCache() a noop
     */
    bool cacheClearsWhenReboot;

  protected:
    struct ScheduledJob {
        queueing::Job* pJob;
        double remainingServiceTime; // as if it was not sharing the processor
        bool operator<(const ScheduledJob& b) const {
            return remainingServiceTime < b.remainingServiceTime;
        }
    };

    typedef std::list<ScheduledJob> RunningJobs;
    RunningJobs runningJobs;

    simsignal_t serverABusySignal;
    simsignal_t serverAServiceTimeSignal;

    cMessage *endExecutionMsg;

    queueing::SelectionStrategy* selectionStrategy;

    // logging
    bool cmdenvLogging;

    // servers
    unsigned maxThreads;
    double timeout;

    // model deviation
    double serviceTimeMean = 0.03;
    double serviceTimeSigma = 0.03;

    std::string deviationMode;
    std::string deviationServiceModule;
    double BOffsetPercent;
    double PI = 3.14159265358979323846;
    double period;

    string deviationFilePath;

    virtual void updateJobTimes();
    virtual void scheduleNextCompletion();
    virtual simtime_t generateJobServiceTime(queueing::Job* pJob);

    virtual void initialize();
    virtual void handleMessage(cMessage *msg);

  public:
    ServiceAMTBrownoutServer();
    virtual ~ServiceAMTBrownoutServer();
    void clearServerCache();

    /**
     * This actually returns true if it can take one more job, even if it's not idle
     * This is this way to follow the semantics that PassiveQueue expect for this
     */
    virtual bool isIdle();
    virtual bool isEmpty();
    virtual void allocate();
};

#endif
