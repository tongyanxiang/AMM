/*******************************************************************************
 * Load Balancer
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEAROUTER_H
#define SERVICEAROUTER_H

#include "QueueingDefs.h"

/**
 * Sends the messages to different outputs depending on Round Robin algorithm.
 */
class ServiceARouter : public cSimpleModule
{
    private:
        int rrCounter;         // msgCounter for round robin routing

    protected:
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

#endif
