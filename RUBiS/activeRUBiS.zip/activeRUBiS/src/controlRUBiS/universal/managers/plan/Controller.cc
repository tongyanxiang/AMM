/*******************************************************************************
 * Controller for Servers.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <time.h>
#include <iostream>
#include <fstream>
#include "Controller.h"

Define_Module(Controller);

void Controller::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // control
    cXMLElement *controlTriggerNode = getSimulation()->getSystemModule()->par("controlTriggerXML").xmlValue();
    controlTrigger = string(controlTriggerNode->getNodeValue())=="true" ? 1 : 0;

    if (controlTrigger) {
        pModel = check_and_cast<Model*>(getParentModule()->getSubmodule("model"));
        pMonitor = check_and_cast<SimMonitor*>(getParentModule()->getSubmodule("simMonitor"));
    }
}

void Controller::handleMessage(cMessage *msg) {

    // get measurements
    measuredArrivalRate = pMonitor->getMeasuredArrivalRate();

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [Controller] measuredArrivalRate[" << num << "]=" << measuredArrivalRate << endl;
    }

    num = num + 1;

    //finish
    delete msg;
}
