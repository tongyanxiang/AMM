/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <fstream>
#include <iostream>
#include <string>
#include <boost/tokenizer.hpp>
#include "Job.h"
#include "SimSource.h"

Define_Module(SimSource);

void SimSource::preload() {
    double serviceAArrivalTime = 0;
    double serviceBArrivalTime = 0;
    double serviceCArrivalTime = 0;

    if (identTrigger) {
        cXMLElement *identWorkloadNode = getSimulation()->getSystemModule()->par("identWorkloadFileXML").xmlValue();
        workloadFilePath = identWorkloadNode->getNodeValue();
    } else {
        cXMLElement *interArrivalsNode = getSimulation()->getSystemModule()->par("controlWorkloadFileXML").xmlValue();
        workloadFilePath = interArrivalsNode->getNodeValue();
    }

    ifstream fin(workloadFilePath);
    if (!fin) {
        error("SimSource %s could not read input file '%s'", this->getFullName(), workloadFilePath);
    } else {
        std::string wlStr;
        while (fin >> wlStr) {

            typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
            tokenizer tokens(wlStr, boost::char_separator<char>(","));
            tokenizer::iterator it = tokens.begin();

            double timeValue = atof((*it).c_str()); // the first token
            it++; // next token

            const char *servicePath = (*it).c_str(); // the second token
            if (strcmp(servicePath, "serviceA") == 0) {
                serviceAArrivalTime += timeValue;
                serviceAArrivalTimes.push_back(serviceAArrivalTime);
                serviceAInterArrivalTimes.push_back(timeValue);

            } else if (strcmp(servicePath, "serviceB") == 0) {
                serviceBArrivalTime += timeValue;
                serviceBArrivalTimes.push_back(serviceBArrivalTime);
                serviceBInterArrivalTimes.push_back(timeValue);

            } else if (strcmp(servicePath, "serviceC") == 0) {
                serviceCArrivalTime += timeValue;
                serviceCArrivalTimes.push_back(serviceCArrivalTime);
                serviceCInterArrivalTimes.push_back(timeValue);
            }
        }

        fin.close();

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [SimSource] read " << serviceAArrivalTimes.size()
                                      << " requests from " << workloadFilePath << " and serviceAArrivalTime is " << serviceAArrivalTime << "s" << endl;
            cout << "t=" << simTime() << " [SimSource] read " << serviceBArrivalTimes.size()
                                      << " requests from " << workloadFilePath << " and serviceBArrivalTime is " << serviceBArrivalTime << "s" << endl;
            cout << "t=" << simTime() << " [SimSource] read " << serviceCArrivalTimes.size()
                                      << " requests from " << workloadFilePath << " and serviceCArrivalTime is " << serviceCArrivalTime << "s" << endl;
        }

        // set simulation limit time as arrivalTime (small time 20.0 for last step)
        double arrivalTime = std::max(serviceAArrivalTime, std::max(serviceBArrivalTime, serviceCArrivalTime));
        getSimulation()->setSimulationTimeLimit(arrivalTime + 20.0);

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [SimSource] arrivalTime is " << arrivalTime << "s" << endl;
        }
    }
}

void SimSource::initialize() {

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // identification
    cXMLElement *identTriggerNode = getSimulation()->getSystemModule()->par("identTriggerXML").xmlValue();
    identTrigger = string(identTriggerNode->getNodeValue())=="true" ? 1 : 0;

    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [SimSource] identTrigger= " << identTrigger << endl;
    }

    // initialization and user workload
    SourceBase::initialize();
    preload();

    // schedule the first message timer, if there is one
    serviceANextArrivalIndex = 0;
    if (serviceAInterArrivalTimes.size() > 0) {
        scheduleAt(serviceAInterArrivalTimes[serviceANextArrivalIndex], new cMessage("serviceANewJobTimer"));
    }

    serviceBNextArrivalIndex = 0;
    if (serviceBInterArrivalTimes.size() > 0) {
        scheduleAt(serviceBInterArrivalTimes[serviceBNextArrivalIndex], new cMessage("serviceBNewJobTimer"));
    }

    serviceCNextArrivalIndex = 0;
    if (serviceCInterArrivalTimes.size() > 0) {
        scheduleAt(serviceCInterArrivalTimes[serviceCNextArrivalIndex], new cMessage("serviceCNewJobTimer"));
    }
}

void SimSource::handleMessage(cMessage *msg) {

    // generate new jobs to serviceA/serviceB/serviceC
    if (strcmp(msg->getName(), "serviceANewJobTimer") == 0 && serviceANextArrivalIndex < serviceAInterArrivalTimes.size()) {

        // create arrival jobs and send it to arrivalMonitor
        queueing::Job *job = createJob();

        // rename job based on service path
        const char *jobName = job->getName();

        string serviceJobNameStr = "serviceA-" + string(jobName);
        const char *serviceJobName = serviceJobNameStr.c_str();
        job->setName(serviceJobName);

        // send out jobs
        send(job, "out");

        // reschedule the timer for the next message
        serviceANextArrivalIndex = serviceANextArrivalIndex + 1;
        scheduleAt(simTime() + serviceAInterArrivalTimes[serviceANextArrivalIndex], msg);

     } else if (strcmp(msg->getName(), "serviceBNewJobTimer") == 0 && serviceBNextArrivalIndex < serviceBInterArrivalTimes.size()) {

        // create arrival jobs and send it to arrivalMonitor
        queueing::Job *job = createJob();

        // rename job based on service path
        const char *jobName = job->getName();

        string serviceJobNameStr = "serviceB-" + string(jobName);
        const char *serviceJobName = serviceJobNameStr.c_str();
        job->setName(serviceJobName);

        // send out jobs
        send(job, "out");

        // reschedule the timer for the next message
        serviceBNextArrivalIndex = serviceBNextArrivalIndex + 1;
        scheduleAt(simTime() + serviceBInterArrivalTimes[serviceBNextArrivalIndex], msg);

     } else if (strcmp(msg->getName(), "serviceCNewJobTimer") == 0 && serviceCNextArrivalIndex < serviceCInterArrivalTimes.size()) {

        // create arrival jobs and send it to arrivalMonitor
        queueing::Job *job = createJob();

        // rename job based on service path
        const char *jobName = job->getName();

        string serviceJobNameStr = "serviceC-" + string(jobName);
        const char *serviceJobName = serviceJobNameStr.c_str();
        job->setName(serviceJobName);

        // send out jobs
        send(job, "out");

        // reschedule the timer for the next message
        serviceCNextArrivalIndex = serviceCNextArrivalIndex + 1;
        scheduleAt(simTime() + serviceCInterArrivalTimes[serviceCNextArrivalIndex], msg);

    } else {
        // finished
        delete msg;
    }
}
