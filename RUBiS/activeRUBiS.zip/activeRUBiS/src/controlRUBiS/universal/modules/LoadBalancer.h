/*******************************************************************************
 * Load Balancer.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef LOADBALANCER_H
#define LOADBALANCER_H

#include "QueueingDefs.h"

using namespace omnetpp;
using namespace queueing;
using namespace std;

/**
 * Sends the messages to different outputs depending on Round Robin algorithm.
 */
class LoadBalancer : public cSimpleModule
{
    protected:
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

#endif
