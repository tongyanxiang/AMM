/*******************************************************************************
 * Load Balancer.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include <boost/tokenizer.hpp>
#include "Job.h"
#include "LoadBalancer.h"

Define_Module(LoadBalancer);

void LoadBalancer::initialize()
{
}

void LoadBalancer::handleMessage(cMessage *msg)
{
    string jobName = string(msg->getName());
    //cout << jobName << endl;

    // extract service info of jobName:serviceX-user-XXX
    typedef boost::tokenizer<boost::char_separator<char> > tokenizer;
    tokenizer tokens(jobName, boost::char_separator<char>("-"));
    tokenizer::iterator it = tokens.begin();

    const char *servicePath = (*it).c_str(); // the first token
    if (strcmp(servicePath, "serviceA") == 0) {
        send(msg, "outA");

    } else if (strcmp(servicePath, "serviceB") == 0) {
        send(msg, "outB");

    } else if (strcmp(servicePath, "serviceC") == 0) {
        //cout << servicePath << endl;
        send(msg, "outC");

    } else {
        cout << "[LoadBalancer] error servicePath: " << servicePath << endl;
    }
}
