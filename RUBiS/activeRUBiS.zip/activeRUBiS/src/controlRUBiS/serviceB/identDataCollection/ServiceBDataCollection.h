/*******************************************************************************
 * Data Collection for System Identification.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEBDATACOLLECTION_H_
#define SERVICEBDATACOLLECTION_H_

#include <omnetpp.h>
#include "managers/model/ServiceBModel.h"
#include "managers/monitor/ServiceBSimMonitor.h"
#include "managers/execution/ServiceBExecutionManager.h"

using namespace omnetpp;
using namespace std;

class ServiceBDataCollection : public cSimpleModule {

  public:
    struct MeasuredOutputsEvent {
        double measuredDimmer;
        int measuredServers;
        int measuredActiveServers;
        double measuredArrivalRate;
        double measuredAvgRespTime;
    };

    MeasuredOutputsEvent measuredOutputs;

    // logging
    bool cmdenvLogging;

    // identification
    bool identTrigger;
    string identServiceModule;
    string identFilePath;

    std::vector<double> identDimmerVec;
    std::vector<double> identServersVec;
    int identServers;

    // count
    int num = 0;

    ServiceBModel *pModel;
    ServiceBSimMonitor *pMonitor;
    ServiceBExecutionManager* pExecMgr;

    MeasuredOutputsEvent getMeasuredOutputs();
    void setIdentControlParameters();
    void writeIdentTrace(MeasuredOutputsEvent measuredOutputs);
    std::vector<double> split(std::string str); /* split string(xml) to double vector */

  protected:
    virtual void initialize();
    virtual void handleMessage(cMessage *msg);
};

#endif
