/*******************************************************************************
 * Load Balancer.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEBLOADBALANCER_H
#define SERVICEBLOADBALANCER_H

#include "QueueingDefs.h"

/**
 * Send the messages to different outputs depending on Round Robin algorithm.
 */
class ServiceBRouter : public cSimpleModule
{
    private:
        int rrCounter;         // msgCounter for round robin routing

    protected:
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

#endif
