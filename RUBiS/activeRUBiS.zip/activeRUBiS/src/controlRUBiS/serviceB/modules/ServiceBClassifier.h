/*******************************************************************************
 * Job Classifier.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#ifndef SERVICEBCLASSIFIER_H
#define SERVICEBCLASSIFIER_H

#include "QueueingDefs.h"

using namespace queueing;

/**
 * Send the messages to different outputs depending on messages type.
 */
class ServiceBClassifier : public omnetpp::cSimpleModule
{
    private:
        const char *dispatchField;   // the message's field or parameter we are dispatching on

    protected:
        virtual void initialize();
        virtual void handleMessage(cMessage *msg);
};

#endif
