/*******************************************************************************
 * Job Classifier.
 * Copyright (c) 2022 Nanjing University.
 * All Rights Reserved.
 *******************************************************************************/

#include "Job.h"
#include "ServiceBClassifier.h"

Define_Module(ServiceBClassifier);

void ServiceBClassifier::initialize()
{
    dispatchField = par("dispatchField");
}

void ServiceBClassifier::handleMessage(cMessage *msg)
{
    queueing::Job *job = check_and_cast<Job*>(msg);

    int outGateIndex = -1;
    if (strcmp(dispatchField, "type") == 0){
        outGateIndex = job->getKind();
    }

    if (outGateIndex < 0 || outGateIndex >= gateSize("out")) {
        send(job, "rest");
    }
    else {
        send(job, "out", outGateIndex);
    }
}
