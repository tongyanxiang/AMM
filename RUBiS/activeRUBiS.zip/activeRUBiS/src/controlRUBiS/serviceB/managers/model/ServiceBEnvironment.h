/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#ifndef SERVICEBENVIRONMENT_H_
#define SERVICEBENVIRONMENT_H_

#include <vector>
#include <ostream>

class ServiceBEnvironment {
    double arrivalRate;
    double arrivalMean;
    double arrivalVariance;

public:
    ServiceBEnvironment();
    ServiceBEnvironment(double arrivalRate, double arrivalMean, double arrivalVariance);
    double getArrivalRate() const;
    void setArrivalRate(double arrivalRate);
    double getArrivalMean() const;
    void setArrivalMean(double arrivalMean);
    double getArrivalVariance() const;
    void setArrivalVariance(double arrivalVariance);
};

typedef std::vector<ServiceBEnvironment> EnvironmentBVector;

#endif
