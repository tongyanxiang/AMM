/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include "ServiceBEnvironment.h"

ServiceBEnvironment::ServiceBEnvironment(): arrivalRate(0.0), arrivalMean(0.0), arrivalVariance(0.0) {}

ServiceBEnvironment::ServiceBEnvironment(double arrivalRate, double arrivalMean, double arrivalStdDev)
    :arrivalRate(arrivalRate), arrivalMean(arrivalMean), arrivalVariance(arrivalStdDev) {};

double ServiceBEnvironment::getArrivalRate() const {
    return arrivalRate;
}

void ServiceBEnvironment::setArrivalRate(double arrivalRate) {
    this->arrivalRate = arrivalRate;
}

double ServiceBEnvironment::getArrivalMean() const {
    return arrivalMean;
}

void ServiceBEnvironment::setArrivalMean(double arrivalMean) {
    this->arrivalMean = arrivalMean;
}

double ServiceBEnvironment::getArrivalVariance() const {
    return arrivalVariance;
}

void ServiceBEnvironment::setArrivalVariance(double arrivalVariance) {
    this->arrivalVariance = arrivalVariance;
}
