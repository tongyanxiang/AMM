/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <sstream>
#include <math.h>
#include <assert.h>
#include "managers/util/ServiceBUtils.h"
#include "managers/execution/ServiceBExecutionManager.h"
#include "ServiceBModel.h"

Define_Module(ServiceBModel);

void ServiceBModel::addExpectedServerChange(double time, ModelServerChange change) {
    ModelServerChangeEvent event;
    event.startTime = simTime().dbl();
    event.time = time;
    event.change = change;
    serverChangeEvents.insert(event);
}

void ServiceBModel::addServer(double bootDelay) {
    addExpectedServerChange(simTime().dbl() + bootDelay, ServiceBModel::SERVER_ONLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] addServer bootDelay=" << bootDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceBModel::removeServer(double offDelay) {
    addExpectedServerChange(simTime().dbl() + offDelay, ServiceBModel::SERVER_OFFLINE);

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] removeServer offDelay=" << offDelay
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceBModel::serverBecameActive() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceBModel::SERVER_ONLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server boot change for this
    serverChangeEvents.erase(it);

    activeServers++;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] serverBecameActive"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

void ServiceBModel::serverBecameShutDown() {
    /* remove expected change...*/
    ModelServerChangeEvents::iterator it = serverChangeEvents.begin();
    while (it != serverChangeEvents.end() && it->change != ServiceBModel::SERVER_OFFLINE) {
        it++;
    }

    assert(it != serverChangeEvents.end()); // there must be an expected server shutdown change for this
    serverChangeEvents.erase(it);

    activeServers--;

    if(cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] serverBecameShutDown"
                                  << " serverCount="       << getServers()
                                  << " active="            << activeServers
                                  << " numServerBooting="  << numServerBooting()
                                  << " numServerShutting=" << numServerShutting()
                                  << " expected="          << serverChangeEvents.size() << endl;
    }
}

int ServiceBModel::numServerBooting() const {
    int bootingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_ONLINE){
                bootingNum++;
            }
            eventIt++;
        }
   }
    return bootingNum;
}

int ServiceBModel::numServerShutting() const {
    int shuttingNum = 0;

    if (!serverChangeEvents.empty()){
        /* find the number of booting servers */
        ModelServerChangeEvents::const_iterator eventIt = serverChangeEvents.begin();
        while(eventIt != serverChangeEvents.end()) {
            if(eventIt->change == SERVER_OFFLINE){
                shuttingNum++;
            }
            eventIt++;
        }
   }
    return shuttingNum;
}

void ServiceBModel::pushServerPool(double time, int id) {
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] push server id=" << id << " time=" << time << endl;
    }

    ModelServerPoolEvent event;
    event.time = time;
    event.id = id;
    serverPoolEvents.insert(event);
}

int ServiceBModel::popServerPool() {
    int id = -1;
    if (!serverPoolEvents.empty()) {
        ModelServerPoolEvents::iterator it = serverPoolEvents.end();
        it--;
        id = it->id;
        serverPoolEvents.erase(it);
    }
    if (cmdenvLogging) {
        cout << "t=" << simTime() << " [ServiceBModel] pop id=" << id << " time=" << simTime().dbl() << endl;
    }

    return id;
}

std::vector<int> ServiceBModel::getServerPool() {
    serverModuleIds.clear();
    ModelServerPoolEvents::iterator it = serverPoolEvents.begin();
    while (it != serverPoolEvents.end()) {
        serverModuleIds.push_back(it->id);
        it++;
    }
    return serverModuleIds;
}

void ServiceBModel::initialize(int stage) {
    if (stage == 0) {

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

        // server config
        brownoutFactor = getParentModule()->par("brownoutFactor");

        // uncertainty
        bootDelay = ServiceBUtils::getMeanAndVarianceFromParameter(getParentModule()->par("bootDelay"));
        offDelay = ServiceBUtils::getMeanAndVarianceFromParameter(getParentModule()->par("offDelay"));

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBModel] initialize"
                                      << " brownoutFactor=" << brownoutFactor
                                      << " bootDelay="      << bootDelay
                                      << " offDelay="       << offDelay << endl;
        }
    } else {
        // initial servers
        ServiceBExecutionManager* pExecMgr = check_and_cast<ServiceBExecutionManager*> (getParentModule()->getSubmodule("executionManagerB"));

        cXMLElement *initialServersNode = getParentModule()->par("initialServersXML").xmlValue();
        int initialServers = atoi(initialServersNode->getNodeValue());

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceBModel] initialServers=" << initialServers << endl;
        }

        while (initialServers > 0) {
            pExecMgr->addServerLatencyOptional(true); // add a server instantaneously
            initialServers--;
        }
    }
}

// servers
double ServiceBModel::getBrownoutFactor() const {
    return brownoutFactor;
}

void ServiceBModel::setBrownoutFactor(double factor) {
    brownoutFactor = factor;
}

int const ServiceBModel::getServers() const {
    return activeServers + numServerBooting()-numServerShutting();
}

int const ServiceBModel::getActiveServers() const {
    return activeServers;
}

int ServiceBModel::getServerThreads() const {
    return serverThreads;
}

void ServiceBModel::setServerThreads(int serverThreads) {
    this->serverThreads = serverThreads;
}

double ServiceBModel::getServiceTimeMean() const {
    return serviceTimeMean;
}

void ServiceBModel::setServiceTime(double serviceTimeMean, double serviceTimeVariance) {
    this->serviceTimeMean = serviceTimeMean;
    this->serviceTimeVariance = serviceTimeVariance;
}

double ServiceBModel::getLowFidelityServiceTimeMean() const {
    return lowFidelityServiceTimeMean;
}

void ServiceBModel::setLowFidelityServiceTime(double lowFidelityServiceTimeMean, double lowFidelityServiceTimeVariance) {
    this->lowFidelityServiceTimeMean = lowFidelityServiceTimeMean;
    this->lowFidelityServiceTimeVariance = lowFidelityServiceTimeVariance;
}

// uncertainty
double ServiceBModel::getBootDelay() const {
    return bootDelay;
}

// utility
double ServiceBModel::getUtility() const {
    return utility;
}

void ServiceBModel::setUtility(double utility) {
    this->utility = utility;
}

// envrionement
const ServiceBEnvironment& ServiceBModel::getEnvironment() const {
    return environment;
}

void ServiceBModel::setEnvironment(const ServiceBEnvironment& environment) {
    this->environment = environment;
}

const ServiceBObservations& ServiceBModel::getObservations() const {
    return observations;
}

void ServiceBModel::setObservations(const ServiceBObservations& observations) {
    this->observations = observations;
}
