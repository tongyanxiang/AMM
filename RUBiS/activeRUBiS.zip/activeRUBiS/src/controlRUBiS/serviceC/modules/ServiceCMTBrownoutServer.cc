/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *  
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *  
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <fstream>
#include <iostream>
#include "ServiceCMTBrownoutServer.h"

Define_Module(ServiceCMTBrownoutServer);

#define SER_RNG 0
#define RNG 1
#define CACHING_EFFECT 0

std::map<long, long> ServiceCMTBrownoutServer::requestCount;

void ServiceCMTBrownoutServer::initialize() {

    serverCBusySignal = registerSignal("serverCBusy");
    emit(serverCBusySignal, false);

    serverCServiceTimeSignal = registerSignal("serverCServiceTime");

    endExecutionMsg = new cMessage("end-execution");

    selectionStrategy = SelectionStrategy::create(par("fetchingAlgorithm"), this, true);
    if (!selectionStrategy)
        error("invalid selection strategy");

    // logging
    cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging").boolValue();

    // servers
    maxThreads = par("threads");
    timeout = par("timeout").doubleValue();

    cacheLow = par("cacheLow");
    cacheRequestCount = par("cacheRequestCount");
    cacheDelta = par("cacheDelta");
    cacheDeltaLow = par("cacheDeltaLow");
    cachePrecision = par("cachePrecision");
    cacheClearsWhenReboot = par("cacheClearsWhenReboot");

//    if(cmdenvLogging) {
//        cout << "t=" << simTime() << " [ServiceCMTBrownoutServer] initialize"
//                                  << " maxThreads="            << maxThreads
//                                  << " timeout="               << timeout
//                                  << " cacheLow="              << cacheLow
//                                  << " cacheRequestCount="     << cacheRequestCount
//                                  << " cacheDelta="            << cacheDelta
//                                  << " cacheDeltaLow="         << cacheDeltaLow
//                                  << " cachePrecision="        << cachePrecision
//                                  << " cacheClearsWhenReboot=" << cacheClearsWhenReboot << endl;
//    }

    // model deviation
    cXMLElement *deviationServiceModuleNode = getSimulation()->getSystemModule()->par("deviationServiceModuleXML").xmlValue();
    deviationServiceModule = string(deviationServiceModuleNode->getNodeValue());

    cXMLElement *deviationModeNode = getSimulation()->getSystemModule()->par("deviationModeXML").xmlValue();
    deviationMode = string(deviationModeNode->getNodeValue());

    if (deviationServiceModule == "serviceC" && deviationMode == "longterm_drift") {

        cXMLElement *BOffsetPercentNode = getSimulation()->getSystemModule()->par("BOffsetPercentXML").xmlValue();
        BOffsetPercent = atof(BOffsetPercentNode->getNodeValue());

        cXMLElement *periodNode = getSimulation()->getSystemModule()->par("periodXML").xmlValue();
        period = atof(periodNode->getNodeValue());

        if (cmdenvLogging) {
            cout << "t=" << simTime() << " [ServiceCMTBrownoutServer] initialize"
                                      << " deviationMode="          << deviationMode
                                      << " deviationServiceModule=" << deviationServiceModule
                                      << " BOffsetPercent="         << BOffsetPercent
                                      << " period="                 << period << endl;
        }

        // tracing
        deviationFilePath = "../traces/serviceCServiceTimeTrace.txt";

        // delete old deviation trace file
        ifstream cpFin(deviationFilePath.c_str());
        if (!cpFin) {
            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCMTBrownoutServer] " << deviationFilePath << " does not exist" << endl;
            }
        } else {
            remove(deviationFilePath.c_str());

            if (cmdenvLogging) {
                cout << "t=" << simTime() << " [ServiceCMTBrownoutServer] Delete " << deviationFilePath << endl;
            }
        }

        // first line of deviation trace file
        ofstream out;
        out.open(deviationFilePath.c_str(), ios::app);
        if (out.is_open()) {
            out << "simTime,";
            out << "serviceTimeMean,";
            out << "serviceTimeSigma,";
            out << "driftServiceTimeMean,";
            out << "serviceTimeSigma,";
            out << "serviceTimeDouble\n";
            out.close();
        }

    }

}

void ServiceCMTBrownoutServer::handleMessage(cMessage* msg) {
    if (msg == endExecutionMsg) {
        ASSERT(!runningJobs.empty());
        updateJobTimes();

        // send out all jobs that completed
        RunningJobs::iterator first = runningJobs.begin();
        while (first != runningJobs.end() && first->remainingServiceTime < 1e-10) {

            // send it to serverMonitor
            send(first->pJob, "out");

            runningJobs.erase(first);
            first = runningJobs.begin();
        }

        if (!runningJobs.empty()) {
            scheduleNextCompletion();
        } else {
            emit(serverCBusySignal, false);
            if (hasGUI()) getDisplayString().setTagArg("i",1,"");
        }
    }
    else { // arrival jobs
        if (!isIdle())
            error("job arrived while already full");

        ScheduledJob job;
        job.pJob = check_and_cast<Job*>(msg);

        if (timeout > 0 && job.pJob->getTotalQueueingTime() >= timeout) {
            // don't serve this job, just send it out
            send(job.pJob, "out");
         } else {
            job.remainingServiceTime = generateJobServiceTime(job.pJob).dbl();

            // these two are nops if there was no job running
            updateJobTimes();
            cancelEvent(endExecutionMsg);

            runningJobs.push_back(job);
            runningJobs.sort();
            scheduleNextCompletion();

            if (runningJobs.size() == 1) { // going from idle to busy
                emit(serverCBusySignal, true);
                if (hasGUI()) getDisplayString().setTagArg("i",1,"cyan");
            }
        }
    }

    if (runningJobs.size() < maxThreads) {
        // examine all input queues, and request a new job from a non empty queue (multi-queues and multi-servers)
        int k = selectionStrategy->select();
        if (k >= 0) {
            cGate *gate = selectionStrategy->selectableGate(k);
            check_and_cast<IPassiveQueue *>(gate->getOwnerModule())->request(gate->getIndex());
        }
    }
}

void ServiceCMTBrownoutServer::scheduleNextCompletion() {
    // schedule next completion event
    RunningJobs::iterator first = runningJobs.begin();
    scheduleAt(simTime() + first->remainingServiceTime*runningJobs.size(), endExecutionMsg);
}

void ServiceCMTBrownoutServer::updateJobTimes() {
    simtime_t d = simTime() - endExecutionMsg->getSendingTime();

    // update service time and remaining time of all jobs
    for (RunningJobs::iterator it = runningJobs.begin(); it != runningJobs.end(); ++it) {
        it->remainingServiceTime -= d.dbl()/runningJobs.size(); // as if it was not sharing the processor
        it->pJob->setTotalServiceTime(it->pJob->getTotalServiceTime() + d);
    }
}

simtime_t ServiceCMTBrownoutServer::generateJobServiceTime(queueing::Job* pJob) {
    double brownoutFactor = par("brownoutFactor");
    double u = uniform(0, 1, RNG);
    simtime_t st = 0;

    if (u >= brownoutFactor) {
        simtime_t serviceTime = par("serviceTime");
        if (serviceTime <= 0.0) {
            serviceTime = 1e-10; // make it a very short job
        }

        // model deviation: normal or longterm_drift
        if (deviationServiceModule == "serviceC" && deviationMode == "longterm_drift") {
            double secondTime = simTime().dbl();
            double driftServiceTimeMean = BOffsetPercent * serviceTimeMean * sin((2 * PI / period) * secondTime) + serviceTimeMean;

            double serviceTimeDouble = truncnormal(driftServiceTimeMean, serviceTimeSigma, SER_RNG);
            serviceTime = serviceTimeDouble;

            ofstream out;
            out.open(deviationFilePath.c_str(), ios::app);
            if (out.is_open()) {
                out << secondTime;
                out << ",";
                out << serviceTimeMean;
                out << ",";
                out << serviceTimeSigma;
                out << ",";
                out << driftServiceTimeMean;
                out << ",";
                out << serviceTimeSigma;
                out << ",";
                out << serviceTimeDouble;
                out << "\n";
                out.close();
            }

        }

        st = serviceTime;

    } else {
        pJob->setKind(1); // mark the job as low fidelity
        simtime_t serviceTime = par("lowFidelityServiceTime");
        if (serviceTime <= 0.0) {
            serviceTime = 1e-10; // make it a very short job
        }
        st = serviceTime;
    }

#if CACHING_EFFECT
    // exponential decay (simulate caching)
    if (cacheLow || pJob->getKind() != 1) {
        double delta = (pJob->getKind() == 1) ? cacheDeltaLow : cacheDelta;
        double lambda = (-1.0 / cacheRequestCount) * (log(cachePrecision * delta) - log(delta));

        long myRequestCount = requestCount[this->getParentModule()->getId()];
        st += delta * exp(-lambda * myRequestCount);
        requestCount[this->getParentModule()->getId()] = ++myRequestCount;
    }
#endif

    emit(serverCServiceTimeSignal, (pJob->getKind() == 1) ? -st.dbl() : st.dbl());

    return st;
}

ServiceCMTBrownoutServer::ServiceCMTBrownoutServer() : endExecutionMsg(NULL), selectionStrategy(NULL), maxThreads(0) {
}

ServiceCMTBrownoutServer::~ServiceCMTBrownoutServer() {
    cancelAndDelete(endExecutionMsg);
    delete selectionStrategy;
    for (RunningJobs::iterator it = runningJobs.begin(); it != runningJobs.end(); ++it) {
        delete it->pJob;
    }
}

void ServiceCMTBrownoutServer::clearServerCache() {
    if (cacheClearsWhenReboot) {
        requestCount[this->getParentModule()->getId()] = 0;
    }
}

bool ServiceCMTBrownoutServer::isIdle() {
    return runningJobs.size() < maxThreads;
}

bool ServiceCMTBrownoutServer::isEmpty() {
    return runningJobs.size() == 0;
}

void ServiceCMTBrownoutServer::allocate() {
}
