/*******************************************************************************
 * Simulator of Web Infrastructure and Management
 * Copyright (c) 2016 Carnegie Mellon University.
 * All Rights Reserved.
 *
 * THIS SOFTWARE IS PROVIDED "AS IS," WITH NO WARRANTIES WHATSOEVER. CARNEGIE
 * MELLON UNIVERSITY EXPRESSLY DISCLAIMS TO THE FULLEST EXTENT PERMITTED BY LAW
 * ALL EXPRESS, IMPLIED, AND STATUTORY WARRANTIES, INCLUDING, WITHOUT
 * LIMITATION, THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, AND NON-INFRINGEMENT OF PROPRIETARY RIGHTS.
 *
 * Released under a BSD license, please see license.txt for full terms.
 * DM-0003883
 *******************************************************************************/

#include <set>
#include <iostream>
#include <fstream>
#include "managers/execution/ServiceCExecutionManager.h"
#include "ServiceCSimProbe.h"

Define_Module(ServiceCSimProbe);

void ServiceCSimProbe::initialize(int stage) {
    if (stage == 1) {

        pModel = check_and_cast<ServiceCModel*>(getParentModule()->getSubmodule("modelC"));

        // logging
        cmdenvLogging = getSimulation()->getSystemModule()->par("cmdenvLogging");

        // control
        controlPeriod = getParentModule()->par("controlPeriod").doubleValue();

        /* register arrivalMonitor signals */
        serviceCInterArrivalSignal = registerSignal("serviceCInterArrival");
        getSimulation()->getSystemModule()->subscribe(serviceCInterArrivalSignal, this);

        /* register server signals */
        serverCServiceTimeSignal = registerSignal("serverCserviceTime");
        getSimulation()->getSystemModule()->subscribe(serverCServiceTimeSignal, this);

        /* register sinkMonitor signals */
        serviceCLifeTimeSignal = registerSignal("serviceCLifeTime");
        getSimulation()->getSystemModule()->subscribe(serviceCLifeTimeSignal, this);

        /* subscribed server state signals */
        serverCBusySignal = registerSignal("serverCBusy");
        getSimulation()->getSystemModule()->subscribe(serverCBusySignal, this);

        serverCRemovedSignal = registerSignal("serverCRemoved");
        getSimulation()->getSystemModule()->subscribe(serverCRemovedSignal, this);

        window = controlPeriod;
        arrival.setWindow(window);
        basicServiceTime.setWindow(window);
        optServiceTime.setWindow(window);;
        basicResponseTime.setWindow(window);
        optResponseTime.setWindow(window);
        responseTime.setWindow(window);
    }
}

void ServiceCSimProbe::receiveSignal(cComponent *source, simsignal_t signalID, const SimTime& t, cObject *details) {
    if (signalID == serviceCLifeTimeSignal) {
        responseTime.record(t.dbl()); //windows for saving all basic and opt responseTime
        bool basic = (strcmp(source->getName(), "sinkMonitorLowC") == 0);
        if (basic) {
            basicResponseTime.record(t.dbl());
        } else {
            optResponseTime.record(t.dbl());
       }
    }
}

void ServiceCSimProbe::receiveSignal(cComponent *source, simsignal_t signalID, double value, cObject *details) {
    if (signalID == serviceCInterArrivalSignal) {
        arrival.record(value);
    } else if (signalID == serverCServiceTimeSignal){
        if (value <= 0.0) {
            basicServiceTime.record(value);
        } else {
            optServiceTime.record(value);
        }
    }
}

void ServiceCSimProbe::receiveSignal(cComponent *source, simsignal_t signalID, bool value, cObject *details) {
    if (signalID == serverCBusySignal) {
        std::string serverName = source->getParentModule()->getName(); // because it is nested

        auto it = utilization.find(serverName);
        if (it != utilization.end()) {
            it->second.record((value) ? 1.0 : 0.0); // busy vs idle
        } else {
            /*
             * a new server emits a busy=false signal when it is initialized.
             * It should not be recorded for a new server because it then
             * throws off the sliding window avg utilization computation
             */
            if (value) {
                auto& util = utilization[serverName];
                util.setWindow(window);
                util.record(1.0); // busy
            }
        }
    }
}

void ServiceCSimProbe::receiveSignal(cComponent *source, simsignal_t signalID, const char* value, cObject *details) {
    if (signalID == serverCRemovedSignal) {
        auto it = utilization.find(value);
        if (it != utilization.end()) {
            utilization.erase(it);
        }
    }
}

double ServiceCSimProbe::getUtilization(const std::string& serverName) {
    auto it = utilization.find(serverName);
    if (it != utilization.end()) {
        return it->second.getPercentageAboveZero();
    }

    return -1.0; // error: server not found
}

void ServiceCSimProbe::handleMessage(cMessage *msg) {
}

ServiceCObservations ServiceCSimProbe::getUpdatedObservations() {
    ServiceCObservations obs;

    obs.basicResponseTime = basicResponseTime.getAverage();
    obs.basicThroughput = basicResponseTime.getRate();
    obs.optResponseTime = optResponseTime.getAverage();
    obs.optThroughput = optResponseTime.getRate();
    obs.avgResponseTime = (obs.basicResponseTime*obs.basicThroughput + obs.optResponseTime*obs.optThroughput)/(obs.basicThroughput + obs.optThroughput);

    double util = 0;
    for (auto& entry : utilization) {
        util += entry.second.getPercentageAboveZero();
    }
    obs.utilization = util/pModel->getActiveServers();

    return obs;
}

ServiceCEnvironment ServiceCSimProbe::getUpdatedEnvironment() {
    double arrivalRate = arrival.getRate();
    double measuredMeanInterArrival = (arrivalRate > 0) ? (1.0/arrivalRate) : 0.0;

    ServiceCEnvironment environment;
    environment.setArrivalRate(arrivalRate);
    environment.setArrivalMean(measuredMeanInterArrival);
    environment.setArrivalVariance(pow(measuredMeanInterArrival, 2)); // assume exponential distribution

    return environment;
}
