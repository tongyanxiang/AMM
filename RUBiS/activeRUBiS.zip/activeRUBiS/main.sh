#!/bin/bash

cd ~/omnetpp-6.0/samples/activeRUBiS/simulations/rubisPIC

../../src/rubis -m -u Cmdenv -n ..:../../src:../../../queueinglib -l ../../../queueinglib/queueinglib rubisPIC.ini
