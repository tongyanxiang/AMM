#include "Injector.hpp"

Injector::Injector(int  &argc, char **argv, const std::string &name) : ROSComponent(argc, argv, name) {}

Injector::~Injector() {}

void Injector::setUp() {
    // Get start time from physicalTimer.txt writen in script
    std::string timer_path = ros::package::getPath("injector") + "/../../physicalTimer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
       std::cerr << "[setUp] Could not read physicalTimer.txt!\n"; 
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;

    // Service
    sensorNodeStartServer = nh.advertiseService("getSensorNodeStartData", &Injector::getSensorNodeStartData, this);
    sensorNodeUpdatedServer = nh.advertiseService("getSensorNodeUpdateData", &Injector::getSensorNodeUpdateData, this);

    // Get and set configs
    nh.getParam("/injector/random_seed", random_seed);

    double freq;
    nh.getParam("/injector/frequency", freq);
    rosComponentDescriptor.setFreq(freq);
    std::cout << "[setUp] frequency=" << freq << std::endl;

    int factor;
    nh.getParam("/injector/acceleration_factor", factor);
    rosComponentDescriptor.setAccelerationFactor(factor);
    std::cout << "[setUp] acceleration_factor=" << factor << std::endl;

    std::string comps;
    nh.getParam("/injector/components", comps);
    components = bsn::utils::split(comps, ',');

    // Initialize the iteration variable
    seed_count = 0;
    iteration = 0;
    targetInteration = 1;
    for (std::vector<std::string>::iterator component = components.begin(); component != components.end(); ++component){

        sensorPublisher[*component] = nh.advertise<messages::InjectorData>("InjectData_"+*component, 100);
        std::cout << "[setUp] Defining publisher " << *component << std::endl;

        // Initialize sensors' freqs
        int compFreq;
        nh.getParam("/injector/" + (*component) + "/startFreq", compFreq);
        sensorFreq[*component] = compFreq;
        sensorIterations[*component] = iteration;

        // Configurations: offset
        nh.getParam("/injector/" + (*component) + "/offset", offset[*component]); 
        std::cout << "[setUp] offset=" << offset[*component] << std::endl;

        // Configurations: amplitude
        std::string amplitude_str;
        nh.getParam("/injector/" + (*component) + "/amplitudeRange", amplitude_str);

        std::vector<std::string> amplitudePair = bsn::utils::split(amplitude_str, ',');
        double amplitudeStart = stod(amplitudePair[0]);
        double amplitudeEnd = stod(amplitudePair[1]);

        std::uniform_real_distribution<double> amplitudeGenerator(amplitudeStart, amplitudeEnd);
        std::mt19937 amplitudeRNG;
        if (random_seed == -1) {
            std::random_device rd;
            amplitudeRNG.seed(rd());
            
        } else if (random_seed >= 0) {
            amplitudeRNG.seed(10000 + seed_count*1000 + random_seed);
        }

        amplitude[*component] = amplitudeGenerator(amplitudeRNG);
        std::cout << "[setUp] amplitude=" << amplitude[*component] << std::endl;

        // Configurations: sigma
        nh.getParam("/injector/" + (*component) + "/sigma", sigma[*component]); 
        std::cout << "[setUp] sigma=" << sigma[*component] << std::endl;

        // Configurations: durationLow
        std::string durationLow_str;
        nh.getParam("/injector/" + (*component) + "/durationRangeLow", durationLow_str);

        std::vector<std::string> durationLowPair = bsn::utils::split(durationLow_str, ',');
        int durationLowStart = stoi(durationLowPair[0]);
        int durationLowEnd = stoi(durationLowPair[1]);

        std::uniform_int_distribution<int> durationLowGenerator(durationLowStart, durationLowEnd);
        std::mt19937 durationLowRNG;
        if (random_seed == -1) {
            std::random_device rd;
            durationLowRNG.seed(rd());
            
        } else if (random_seed >= 0) {
            durationLowRNG.seed(20000 + seed_count*1000 + random_seed);
        }

        durationLow[*component] = durationLowGenerator(durationLowRNG);
        std::cout << "[setUp] durationLow=" << durationLow[*component] << std::endl;

        // Configurations: durationHigh
        std::string durationHigh_str;
        nh.getParam("/injector/" + (*component) + "/durationRangeHigh", durationHigh_str);

        std::vector<std::string> durationHighPair = bsn::utils::split(durationHigh_str, ',');
        int durationHighStart = stoi(durationHighPair[0]);
        int durationHighEnd = stoi(durationHighPair[1]);

        std::uniform_int_distribution<int> durationHighGenerator(durationHighStart, durationHighEnd);
        std::mt19937 durationHighRNG;
        if (random_seed == -1) {
            std::random_device rd;
            durationHighRNG.seed(rd());
            
        } else if (random_seed >= 0) {
            durationHighRNG.seed(30000 + seed_count*1000 + random_seed);
        }

        durationHigh[*component] = durationHighGenerator(durationHighRNG);
        std::cout << "[setUp] durationHigh=" << durationHigh[*component] << std::endl;

        // Configurations: ramp
        std::string ramp_str;
        nh.getParam("/injector/" + (*component) + "/rampRange", ramp_str);

        std::vector<std::string> rampPair = bsn::utils::split(ramp_str, ',');
        int rampStart = stoi(rampPair[0]);
        int rampEnd = stoi(rampPair[1]);

        std::uniform_int_distribution<int> rampGenerator(rampStart, rampEnd);
        std::mt19937 rampRNG;
        if (random_seed == -1) {
            std::random_device rd;
            rampRNG.seed(rd());
            
        } else if (random_seed >= 0) {
            rampRNG.seed(40000 + seed_count*1000 + random_seed);
        }

        ramp[*component] = rampGenerator(rampRNG);
        std::cout << "[setUp] ramp=" << ramp[*component] << std::endl;

        // Configurations: begin
        std::string begin_str;
        nh.getParam("/injector/" + (*component) + "/beginRange", begin_str);

        std::vector<std::string> beginPair = bsn::utils::split(begin_str, ',');
        int beginStart = stoi(beginPair[0]);
        int beginEnd = stoi(beginPair[1]);

        std::uniform_int_distribution<int> beginGenerator(beginStart, beginEnd);
        std::mt19937 beginRNG;
        if (random_seed == -1) {
            std::random_device rd;
            beginRNG.seed(rd());
            
        } else if (random_seed >= 0) {
            beginRNG.seed(60000 + seed_count*1000 + random_seed);
        }

        begin[*component] = beginGenerator(beginRNG);
        std::cout << "[setUp] begin=" << begin[*component] << std::endl;

        // Evaluation
        injectorData[*component] = configureNoiseGenerator(*component);
        seed_count += 1;
    }

    // Cope with the delay on opening the connection
    int sensorConnectionNum = 0;
    while(sensorConnectionNum < 6) {
        sensorConnectionNum = 0;
        for (std::vector<std::string>::iterator component = components.begin(); component != components.end(); ++component){  
            if (sensorPublisher[*component].getNumSubscribers() > 0) {
                sensorConnectionNum += 1;
            }            
        }     
        // std::cout << "[setUp] sensorConnectionNum=" << sensorConnectionNum << std::endl;
    }
    std::cout << "[setUp] All sensors have connected." << std::endl;

    // Tracing 
    nh.getParam("/injector/data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("injector") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        injector_g3t1_1_filepath = trace_dir + "/injector_g3t1_1_factor_trace.txt";
        fp.open(injector_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();

        injector_g3t1_2_filepath = trace_dir + "/injector_g3t1_2_factor_trace.txt";
        fp.open(injector_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();

        injector_g3t1_3_filepath = trace_dir + "/injector_g3t1_3_factor_trace.txt";
        fp.open(injector_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();

        injector_g3t1_4_filepath = trace_dir + "/injector_g3t1_4_factor_trace.txt";
        fp.open(injector_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();

        injector_g3t1_5_filepath = trace_dir + "/injector_g3t1_5_factor_trace.txt";
        fp.open(injector_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();

        injector_g3t1_6_filepath = trace_dir + "/injector_g3t1_6_factor_trace.txt";
        fp.open(injector_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),component,[stepNum,offset,amplitude,sigma,durationLow,durationHigh,ramp,begin],sensorFreq,injector_factor\n";
        fp.close();
    }
}

bsn::generator::NoiseGenerator Injector::configureNoiseGenerator(const std::string &component) {
    std::array<std::normal_distribution<double>,2> valueGenerators;

    // Value generators
    valueGenerators[0] = std::normal_distribution<double> (offset[component], sigma[component]);
    valueGenerators[1] = std::normal_distribution<double> (amplitude[component], sigma[component]);

    // Random  
    std::mt19937 rng;
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        int data_seed = 60000 + 1000*seed_count + random_seed;
        rng.seed(data_seed);
    }
    
    bsn::generator::NoiseGenerator noiseGenerator(component, 
                                                  offset[component], 
                                                  amplitude[component], 
                                                  durationLow[component], 
                                                  durationHigh[component], 
                                                  ramp[component], 
                                                  begin[component], 
                                                  valueGenerators, rng);

    return noiseGenerator;
}

void Injector::tearDown() {}

void Injector::body() {
    // Restart
    physicalTimestamp = this->nowInMilliSecond() - time_ref;
    if (iteration == 0) {
        timer = timer_old = physicalTimestamp;
    } else{
        timer = physicalTimestamp;
    }

    int delta_time = timer - timer_old;
    if (delta_time > timeInterval) {
        std::cout << "[body] Error from injector.\n";

        std::string restart_path = ros::package::getPath("injector") + "/../../restart.txt";
        fp.open(restart_path, std::fstream::in | std::fstream::out);   
        fp << 1 << "\n";
        fp.close();
    }

    if(sensorStarted.size() < 6)
        return;
    if(iteration >= targetInteration)
        return;
    std::cout << "[body] Check sensors' status.\n";

    for(auto i : sensorStarted){
        if(!i.second){
            std::cout << "[body] Sensor " << i.first << " status is not ready!\n";
            return;
        }   
    }
    std::cout << "[body] All 6 sensors are ready.\n";

    // Wait for all the subscribers to subscribe
    int sensorConnectionNum = 0;
    while(sensorConnectionNum < 6) {
        sensorConnectionNum = 0;
        for (std::vector<std::string>::iterator component = components.begin(); component != components.end(); ++component){  
            if (sensorPublisher[*component].getNumSubscribers() > 0) {
                sensorConnectionNum += 1;
            }            
        }     
    }
    std::cout << "[body] All sensors have connected.\n";

    // Generate inputData
    if(iteration < targetInteration){
        for(auto it = components.begin(); it != components.end(); ++it){

            int senserNum = 0;
            if(sensorStarted.find(*it) != sensorStarted.end() && sensorStarted[*it]){
                messages::InjectorData msg;
                msg.component = *it;
                msg.sensorFreq = sensorFreq[*it];
                msg.iteration = iteration + 1;
                
                for(auto i = 0; i < sensorFreq[*it]; i++){
                    int tempLogicalTimestamp = iteration * 1000 + 1000.0*(i+1) / sensorFreq[*it];
                    logicalTimestamp = tempLogicalTimestamp;
                    logicalTimestamps[*it] = tempLogicalTimestamp;
                    msg.timeData.push_back(tempLogicalTimestamp);

                    double inputData = injectorData[*it].gen_noise(logicalTimestamps[*it]);
                    msg.data.push_back(inputData);
                  
                    std::cout << "[t=" << logicalTimestamps[*it] << "] Generate inputData=" << inputData << ", size=" << msg.data.size() << std::endl;

                    // Tracing
                    if (data_tracing) {         
                        physicalTimestamp = this->nowInMilliSecond() - time_ref;
                             
                        if (*it == "g3t1_1") {fp.open(injector_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                        if (*it == "g3t1_2") {fp.open(injector_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                        if (*it == "g3t1_3") {fp.open(injector_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                        if (*it == "g3t1_4") {fp.open(injector_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                        if (*it == "g3t1_5") {fp.open(injector_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                        if (*it == "g3t1_6") {fp.open(injector_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

                        int stepNum = injectorData[*it].getStepNum();

                        fp << ceil(logicalTimestamps[*it]/1000.0) << ","; 
                        fp << logicalTimestamps[*it] << ",";
                        fp << ceil(physicalTimestamp/1000.0) << ","; 
                        fp << physicalTimestamp << ",";
                        fp << *it << ",";  
                        fp << "[" 
                           << stepNum << "," 
                           << offset[*it] << "," 
                           << amplitude[*it] << "," 
                           << sigma[*it] << "," 
                           << durationLow[*it] << "," 
                           << durationHigh[*it] << "," 
                           << ramp[*it] << "," 
                           << begin[*it] 
                           << "],";      
                        fp << sensorFreq[*it] << ",";     
                        fp << inputData << "\n";      
                        fp.close();    
                    }
                }

                sensorPublisher[*it].publish(msg);
                std::cout << "[t=" << logicalTimestamps[*it] << "] Send injector data to sensor=" << *it << ", size=" << msg.data.size() << std::endl;

                // Restart
                timer_old = timer;
            }

        }
        
        iteration ++;
    }
}

bool Injector::getSensorNodeStartData(services::SensorNodeStartData::Request &request, services::SensorNodeStartData::Response &response){
    std::string component = request.component;
    bool started = request.started;
    
    if(started){
        sensorStarted[component] = true;
        // Publisher for the random input genertor
    }
        
    response.ok = true;
}

bool Injector::getSensorNodeUpdateData(services::SensorNodeUpdateData::Request &request, services::SensorNodeUpdateData::Response &response){
    std::string component = request.component;
    sensorIterations[request.component] = request.iteration;
    sensorFreq[request.component] = request.sensorFreq;
    bool iterationFinished = true;

    std::cout << "[t=" << logicalTimestamps[request.component] << "] Received SensorNodeUpdateData component=" << request.component << ", iteration=" << request.iteration << ", freq=" << request.sensorFreq << std::endl;

    // Check wether all sensors are updated
    for(const auto& it : sensorIterations){
        if(sensorIterations[it.first] != targetInteration){
            iterationFinished = false;
            break;
        }
    }

    if(iterationFinished){
        targetInteration ++;
    }
}