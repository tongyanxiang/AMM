#ifndef INJECTOR_HPP
#define INJECTOR_HPP

#include <fstream>    
#include <sys/stat.h>

#include "ros/package.h"
#include "services/SensorNodeStartData.h"
#include "services/SensorNodeUpdateData.h"
#include "messages/InjectorData.h"

#include "libbsn/utils/utils.hpp"
#include "libbsn/generator/NoiseGenerator.hpp"

#include "archlib/ROSComponent.hpp"

class Injector : public arch::ROSComponent {

	public:
    	Injector(int &argc, char **argv, const std::string &name);
    	virtual ~Injector();

		virtual void setUp();
		virtual void tearDown();
		virtual void body();

    private:
      	Injector(const Injector &);
    	Injector &operator=(const Injector &);

		int64_t seconds_in_cycles(const double &seconds);

		// Evaluation
        int random_seed;     
        int seed_count;      
		std::map<std::string, int> logicalTimestamps;
		std::map<std::string, int> sensorFreq;

		// Tracing
        bool data_tracing;

        std::fstream fp;
        std::string injector_g3t1_1_filepath, injector_g3t1_2_filepath, injector_g3t1_3_filepath;
        std::string injector_g3t1_4_filepath, injector_g3t1_5_filepath, injector_g3t1_6_filepath;

		bool getSensorNodeStartData(services::SensorNodeStartData::Request &request, services::SensorNodeStartData::Response &response);
		bool getSensorNodeUpdateData(services::SensorNodeUpdateData::Request &request, services::SensorNodeUpdateData::Response &response);
		
		// Mark when all the sensors are started
		bsn::generator::NoiseGenerator configureNoiseGenerator(const std::string& component);

        std::map<std::string, bsn::generator::NoiseGenerator> injectorData;

		ros::NodeHandle nh;
		ros::ServiceServer sensorNodeStartServer;
		ros::ServiceServer sensorNodeUpdatedServer;

		// The pubilsher of the random input for the sensors
		std::map<std::string, ros::Publisher> sensorPublisher;
		
		// Iteration record
		int iteration;
		int targetInteration;

		// Record the iteration of the sensors
		std::map<std::string, int> sensorIterations;

		// Record the start situation of the sensors
		std::map<std::string, bool> sensorStarted;
		std::vector<std::string> components;
		std::map<std::string, double> injectorFactor;

		// Configurations
		std::map<std::string, double> offset;
		std::map<std::string, double> amplitude;
		std::map<std::string, double> sigma;
		std::map<std::string, int> durationLow;
		std::map<std::string, int> durationHigh;
		std::map<std::string, int> ramp;
		std::map<std::string, int> begin;

		// Restart
		int timeInterval = 20*1000; 
		int timer_old;
		int timer;
};

#endif 