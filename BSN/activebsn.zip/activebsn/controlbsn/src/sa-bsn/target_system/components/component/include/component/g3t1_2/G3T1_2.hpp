#ifndef G3T1_2_HPP
#define G3T1_2_HPP

#include "services/PatientData.h"
#include "services/SensorNodeStartData.h"
#include "messages/InjectorData.h"
#include "messages/SensorData.h"

#include "libbsn/range/Range.hpp"
#include "libbsn/generator/Markov.hpp"
#include "libbsn/generator/DataGenerator.hpp"
#include "libbsn/filters/MovingAverage.hpp"
#include "libbsn/configuration/SensorConfiguration.hpp"

#include "component/Sensor.hpp"

class G3T1_2 : public Sensor {
    
  	public:
	    G3T1_2(int &argc, char **argv, const std::string &name);
    	~G3T1_2();

	private:
      	G3T1_2(const G3T1_2 &);
    	G3T1_2 &operator=(const G3T1_2 &);

		std::string label(double &risk);

	public:
    	void setUp();
    	void tearDown();

        double collect();
        double process(const double &data);
        void transfer(const double &data);
        
		// Get input data from injector
		void collectInputData(const messages::InjectorData::ConstPtr& msg);

  	private:
        // Tracing
        bool data_tracing;
        int sensorFreq;

        std::fstream fp;
        std::string g3t1_filepath;

		bsn::generator::Markov markov;
		bsn::generator::DataGenerator dataGenerator;
		bsn::filters::MovingAverage filter;
		bsn::configuration::SensorConfiguration sensorConfig;

		ros::NodeHandle nh;
		ros::Publisher data_pub;
		ros::ServiceClient client;
		ros::Subscriber dataInitialization;
		
		double collected_risk;
};

#endif 