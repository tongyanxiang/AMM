#include "component/g4t1/G4T1.hpp"
#define W(x) std::cerr << #x << " = " << x << std::endl;

#define BATT_UNIT 0.001

using namespace bsn::processor;

G4T1::G4T1(int &argc, char **argv, const std::string &name) : lost_packt(false),
    CentralHub(argc, argv, name, true, bsn::resource::Battery("ch_batt", 100, 100, 1) ),
    patient_status(0.0) {}
	
G4T1::~G4T1() {}

std::vector<std::string> G4T1::getPatientStatus() {
    std::string sensor_risk_str;
    std::string oxi;
    std::string ecg;
    std::string trm;
    std::string abpd;
    std::string abps;
    std::string glc;

    for (int i = 0; i < 6; i++) {
        double sensor_risk = data_buffer[i].back();

        if (sensor_risk > 0 && sensor_risk <= 20) {
            sensor_risk_str = "low risk";
        } else if (sensor_risk > 20 && sensor_risk <= 65) {
            sensor_risk_str = "moderate risk";
        } else if (sensor_risk > 65 && sensor_risk <= 100) {
            sensor_risk_str = "high risk";
        } else {
            sensor_risk_str = "unknown";
        }

        // oxigenation, heart_rate, temperature, abps, abpd, glucose
        if (i == 0) {
            oxi = sensor_risk_str;
            oxi_risk = sensor_risk;
        } else if (i == 1) {
            ecg = sensor_risk_str;
            ecg_risk = sensor_risk;
        } else if (i == 2) {
            trm = sensor_risk_str;
            trm_risk = sensor_risk;
        } else if (i == 3) {
            abps = sensor_risk_str;
            abps_risk = sensor_risk;
        } else if (i == 4) {
            abpd = sensor_risk_str;
            abpd_risk = sensor_risk;
        } else if (i == 5) {
            glc = sensor_risk_str;
            glc_risk = sensor_risk;
        }
    }

    std::vector<std::string> v = {oxi, ecg, trm, abps, abpd, glc};  
    return v;
}

void G4T1::setUp() {
    // Get start time from physicalTimer.txt writen in script
    std::string timer_path = ros::package::getPath("component") + "/../../../physicalTimer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        std::cerr << "[setUp] Could not read physicalTimer.txt!\n"; 
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;
    
    Component::setUp();

    ros::NodeHandle config;

    double freq;
    config.getParam("frequency", freq);
    rosComponentDescriptor.setFreq(freq);
    std::cout << "[setUp] frequency=" << freq << std::endl;

    for (std::vector<std::list<double>>::iterator it = data_buffer.begin();
        it != data_buffer.end(); ++it) {
            (*it) = {0.0};
    }

    pub = config.advertise<messages::TargetSystemData>("TargetSystemData", 100);

    // Tracing 
    config.getParam("data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("component") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        g4t1_g3t1_1_filepath = trace_dir + "/component_g4t1_g3t1_1_trace.txt";
        fp.open(g4t1_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,oxi_freq,oxi_data,oxi_risk,oxi_batt\n";
        fp.close();

        g4t1_g3t1_2_filepath = trace_dir + "/component_g4t1_g3t1_2_trace.txt";
        fp.open(g4t1_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,ecg_freq,ecg_data,ecg_risk,ecg_batt\n";
        fp.close();

        g4t1_g3t1_3_filepath = trace_dir + "/component_g4t1_g3t1_3_trace.txt";
        fp.open(g4t1_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,trm_freq,trm_data,trm_risk,trm_batt\n";
        fp.close();

        g4t1_g3t1_4_filepath = trace_dir + "/component_g4t1_g3t1_4_trace.txt";
        fp.open(g4t1_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,abps_freq,abps_data,abps_risk,abps_batt\n";
        fp.close();

        g4t1_g3t1_5_filepath = trace_dir + "/component_g4t1_g3t1_5_trace.txt";
        fp.open(g4t1_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,abpd_freq,abpd_data,abpd_risk,abpd_batt\n";
        fp.close();

        g4t1_g3t1_6_filepath = trace_dir + "/component_g4t1_g3t1_6_trace.txt";
        fp.open(g4t1_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),type,glc_freq,glc_data,glc_risk,glc_batt\n";
        fp.close();                                        
    }
}

void G4T1::tearDown() {}

void G4T1::collect(const messages::SensorData::ConstPtr& msg) {
    int type = getSensorId(msg->type);
    logicalTimestamp = msg->logicalTimestamp;
    int freq = msg->sensorFreq;
    double data = msg->data;
    double risk = msg->risk;
    double batt = msg->batt;

    battery.consume(BATT_UNIT);
    if (msg->type == "null" || int32_t(risk) == -1)  throw std::domain_error("risk data out of boundaries");

    /*update battery status for received sensor info*/
    // oxigenation, heart_rate, temperature, abps, abpd, glucose
    if (msg->type == "oximeter") {
        oxi_freq = freq;
        oxi_data = data;
        oxi_risk = risk;
        oxi_batt = batt;

        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "oximeter" << ",";
            fp << oxi_freq << ",";
            fp << oxi_data << ",";
            fp << oxi_risk << ",";
            fp << oxi_batt << "\n";             
            fp.close();                                      
        } 

    } else if (msg->type == "ecg") {
        ecg_freq = freq;
        ecg_data = data;
        ecg_risk = risk;
        ecg_batt = batt;
 
        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "ecg" << ",";
            fp << ecg_freq << ",";
            fp << ecg_data << ",";
            fp << ecg_risk << ",";
            fp << ecg_batt << "\n";             
            fp.close();                                      
        } 

    } else if (msg->type == "thermometer") {
        trm_freq = freq;
        trm_data = data;
        trm_risk = risk;
        trm_batt = batt;

        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);            
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "thermometer" << ",";
            fp << trm_freq << ",";
            fp << trm_data << ",";
            fp << trm_risk << ",";
            fp << trm_batt << "\n";             
            fp.close();                                      
        } 

    } else if (msg->type == "abps") {
        abps_freq = freq;
        abps_data = data;
        abps_risk = risk;
        abps_batt = batt;

        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);          
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "abps" << ",";
            fp << abps_freq << ",";
            fp << abps_data << ",";
            fp << abps_risk << ",";
            fp << abps_batt << "\n";             
            fp.close();                                      
        } 

    } else if (msg->type == "abpd") {
        abpd_freq = freq;
        abpd_data = data;
        abpd_risk = risk;
        abpd_batt = batt;
   
        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);          
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "abpd" << ",";
            fp << abpd_freq << ",";
            fp << abpd_data << ",";
            fp << abpd_risk << ",";
            fp << abpd_batt << "\n";             
            fp.close();                                      
        } 

    } else if (msg->type == "glucosemeter") {
        glc_freq = freq;
        glc_data = data;
        glc_risk = risk;
        glc_batt = batt;
  
        // Tracing
        if (data_tracing) {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            fp.open(g4t1_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);      
            fp << ceil(logicalTimestamp/1000.0) << ",";
            fp << logicalTimestamp << ",";
            fp << ceil(physicalTimestamp/1000.0) << ",";
            fp << physicalTimestamp << ",";
            fp << "glucosemeter" << ",";
            fp << glc_freq << ",";
            fp << glc_data << ",";
            fp << glc_risk << ",";
            fp << glc_batt << "\n";             
            fp.close();                                      
        } 
    }

    if (buffer_size[type] < max_size) {
        data_buffer[type].push_back(risk);
        buffer_size[type] = data_buffer[type].size();
        total_buffer_size = std::accumulate(std::begin(buffer_size), std::end(buffer_size), 0, std::plus<int>());
    } else {
        data_buffer[type].push_back(risk);
        data_buffer[type].erase(data_buffer[type].begin());//erase the first element to avoid overflow
        lost_packt = true;
    }
}

void G4T1::process(){
    battery.consume(BATT_UNIT * data_buffer.size());
    std::vector<double> current_data;

    for(std::vector<std::list<double>>::iterator it = data_buffer.begin(); it != data_buffer.end(); it++) {
        double el = it->front();
        current_data.push_back(el);
        if(it->size() > 1) it->pop_front();
    }

    patient_status = data_fuse(current_data); // consumes 1 packt per sensor (in the buffers that have packages to data_bufferbe processed)
    for (int i = 0; i < buffer_size.size(); ++i){ // update buffer sizes
        buffer_size[i] = data_buffer[i].size();
    }
    total_buffer_size = std::accumulate(std::begin(buffer_size), std::end(buffer_size), 0, std::plus<int>()); //update total buffer size 

    // std::vector<std::string> risks;
    getPatientStatus();

    std::string patient_risk;

    if(patient_status <= 20) {
        patient_risk = "VERY LOW RISK";
    } else if(patient_status > 20 && patient_status <= 40) {
        patient_risk = "LOW RISK";
    } else if(patient_status > 40 && patient_status <= 60) {
        patient_risk = "MODERATE RISK";
    } else if(patient_status > 60 && patient_status <= 80) {
        patient_risk = "CRITICAL RISK";
    } else if(patient_status > 80 && patient_status <= 100) {
        patient_risk = "VERY CRITICAL RISK";
    }

    std::cout << std::endl << "*****************************************" << std::endl;
    std::cout << "PatientStatusInfo#" << std::endl;
    std::cout << "| OXIM_RISK: " << oxi_risk << std::endl;
    std::cout << "| ECG_RISK: " << ecg_risk << std::endl;
    std::cout << "| THERM_RISK: " << trm_risk << std::endl;
    std::cout << "| ABPS_RISK: " << abps_risk << std::endl;
    std::cout << "| ABPD_RISK: " << abpd_risk << std::endl;
    std::cout << "| GLC_RISK: " << glc_risk << std::endl;
    std::cout << "| PATIENT_STATE:" << patient_risk << std::endl;
    std::cout << "*****************************************" << std::endl;
}

int32_t G4T1::getSensorId(std::string type) {
    // oxigenation, heart_rate, temperature, abps, abpd, glucose
    if (type == "oximeter")
        return 0;
    else if (type == "ecg")
        return 1;
    else if (type == "thermometer")
        return 2;
    else if (type == "abps")
        return 3;
    else if (type == "abpd")		
        return 4;
    else if (type == "glucosemeter")        
        return 5;
    else {
        std::cout << "UNKNOWN TYPE " + type << std::endl;
        return -1;
    }
}

void G4T1::transfer() {
    messages::TargetSystemData msg;

    msg.oxi_freq = oxi_freq;
    msg.ecg_freq = ecg_freq;
    msg.trm_freq = trm_freq;
    msg.abps_freq = abps_freq;
    msg.abpd_freq = abpd_freq;
    msg.glc_freq = glc_freq;

    msg.oxi_data = oxi_data;
    msg.ecg_data = ecg_data;
    msg.trm_data = trm_data;
    msg.abps_data = abps_data;
    msg.abpd_data = abpd_data;
    msg.glc_data = glc_data;

    msg.oxi_risk = oxi_risk;
    msg.ecg_risk = ecg_risk;
    msg.trm_risk = trm_risk;
    msg.abps_risk = abps_risk;
    msg.abpd_risk = abpd_risk;
    msg.glc_risk = glc_risk;
    
    msg.oxi_batt = oxi_batt;
    msg.ecg_batt = ecg_batt;
    msg.trm_batt = trm_batt;
    msg.abps_batt = abps_batt;
    msg.abpd_batt = abpd_batt;
    msg.glc_batt = glc_batt;

    msg.logicalTimestamp = logicalTimestamp;
    msg.freq = rosComponentDescriptor.getFreq();
    msg.patient_status = patient_status;

    pub.publish(msg);

    if (lost_packt) {
        lost_packt = false;
        throw std::domain_error("lost data due to package overflow");
    }
}