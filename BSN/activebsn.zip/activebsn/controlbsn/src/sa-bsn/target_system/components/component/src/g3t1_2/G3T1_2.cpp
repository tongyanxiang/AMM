#include "component/g3t1_2/G3T1_2.hpp"

using namespace bsn::range;
using namespace bsn::resource;
using namespace bsn::generator;
using namespace bsn::configuration;

G3T1_2::G3T1_2(int &argc, char **argv, const std::string &name) :
    Sensor(argc, argv, name, "ecg", true, 1, bsn::resource::Battery("ecg_batt", 100, 100, 1), false),
    markov(),
    dataGenerator(),
    filter(1),
    sensorConfig(),
    collected_risk() {}

G3T1_2::~G3T1_2() {}

void G3T1_2::setUp() {
    // Get start time from physicalTimer.txt writen in script
    std::string timer_path = ros::package::getPath("component") + "/../../../physicalTimer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        std::cerr << "[setUp] Could not read physicalTimer.txt!\n"; 
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;
    
    Component::setUp();

    nh.getParam("/g3t1_2/start", shouldStart);
    
    int freq;
	nh.getParam("/g3t1_2/frequency", freq);
    rosComponentDescriptor.setFreq(freq);
    std::cout << "[setUp] frequency=" << freq << std::endl;

    int factor;
    nh.getParam("/injector/acceleration_factor", factor);
    rosComponentDescriptor.setAccelerationFactor(factor);
    std::cout << "[setUp] acceleration_factor=" << factor << std::endl;

    std::string s;
    std::array<bsn::range::Range,5> ranges;
    
    { // Configure markov chain
        std::vector<std::string> lrs,mrs0,hrs0,mrs1,hrs1;

        nh.getParam("/g3t1_2/heart_rate_HighRisk0", s);
        hrs0 = bsn::utils::split(s, ',');
        nh.getParam("/g3t1_2/heart_rate_MidRisk0", s);
        mrs0 = bsn::utils::split(s, ',');
        nh.getParam("/g3t1_2/heart_rate_LowRisk", s);
        lrs = bsn::utils::split(s, ',');
        nh.getParam("/g3t1_2/heart_rate_MidRisk1", s);
        mrs1 = bsn::utils::split(s, ',');
        nh.getParam("/g3t1_2/heart_rate_HighRisk1", s);
        hrs1 = bsn::utils::split(s, ',');

        ranges[0] = Range(std::stod(hrs0[0]), std::stod(hrs0[1]));
        ranges[1] = Range(std::stod(mrs0[0]), std::stod(mrs0[1]));
        ranges[2] = Range(std::stod(lrs[0]), std::stod(lrs[1]));
        ranges[3] = Range(std::stod(mrs1[0]), std::stod(mrs1[1]));
        ranges[4] = Range(std::stod(hrs1[0]), std::stod(hrs1[1]));
    }

    { // Configure sensor configuration
        Range low_range = ranges[2];
        
        std::array<Range,2> midRanges;
        midRanges[0] = ranges[1];
        midRanges[1] = ranges[3];
        
        std::array<Range,2> highRanges;
        highRanges[0] = ranges[0];
        highRanges[1] = ranges[4];

        std::array<Range,3> percentages;

        nh.getParam("/g3t1_2/lowrisk", s);
        std::vector<std::string> low_p = bsn::utils::split(s, ',');
        percentages[0] = Range(std::stod(low_p[0]), std::stod(low_p[1]));

        nh.getParam("/g3t1_2/midrisk", s);
        std::vector<std::string> mid_p = bsn::utils::split(s, ',');
        percentages[1] = Range(std::stod(mid_p[0]), std::stod(mid_p[1]));

        nh.getParam("/g3t1_2/highrisk", s);
        std::vector<std::string> high_p = bsn::utils::split(s, ',');
        percentages[2] = Range(std::stod(high_p[0]), std::stod(high_p[1]));

        sensorConfig = SensorConfiguration(0, low_range, midRanges, highRanges, percentages);
    }

    { //Check for instant recharge parameter
        nh.getParam("/g3t1_2/instant_recharge", instant_recharge);
    }

    // Cost
    nh.getParam("/g3t1_2/BATT_UNIT", BATT_UNIT);
    std::cout << "[setUp] BATT_UNIT=" << BATT_UNIT << std::endl;

    // Process noise
    nh.getParam("/g3t1_2/process_noise_trigger", process_noise_trigger);
    nh.getParam("/g3t1_2/random_seed", random_seed);
    nh.getParam("/g3t1_2/process_noise_sigma", process_noise_sigma);
    std::cout << "[setUp] process_noise_trigger=" << process_noise_trigger << ", random_seed=" << random_seed << ", process_noise_sigma=" << process_noise_sigma << std::endl;

    PNGenerator = std::normal_distribution<double> (0.0, process_noise_sigma);

    // Environment uncertainty
    nh.getParam("/g3t1_2/uncertainty_trigger", uncertainty_trigger);

    // Model deviation: normal or Longterm_drift
    nh.getParam("/g3t1_2/deviation_mode", deviation_mode);
    nh.getParam("/g3t1_2/B_offset_percent", B_offset_percent);
    nh.getParam("/g3t1_2/drift_start_time", drift_start_time);
    std::cout << "[setUp] deviation_mode=" << deviation_mode << ", B_offset_percent=" << B_offset_percent << ", drift_start_time=" << drift_start_time << std::endl;

    // Injector subscribe
    currentLoop = 0;
    
    std::string sensor_name = rosComponentDescriptor.getName();
    dataInitialization = handle.subscribe("InjectData_"+sensor_name.substr(1, sensor_name.size()), 100, &G3T1_2::collectInputData, this);
    std::cout << "[setUp] Initialize subscriber InjectData_" << sensor_name.substr(1, sensor_name.size()) << std::endl;

    // Injector service
    ros::ServiceClient injector_client = handle.serviceClient<services::SensorNodeStartData>("getSensorNodeStartData");
    services::SensorNodeStartData srv;

    // Request
    srv.request.component = sensor_name.substr(1, sensor_name.size());
    srv.request.started = true;

    // Response
    bool flag = injector_client.call(srv);
    if (flag) {
        std::cout << "[setUp] Get the response from injector, injector updated the config.\n";
    } else {
        std::cout << "[setUp] Response error from injector.\n";

        std::string restart_path = ros::package::getPath("component") + "/../../../restart.txt";
        fp.open(restart_path, std::fstream::in | std::fstream::out);   
        fp << 1 << "\n";
        fp.close();        
    }
    
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        rng.seed(random_seed);
    }
    
    // Tracing 
    nh.getParam("/g3t1_2/data_tracing", data_tracing);

    if (data_tracing) {
        std::string trace_dir = ros::package::getPath("component") + "/traces";

        // Make new directory
        struct stat st;
        if (stat(trace_dir.c_str(), &st) == -1) {
            std::string makeCommand = "mkdir -p " + trace_dir;
            system(makeCommand.c_str());
        }

        g3t1_filepath = trace_dir + "/component_g3t1_2_trace.txt";
        fp.open(g3t1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,BATT_UNIT,true_B,noisy_true_B,drift_B,noisy_drift_B,B_offset,process_noise_offset,injector_factor,injector_offset,cost\n";
        fp.close();
    }    
}

void G3T1_2::tearDown() {
    Component::tearDown();
}

double G3T1_2::collect() {
    double m_data = 0;

    // Get the injector factor from the private variable
    if(!injectorFactors.empty()){
        logicalTimestamp = logicalTimes.front();
        logicalTimes.erase(logicalTimes.begin());

        injector_factor = injectorFactors.front();
        injectorFactors.erase(injectorFactors.begin());

        msgCurrentLoops.push_back(currentLoops.front());
        currentLoops.erase(currentLoops.begin());

        msgCurrentFreq = currentFreq;
        msgCurrentComp = rosComponentDescriptor.getName();
        msgCurrentIteration = currentIteration;

        std::cout << "[t=" << logicalTimestamp << "] Collect injector_factor=" << injector_factor << ", msgCurrentIteration=" << msgCurrentIteration << std::endl; 
    }

    // Patient service
    ros::ServiceClient patient_client = handle.serviceClient<services::PatientData>("getPatientData");
    services::PatientData patient_srv;

    // Request
    patient_srv.request.vitalSign = "heart_rate";
    patient_srv.request.logicalTimestamp = logicalTimestamp;
    patient_srv.request.sensorFreq = rosComponentDescriptor.getFreq();

    // Response
    if (patient_client.call(patient_srv)) {
        m_data = patient_srv.response.data;
        // ROS_INFO("new data collected: [%s]", std::to_string(m_data).c_str());
    } else {
        m_data = 0.0;
        // ROS_INFO("error collecting data, defualt m_data: [%f]", m_data);
    }
    
    // Tracing
    sensorFreq = rosComponentDescriptor.getFreq(); 

    collected_risk = sensorConfig.evaluateNumber(m_data);

    return m_data;
}

void G3T1_2::collectInputData(const messages::InjectorData::ConstPtr& msg){
    maxLoop = msg->sensorFreq;
    currentFreq = msg->sensorFreq;
    rosComponentDescriptor.setFreq(msg->sensorFreq);
    for (auto it = msg->timeData.begin(); it < msg->timeData.end(); it++){
        logicalTimes.push_back(*it);
    }

    for (auto it = msg->data.begin(); it < msg->data.end(); it++){
        injectorFactors.push_back(*it);
        currentLoops.push_back(currentLoop);
        currentLoop ++;
    }

    currentIteration = msg->iteration;

    std::cout << "[t=" << logicalTimestamp << "] InjectorData iteration=" << currentIteration << ", loop=" << currentLoop << ", component=" << msg->component.c_str() << std::endl; 
}


double G3T1_2::process(const double &m_data) {
    double filtered_data;
    
    filter.insert(m_data);
    filtered_data = filter.getValue();

    // ROS_INFO("filtered data: [%s]", std::to_string(filtered_data).c_str());

    return filtered_data;
}

void G3T1_2::transfer(const double &m_data) {
    double risk;
    risk = sensorConfig.evaluateNumber(m_data);

    if (risk < 0 || risk > 100) throw std::domain_error("risk data out of boundaries");
    if (label(risk) != label(collected_risk)) throw std::domain_error("sensor accuracy fail");

    // Nominal B: collect + process + transfer
    true_B = 3.0 * BATT_UNIT;

    // Model deviation: longterm_drift
    double second_time = logicalTimestamp/1000.0;
    if (deviation_mode == "longterm_drift" && second_time >= drift_start_time) {
        B_offset = B_offset_percent * true_B * sin((2 * PI / period) * (second_time - drift_start_time));
        std::cout << "[t=" << logicalTimestamp << "] longterm_drift B_offset=" << B_offset << std::endl;
    } else {
        B_offset = 0.0;
    }
    drift_B = true_B + B_offset;

    // Process noise
    if (process_noise_trigger) {
        process_noise_offset = PNGenerator(rng);
    } else {
        process_noise_offset = 0.0;
    }
    noisy_true_B = true_B + process_noise_offset;
    noisy_drift_B = drift_B + process_noise_offset;

    // Environment uncertainty
    if (uncertainty_trigger) {
        injector_offset = BATT_UNIT * injector_factor;
    } else {
        injector_offset = 0.0;
    }
    noisy_true_B += injector_offset;
    noisy_drift_B += injector_offset; 

    // Cost
    if (deviation_mode == "longterm_drift") {
        cost = noisy_drift_B;
    } else {
        cost = noisy_true_B;
    }
    battery.consume(cost);

    // Tracing
    if (data_tracing) {
        physicalTimestamp = this->nowInMilliSecond() - time_ref;

        fp.open(g3t1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
        fp << ceil(logicalTimestamp/1000.0) << ",";
        fp << logicalTimestamp << ",";
        fp << ceil(physicalTimestamp/1000.0) << ",";
        fp << physicalTimestamp << ",";
        fp << "heart_rate" << ","; 
        fp << sensorFreq << ",";    
        fp << BATT_UNIT << ",";  
        fp << true_B << "," << noisy_true_B << "," << drift_B << "," << noisy_drift_B << ",";  
        fp << B_offset << ",";   
        fp << process_noise_offset << ",";   
        fp << injector_factor << "," << injector_offset << ",";   
        fp << cost << "\n"; 
        fp.close(); 
    } 

    ros::NodeHandle handle;
    data_pub = handle.advertise<messages::SensorData>("ecg_data", 100);
    
    messages::SensorData msg;
    msg.type = type;
    msg.logicalTimestamp = logicalTimestamp;
    msg.sensorFreq = sensorFreq;
    msg.data = m_data;
    msg.risk = risk;
    msg.batt = battery.getCurrentLevel();

    data_pub.publish(msg);

    // ROS_INFO("risk calculated and transferred: [%.2f%%]", risk);
}

std::string G3T1_2::label(double &risk) {
    std::string ans;
    if(sensorConfig.isLowRisk(risk)){
        ans = "low";
    } else if (sensorConfig.isMediumRisk(risk)) {
        ans = "moderate";
    } else if (sensorConfig.isHighRisk(risk)) {
        ans = "high";
    } else {
        ans = "unknown";
    }

    return ans;
}