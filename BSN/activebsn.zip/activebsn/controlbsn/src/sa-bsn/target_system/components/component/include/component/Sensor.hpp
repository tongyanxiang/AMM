#ifndef SENSOR_HPP
#define SENSOR_HPP

#include <random>
#include <fstream>
#include <sys/stat.h>

#include "ros/package.h"
#include "services/SensorNodeUpdateData.h"

#include "libbsn/resource/Battery.hpp"
#include "libbsn/utils/utils.hpp"

#include "archlib/target_system/Component.hpp"

class Sensor : public arch::target_system::Component {

    public:
		Sensor(int &argc, char **argv, const std::string &name, const std::string &type, const bool &active, const double &injector_factor, const bsn::resource::Battery &battery, const bool &instant_recharge);
    	~Sensor();

	private:
    	Sensor &operator=(const Sensor &);

  	public:
        virtual void setUp() = 0;
    	virtual void tearDown() = 0;
        virtual int32_t run();
		void body();

        void reconfigure(const archlib::AdaptationCommand::ConstPtr& msg);
		
        virtual double collect() = 0;
        virtual double process(const double &data) = 0;
        virtual void transfer(const double &data) = 0;

    protected:
        // acceleration simulation
        int acceleration;

        // Cost
        double BATT_UNIT;

        // Process noise
        bool process_noise_trigger;
        double process_noise_sigma;
        double process_noise_offset;

        int random_seed; 
		std::normal_distribution<double> PNGenerator;
		std::mt19937 rng;

        // Environment uncertainty
        bool uncertainty_trigger;
        double injector_factor;
        double injector_offset;

        // Deviation
        std::string deviation_mode; 
        
        int drift_start_time;
        double B_offset_percent;
        double B_offset;
        double PI = 3.14159265358979323846;
        double period = 6.0*600;  

        double true_B;
        double noisy_true_B;
        
        double drift_B;
        double noisy_drift_B;

    protected:
        bool isActive();
        void turnOn();
        void turnOff();
        void recharge();

    protected:
		std::string type;
		bool active;
        int buffer_size;
        int replicate_collect;
		bsn::resource::Battery battery;
        double data;
        bool instant_recharge;
        bool shouldStart;
        double cost;

        ros::Publisher updateConfigPubs;

		// Get input data from injector
		std::vector<int> logicalTimes;
        std::vector<double> injectorFactors;
        
		// Record the data
		std::vector<int> currentLoops;
		int currentLoop;
		int maxLoop;
		int currentIteration;
		int targetIteration;
		int currentFreq;
};

#endif 