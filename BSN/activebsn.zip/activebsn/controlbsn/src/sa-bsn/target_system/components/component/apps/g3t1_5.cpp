#include "component/g3t1_5/G3T1_5.hpp"

int32_t main(int32_t argc, char **argv) {
    G3T1_5 g3t1_5(argc, argv, "apbd");
    return g3t1_5.run();
}