#include "data_access/DataAccess.hpp"

#define W(x) std::cerr << #x << " = " << x << std::endl;

DataAccess::DataAccess(int  &argc, char **argv, const std::string &name) : ROSComponent(argc, argv, name), buffer_size(), reliability_formula(), cost_formula() {}

DataAccess::~DataAccess() {}

std::string fetch_formula(std::string name){
    std::string formula;
    std::string path = ros::package::getPath("repository");
    
    std::string filename = "/../resource/models/" + name + ".formula";
    try{
        std::ifstream file;
        file.open(path + filename);
        std::getline(file, formula);
        file.close();
    } catch (std::ifstream::failure e) { 
        std::cerr << "Could not load " + name +  " formula into memory!\n"; 
    }

    return formula;
}

void DataAccess::setUp() {
    // Get start time from physicalTimer.txt writen in script
    std::string timer_path = ros::package::getPath("repository") + "/../../physicalTimer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        std::cerr << "[setUp] Could not read physicalTimer.txt!\n"; 
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;

    // Intialize buffer_size and formula
    buffer_size = 1000;
    reliability_formula = fetch_formula("reliability");
    cost_formula = fetch_formula("cost");

    // Intialize batteries and reliabilities
    components_batteries["g3t1_1"] = 100;
    components_batteries["g3t1_2"] = 100;
    components_batteries["g3t1_3"] = 100;
    components_batteries["g3t1_4"] = 100;
    components_batteries["g3t1_5"] = 100;
    components_batteries["g3t1_6"] = 100;
    components_reliabilities["g3t1_1"] = 1;
    components_reliabilities["g3t1_2"] = 1;
    components_reliabilities["g3t1_3"] = 1;
    components_reliabilities["g3t1_4"] = 1;
    components_reliabilities["g3t1_5"] = 1;
    components_reliabilities["g3t1_6"] = 1;
    
    // Intialize the iteration, -1 means an iteration doesn't begin.
    currentIteration = -1;
    compIterMarks["g3t1_1"] = -1;
    compIterMarks["g3t1_2"] = -1;
    compIterMarks["g3t1_3"] = -1;
    compIterMarks["g3t1_4"] = -1;
    compIterMarks["g3t1_5"] = -1;
    compIterMarks["g3t1_6"] = -1;

    // Intialize subscriber, publisher and service
    targetSystemSub = nh.subscribe("TargetSystemData", 100, &DataAccess::processTargetSystemData, this);
    handle_persist = nh.subscribe("persist", 100, &DataAccess::receivePersistMessage, this);

    dataPersistFinshedPub = nh.advertise<archlib::DataPersistFinished>("DataPersistFinished", 100);

    server = nh.advertiseService("DataAccessRequest", &DataAccess::processQuery, this);

    // Frequency
    double freq;
	nh.getParam("/data_access/frequency", freq);
    rosComponentDescriptor.setFreq(freq);
    std::cout << "[setUp] frequency=" << freq << std::endl;

    // Observation noise
    nh.getParam("/data_access/sensor_noise_trigger", sensor_noise_trigger);
    nh.getParam("/data_access/random_seed", random_seed);
    nh.getParam("/data_access/sensor_noise_sigma", sensor_noise_sigma);
    std::cout << "[setUp] sensor_noise_trigger=" << sensor_noise_trigger << ", random_seed=" << random_seed << ", sensor_noise_sigma=" << sensor_noise_sigma << std::endl;
    
    ONGenerator = std::normal_distribution<double> (0.0, sensor_noise_sigma);
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        rng.seed(random_seed);
    }

    // Tracing 
    nh.getParam("/data_access/data_tracing", data_tracing);
    std::cout << "[setUp] data_tracing=" << data_tracing << std::endl;

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("repository") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        event_filepath = trace_dir + "/dataAccess_event_trace.txt";
        status_filepath = trace_dir + "/dataAccess_status_trace.txt";

        g3t1_1_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_1_trace.txt";
        g3t1_2_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_2_trace.txt";
        g3t1_3_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_3_trace.txt";
        g3t1_4_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_4_trace.txt";
        g3t1_5_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_5_trace.txt";
        g3t1_6_energy_status_filepath = trace_dir + "/dataAccess_energy_status_g3t1_6_trace.txt";

        g3t1_1_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_1_trace.txt";
        g3t1_2_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_2_trace.txt";
        g3t1_3_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_3_trace.txt";
        g3t1_4_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_4_trace.txt";
        g3t1_5_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_5_trace.txt";
        g3t1_6_adaptation_filepath = trace_dir + "/dataAccess_adaptation_g3t1_6_trace.txt"; 

        engine_cost_filepath = trace_dir + "/dataAccess_engine_cost_trace.txt";
        enactor_cost_filepath = trace_dir + "/dataAccess_enactor_cost_trace.txt";

        enactor_g3t1_1_window_filepath = trace_dir + "/enactor_window_g3t1_1_trace.txt";
        enactor_g3t1_2_window_filepath = trace_dir + "/enactor_window_g3t1_2_trace.txt";
        enactor_g3t1_3_window_filepath = trace_dir + "/enactor_window_g3t1_3_trace.txt";
        enactor_g3t1_4_window_filepath = trace_dir + "/enactor_window_g3t1_4_trace.txt";
        enactor_g3t1_5_window_filepath = trace_dir + "/enactor_window_g3t1_5_trace.txt";
        enactor_g3t1_6_window_filepath = trace_dir + "/enactor_window_g3t1_6_trace.txt";
        
        // Event
        fp.open(event_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),name,source,target,freq,event\n";
        fp.close();

        // Status
        fp.open(status_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),name,source,target,freq,state\n";
        fp.close();

        // Energy status filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),iteration,loop,name,source,target,freq,content\n";
            fp.close();
        }

        // Adaptation filepath
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),iteration,name,source,target,action\n";
            fp.close();
        }  

        // Cost filepath     
        fp.open(engine_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),name,query,content\n";
        fp.close();     

        fp.open(enactor_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),name,query,content\n";
        fp.close();   

        // Enactor cost time window filepath   
        for (int index=0; index<6; index++) {
            if (index == 0) {fp.open(enactor_g3t1_1_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 1) {fp.open(enactor_g3t1_2_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 2) {fp.open(enactor_g3t1_3_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 3) {fp.open(enactor_g3t1_4_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 4) {fp.open(enactor_g3t1_5_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (index == 5) {fp.open(enactor_g3t1_6_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

            fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),source,freq,windowSize,content\n";
            fp.close();        
        }              
    }
}

void DataAccess::tearDown(){}

void DataAccess::body() {
    count_to_fetch++;
    frequency = rosComponentDescriptor.getFreq();

    if (count_to_fetch >= frequency*10){
        reliability_formula = fetch_formula("reliability");
        cost_formula = fetch_formula("cost");

        count_to_fetch = 0;
    }

    // Check for data transmission finished
    bool isFinished = true;
    for(auto it :compIterMarks){
        std::string compName = it.first;
        if(compIterMarks[compName] == -1){
            isFinished = false;
            break;
        }
        if(compFreqMarks.find(compName) == compFreqMarks.end() || compLoopMarks.find(compName) == compLoopMarks.end()){
            isFinished = false;
            break;
        }
        int compIter = compIterMarks[compName];
        int compFreq = compFreqMarks[compName];
        if(compIter != currentIteration){
            isFinished = false;
            break;
        }
        std::set<int> sortedSet(compLoopMarks[compName].begin(), compLoopMarks[compName].end());
        if(compLoopMarks[compName].size() < compFreq){
            isFinished = false;
            break;
        }
    }

    if(isFinished){
        std::cout << "[t=" << logicalTimestamp << "] Data collected ready.\n";
        compFreqMarks.clear();
        compLoopMarks.clear();
        compIterMarks.clear();

        archlib::DataPersistFinished msg;
        msg.ok = true;
        msg.iteration = currentIteration;
        dataPersistFinshedPub.publish(msg);

        currentIteration = -1;
        compIterMarks["g3t1_1"] = -1;
        compIterMarks["g3t1_2"] = -1;
        compIterMarks["g3t1_3"] = -1;
        compIterMarks["g3t1_4"] = -1;
        compIterMarks["g3t1_5"] = -1;
        compIterMarks["g3t1_6"] = -1;
    }

    ros::spinOnce();
}

void DataAccess::processTargetSystemData(const messages::TargetSystemData::ConstPtr& msg) {
    components_batteries["g3t1_1"] = msg->trm_batt;
    components_batteries["g3t1_2"] = msg->ecg_batt;
    components_batteries["g3t1_3"] = msg->oxi_batt;
    components_batteries["g3t1_4"] = msg->abps_batt;
    components_batteries["g3t1_5"] = msg->abpd_batt;
    components_batteries["g3t1_6"] = msg->glc_batt;
}

void DataAccess::receivePersistMessage(const archlib::Persist::ConstPtr& msg) {
    // ROS_INFO("I heard: [%s]", msg->type.c_str());

    if (msg->type=="Event") {
        // std::cout << "[t=" << msg->timestamp << "] source=" << msg->source << ", content=" << msg->content << std::endl;
    
        // "/g3t1_X:activate/deactivate"
        if (msg->source != "/g4t1") {
            if (events[msg->source].size()<=buffer_size) {
                events[msg->source].push_back(msg->content);
            } else {
                events[msg->source].pop_front();
                events[msg->source].push_back(msg->content);
            }

            std::string key = msg->source;
            key = key.substr(1, key.size());
            contexts[key] = msg->content == "activate" ? 1 : 0;

            if (data_tracing) {
                persistEvent(msg->logicalTimestamp, msg->source, msg->target, msg->freq, msg->content);
            }
        }

    } else if (msg->type == "Status") { 
        // std::cout << "[t=" << msg->logicalTimestamp << "] source=" << msg->source << ", content=" << msg->content << std::endl;
    
        // "/g3t1_X:init/running/success/fail"
        if (msg->source != "/g4t1") {
            status[msg->source].push_back({msg->logicalTimestamp, msg->freq, msg->content});

            if (data_tracing) {
                persistStatus(msg->logicalTimestamp, msg->source, msg->target, msg->freq, msg->content);
            }
        }

    } else if (msg->type == "EnergyStatus") {
        // std::cout << "[t=" << msg->logicalTimestamp << "] source=" << msg->source << ", content=" << msg->content << std::endl;

        // "/g3t1_X:0.15"
        if (msg->source != "/g4t1" && msg->source != "/engine") {
            // Notice!!! energystatus's key can't be replaced by compName
            // Because the latter logic relies on name like "/g3t1_1", not "g3t1_1"
            energystatus[msg->source].push_back({msg->logicalTimestamp, msg->freq, msg->content, msg->iteration, msg->loop});

            // msg->source: /g3t1_1 or /g3t1_2 ... etc
            std::string compName = msg->source.substr(1, msg->source.size());
            // compName: g3t1_1 or g3t1_2 ... etc
            if(currentIteration == -1){
                currentIteration = msg->iteration;
            }
            if(compFreqMarks.find(compName) == compFreqMarks.end()){
                compFreqMarks[compName] = msg->freq;
            }
            compIterMarks[compName] = msg->iteration;
            compLoopMarks[compName].insert(msg->loop);

            if (data_tracing) {
                persistEnergyCostStatus(msg->logicalTimestamp, msg->source, msg->target, msg->freq, msg->content, msg->iteration, msg->loop);
            }
        }

    } else if (msg->type=="AdaptationCommand") {
        // std::cout << "[t=" << msg->logicalTimestamp << "] source=" << msg->source << ", content=" << msg->content << std::endl;
        
        // "/g3t1_X:freq=1"
        if (msg->source != "/g4t1") {
            if (data_tracing) {
                persistAdaptation(msg->logicalTimestamp, msg->source, msg->target, msg->content);
            }
        }

    } else {
        ROS_INFO("(Could not identify message type!!)");
    }
}

bool DataAccess::processQuery(archlib::DataAccessRequest::Request &req, archlib::DataAccessRequest::Response &res){
    res.content = "";

    logicalTimestamp = req.logicalTimestamp;   
    try {
        if (req.name == "/engine" || req.name == "/enactor") {
            std::vector<std::string> query = bsn::utils::split(req.query,':');

            // wait smth like "reliability_formula"/"cost_formula" from "/engine"
            // response smth with formula
            if (query.size() == 1){
                if (query[0] == "reliability_formula") {
                    res.content = reliability_formula;
                } else if (query[0] == "cost_formula") {
                    res.content = cost_formula;
                } 
            }

            if (query.size() > 1){
                if (query[1] == "event") {
                    // wait smth like "all:event:XXX" from "/engine" -> return first XXX events
                    // response smth like "/g3t1_1:activate,...,activate;/g3t1_2:deactivate,...,deactivate;..."
                    int num = stoi(query[2]);
                    for (std::map<std::string, std::deque<std::string>>::iterator it = events.begin(); it != events.end(); it++){
                        std::string aux = it->first;
                        aux += ":";
                        bool flag = false;
                        std::string content = "";
                        for(int i = it->second.size()-num; i < it->second.size(); ++i){
                            flag = true;
                            aux += it->second[i];
                            content += it->second[i];
                            
                            if (i + 1 < it->second.size()){aux += ",";}
                        }
                        aux += ";";

                        if (flag) {
                            std::string key = it->first;
                            key = key.substr(1, key.size());
                            contexts[key] = content == "activate" ? 1 : 0;
                            res.content += aux;
                        }
                    }

                } else if (query[1] == "reliability") {
                    // wait smth like "all:reliability:XXX" from "/enactor" -> return component reliability within the lastest XXX seconds
                    // response smth like "/g3t1_1:0.90;/g3t1_2:0.90;..."
                    time_window = stoi(query[2]);    
                    applyTimeWindowReliability();
                    for (auto it : status) {
                        res.content += calculateComponentReliability(it.first);
                    }

                } else if (query[1] == "cost") {   
                    // wait smth like "all:cost:XXX" from "/engine" or "/enactor" -> return return component cost within the lastest XXX seconds
                    // response smth like "/g3t1_1:0.90;/g3t1_2:0.90..."
                    time_window = stoi(query[2]);                           
                    applyTimeWindowCost(logicalTimestamp, req.name);

                    for (auto it : energystatus) {
                        res.content += calculateComponentCost(it.first);
                    }

                    if (data_tracing) {
                        physicalTimestamp = this->nowInMilliSecond() - time_ref;
                        
                        if (req.name == "/engine") {
                            fp.open(engine_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                        } else if (req.name == "/enactor") {
                            fp.open(enactor_cost_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
                        }

                        fp << ceil(logicalTimestamp/1000.0) << ",";  
                        fp << logicalTimestamp << ",";  
                        fp << ceil(physicalTimestamp/1000.0) << ",";  
                        fp << physicalTimestamp << ",";  
                        fp << req.name << ",";  
                        fp << req.query << ",";  
                        fp << res.content << "\n";  
                        fp.close();    
                    }             
                }
            }
                                    
        } 
    } catch(...) {}
	
    return true;
}

void DataAccess::persistEvent(const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    EventMessage obj("Event", logicalTimestamp, source, target, freq, content);
    eventVec.push_back(obj);
    flush();
}

void DataAccess::persistStatus(const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    StatusMessage obj("Status", logicalTimestamp, source, target, freq, content);
    statusVec.push_back(obj);   
    flush();
}

void DataAccess::persistEnergyStatus(const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content){
    EnergyStatusMessage obj("EnergyStatus", logicalTimestamp, source, target, freq, content);
    energystatusVec.push_back(obj);
    flush();
}

void DataAccess::persistEnergyCostStatus(const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &content,const int& iteration, const int& loop){
    EnergyCostStatusMessage obj("EnergyStatus", logicalTimestamp, source, target, freq, content, iteration, loop);
    energyCostStatusVec.push_back(obj);
    flush();
}

void DataAccess::persistAdaptation(const int &logicalTimestamp, const std::string &source, const std::string &target, const std::string &content){
    AdaptationMessage obj("Adaptation", logicalTimestamp, source, target, content);
    adaptVec.push_back(obj);
    flush();
}

void DataAccess::persistAdaptationMsg(const int &logicalTimestamp, const std::string &source, const std::string &target, const std::string &content, const int& iteration){
    AdaptationCommandMessage obj("Adaptation", logicalTimestamp, source, target, content, iteration);
    adaptMsgVec.push_back(obj);
    flush();
}

void DataAccess::flush(){
    physicalTimestamp = this->nowInMilliSecond() - time_ref;
        
    fp.open(event_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
    for(std::vector<EventMessage>::iterator it = eventVec.begin(); it != eventVec.end(); ++it) {
        fp << ceil((*it).getLogicalTimestamp()/1000.0) << ",";   
        fp << (*it).getLogicalTimestamp() << ",";        
        fp << ceil(physicalTimestamp/1000.0) << ",";   
        fp << physicalTimestamp << ",";     
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getEvent() << "\n";
    }
    fp.close();
    eventVec.clear();

    fp.open(status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);   
    for(std::vector<StatusMessage>::iterator it = statusVec.begin(); it != statusVec.end(); ++it) {
        fp << ceil((*it).getLogicalTimestamp()/1000.0) << ",";   
        fp << (*it).getLogicalTimestamp() << ",";  
        fp << ceil(physicalTimestamp/1000.0) << ",";   
        fp << physicalTimestamp << ",";              
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getState() << "\n";
    }
    fp.close();
    statusVec.clear();

    for(std::vector<EnergyCostStatusMessage>::iterator it = energyCostStatusVec.begin(); it != energyCostStatusVec.end(); ++it) {
        if ((*it).getSource() == "/g3t1_1") {fp.open(g3t1_1_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_2") {fp.open(g3t1_2_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_3") {fp.open(g3t1_3_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_4") {fp.open(g3t1_4_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_5") {fp.open(g3t1_5_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getSource() == "/g3t1_6") {fp.open(g3t1_6_energy_status_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

        fp << ceil((*it).getLogicalTimestamp()/1000.0) << ",";   
        fp << (*it).getLogicalTimestamp() << ",";   
        fp << ceil(physicalTimestamp/1000.0) << ",";   
        fp << physicalTimestamp << ",";            
        fp << (*it).getIteration() << ","; 
        fp << (*it).getLoop() << ",";    
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getFreq() << ",";
        fp << (*it).getCost() << "\n";
        fp.close();
    }
    energyCostStatusVec.clear();

    for(auto it = adaptMsgVec.begin(); it != adaptMsgVec.end(); ++it) {
        if ((*it).getTarget() == "/g3t1_1") {fp.open(g3t1_1_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_2") {fp.open(g3t1_2_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_3") {fp.open(g3t1_3_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_4") {fp.open(g3t1_4_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_5") {fp.open(g3t1_5_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if ((*it).getTarget() == "/g3t1_6") {fp.open(g3t1_6_adaptation_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
   
        fp << ceil((*it).getLogicalTimestamp()/1000.0) << ",";   
        fp << (*it).getLogicalTimestamp() << ",";  
        fp << ceil(physicalTimestamp/1000.0) << ",";   
        fp << physicalTimestamp << ",";            
        fp << (*it).getIteration() << ",";            
        fp << (*it).getName() << ",";
        fp << (*it).getSource() << ",";
        fp << (*it).getTarget() << ",";
        fp << (*it).getContent() << "\n";
        fp.close();
    }
    adaptMsgVec.clear();
}

/**
 * Builds the response string and calculate the reliability
 * of the component specified as parameter
*/
std::string DataAccess::calculateComponentReliability(const std::string& component) {
    std::string aux = component, content = "";
    aux += ":";
    bool flag = false;
    double sum = 0;
    int len = 0;
    
    for (auto value : status[component]) {
        // reliability = success/(success + fails)
        std::string thirdValue = std::get<2>(value);
        if (thirdValue == "success") { // calculate reliability
            sum += 1;
            len++;
        } else if (thirdValue == "fail") {
            len++;
        } 

        flag = true;
    }
    aux += std::to_string((len > 0) ? sum / len : 0) + ';';

    std::string key = component;
    key = key.substr(1, key.size());

    if(flag) content += aux;

    components_reliabilities[key] = (len > 0) ? sum / len : 0;

    return content;
}

/**
 * Builds the response string and calculate the cost
 * of the component specified as parameter
*/
std::string DataAccess::calculateComponentCost(const std::string& component) {
    std::string aux = component, content = "";
    aux += ":";
    bool flag = false;
    double sum = 0;

    for (auto value : energystatus[component]) {
        std::string thirdValue = std::get<2>(value);
        sum += stod(thirdValue);
        
        flag = true;
    }

    // sensor noise
    if (sensor_noise_trigger == 1) {
        sensor_noise_offset = ONGenerator(rng);
        sum = sum + sensor_noise_offset;
    }
    aux += std::to_string(sum) + ';';

    std::string key = component;
    key = key.substr(1, key.size());

    if(flag) content += aux;

    components_costs[key] = sum;

    return content;
}

void DataAccess::applyTimeWindowReliability() {
    for (auto& component : status) {
        auto& deq = component.second;  

        // status: [msg->logicalTimestamp, msg->freq, msg->content]
        double nowSecond = std::get<0>(deq.back())/1000.0;
        
        while (!deq.empty()) {
            double arrivedSecond = std::get<0>(deq.front())/1000.0;
            double time_span = nowSecond - arrivedSecond;

            if (time_span >= time_window) {
                deq.pop_front();
            } else {
                component.second = deq;
                break;
            }
        }
    }
}

void DataAccess::applyTimeWindowCost(const int& timestamp, const std::string& requestName) {
    for (auto& component : energystatus) {
        auto& deq = component.second;  

        // energystatus: [msg->logicalTimestamp, msg->freq, msg->content, msg->iteration, msg->loop]
        double nowSecond = std::get<0>(deq.back())/1000.0;
        int freq = std::get<1>(deq.back());

        while (!deq.empty()) {
            double arrivedSecond = std::get<0>(deq.front())/1000.0;
            double time_span = nowSecond - arrivedSecond;

            if (time_span >= time_window) {
                deq.pop_front();
            } else {
                component.second = deq;
                break;
            }
        }

        // Tracing
        if (data_tracing && requestName == "/enactor") {
            physicalTimestamp = this->nowInMilliSecond() - time_ref;

            if (component.first == "/g3t1_1") {fp.open(enactor_g3t1_1_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
            else if (component.first == "/g3t1_2") {fp.open(enactor_g3t1_2_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_3") {fp.open(enactor_g3t1_3_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_4") {fp.open(enactor_g3t1_4_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_5") {fp.open(enactor_g3t1_5_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
            else if (component.first == "/g3t1_6") {fp.open(enactor_g3t1_6_window_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
          
            fp << ceil(logicalTimestamp/1000.0) << ",";  
            fp << logicalTimestamp << ",";  
            fp << ceil(physicalTimestamp/1000.0) << ",";  
            fp << physicalTimestamp << ",";              
            fp << component.first << ",";  
            fp << freq << ",";  
            fp << component.second.size();    
            for (auto& value : component.second) {
                fp << ",{"<< std::get<0>(value) << "," << std::get<1>(value) << "," << std::get<2>(value) << "}";     
            }
            fp << "\n"; 
            fp.close();    
        }
    }
}