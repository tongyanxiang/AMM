#ifndef ENERGY_COST_STATUS_MESSAGE_HPP
#define ENERGY_COST_STATUS_MESSAGE_HPP

#include <string>

class EnergyCostStatusMessage {

    public:
	EnergyCostStatusMessage(const std::string &name, const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &cost, const int& iteration, const int& loop) : name(name), logicalTimestamp(logicalTimestamp), source(source), target(target), freq(freq), cost(cost), iteration(iteration), loop(loop){};
        
        std::string getName() const { return this->name;};
        int getLogicalTimestamp() const {return this->logicalTimestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        int getFreq() const {return this->freq;};
        std::string getCost() const {return this->cost;};
        int getIteration() const {return this->iteration;};
        int getLoop() const{return this->loop;};

    private:
        std::string name;
        int logicalTimestamp;
        std::string source;
        std::string target;
        int freq;
        std::string cost;
        int iteration;
        int loop;
};

#endif 