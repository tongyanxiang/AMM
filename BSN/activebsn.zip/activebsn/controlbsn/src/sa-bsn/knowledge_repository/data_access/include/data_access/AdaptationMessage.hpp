#ifndef ADAPTATION_MESSAGE_HPP
#define ADAPTATION_MESSAGE_HPP

#include <string>

class AdaptationMessage {

    public:
        AdaptationMessage(const std::string &name, const int &logicalTimestamp, const std::string &source, const std::string &target, const std::string &content) : name(name), logicalTimestamp(logicalTimestamp), source(source), target(target), content(content){};

        std::string getName() const { return this->name;};
        int getLogicalTimestamp() const {return this->logicalTimestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        std::string getContent() const {return this->content;};

    private:
        std::string name;
        int logicalTimestamp;
        std::string source;
        std::string target;
        std::string content;
};

#endif 