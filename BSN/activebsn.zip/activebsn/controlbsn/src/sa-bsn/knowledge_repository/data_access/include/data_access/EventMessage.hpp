#ifndef EVENT_MESSAGE_HPP
#define EVENT_MESSAGE_HPP

#include <string>

class EventMessage {

    public:
        EventMessage(const std::string &name, const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &event) : name(name), logicalTimestamp(logicalTimestamp), source(source), target(target), freq(freq), event(event){};

        std::string getName() const { return this->name;};
        int getLogicalTimestamp() const {return this->logicalTimestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        int getFreq() const {return this->freq;};
        std::string getEvent() const {return this->event;};

    private:
        std::string name;
        int logicalTimestamp;
        std::string source;
        std::string target;
        int freq;
        std::string event;
};

#endif 