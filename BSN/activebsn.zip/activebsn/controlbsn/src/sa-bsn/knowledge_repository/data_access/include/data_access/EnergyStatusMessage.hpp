#ifndef ENERGY_STATUS_MESSAGE_HPP
#define ENERGY_STATUS_MESSAGE_HPP

#include <string>

class EnergyStatusMessage {

    public:
	EnergyStatusMessage(const std::string &name, const int &logicalTimestamp, const std::string &source, const std::string &target, const int &freq, const std::string &cost) : name(name), logicalTimestamp(logicalTimestamp), source(source), target(target), freq(freq), cost(cost){};
        
        std::string getName() const { return this->name;};
        int getLogicalTimestamp() const {return this->logicalTimestamp;};
        std::string getSource() const {return this->source;};
        std::string getTarget() const {return this->target;};
        int getFreq() const {return this->freq;};
        std::string getCost() const {return this->cost;};

    private:
        std::string name;
        int logicalTimestamp;
        std::string source;
        std::string target;
        int freq;
        std::string cost;
};

#endif 