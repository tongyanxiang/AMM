#include <fstream>
#include <sys/stat.h>

#include "ros/package.h"
#include "services/PatientData.h"

#include "libbsn/generator/DataGenerator.hpp"
#include "libbsn/range/Range.hpp"
#include "libbsn/utils/utils.hpp"

#include "archlib/ROSComponent.hpp"

class PatientModule : public arch::ROSComponent {
    public:
        PatientModule(int &argc, char **argv, std::string name);
        ~PatientModule();

        void setUp();
        void tearDown();
        void body();
        
    private:
        // Evaluation
        int random_seed;     
        int seed_count;   
        std::map<std::string, int> logicalTimestamps;   
        std::map<std::string, int> sensorFreqs;

        // Tracing
        bool data_tracing;
        std::fstream fp;
        std::string patient_g3t1_1_filepath, patient_g3t1_2_filepath, patient_g3t1_3_filepath;
        std::string patient_g3t1_4_filepath, patient_g3t1_5_filepath, patient_g3t1_6_filepath;

        bool getPatientData(services::PatientData::Request &request, services::PatientData::Response &response);
        bsn::generator::DataGenerator configureDataGenerator(const std::string& vitalSign);

        std::map<std::string, bsn::generator::DataGenerator> patientData;
        std::map<std::string, double> vitalSignsFrequencies;
        std::map<std::string, double> vitalSignsChanges;
        std::map<std::string, double> vitalSignsOffsets;
        std::map<std::string, double> vitalSignsSeconds;

        ros::NodeHandle nh;
        ros::ServiceServer service;
};