#include <PatientModule.hpp>

PatientModule::PatientModule(int  &argc, char **argv, std::string name) : ROSComponent(argc, argv, name) {}

PatientModule::~PatientModule() {}

void PatientModule::setUp() {
    // Get start physical time from physicalTimer.txt writen in script
    std::string timer_path = ros::package::getPath("patient") + "/../../physicalTimer.txt";

    std::ifstream fin(timer_path);
    if (!fin) {
        std::cerr << "[setUp] Could not read physicalTimer.txt!\n"; 
    } else {
        std::string timer_str;
        fin >> timer_str;
        time_ref = atoi(timer_str.c_str());
    }
    std::cout << "[setUp] time_ref=" << time_ref << std::endl;

    // Service
    service = nh.advertiseService("getPatientData", &PatientModule::getPatientData, this);

    // Random 
    nh.getParam("/patient/random_seed", random_seed);
    seed_count = 0;

    // Get and set frequency
    double freq;
    nh.getParam("/patient/frequency", freq);
    rosComponentDescriptor.setFreq(freq);

    // Get what vital signs this module will simulate
    std::string vitalSigns;
    nh.getParam("/patient/vitalSigns", vitalSigns);

    // Removes white spaces from vitalSigns
    vitalSigns.erase(std::remove(vitalSigns.begin(), vitalSigns.end(),' '), vitalSigns.end());

    std::vector<std::string> splittedVitalSigns = bsn::utils::split(vitalSigns, ',');
    double aux;
    for (std::string s : splittedVitalSigns) {
        vitalSignsFrequencies[s] = 0;       
        nh.getParam("/patient/" + s + "_Change", aux);
        vitalSignsChanges[s] = 1/aux;
        nh.getParam("/patient/" + s + "_Offset", vitalSignsOffsets[s]);
        vitalSignsSeconds[s] = vitalSignsOffsets[s] + vitalSignsChanges[s];
    }

    for (const std::string& s : splittedVitalSigns) {
        patientData[s] = configureDataGenerator(s);
    }

    // Tracing 
    nh.getParam("/patient/data_tracing", data_tracing);

    // Remove old trace directory
    std::string trace_dir = ros::package::getPath("patient") + "/traces";
    struct stat st;
    if (stat(trace_dir.c_str(), &st) != -1) {
        std::string rmCommand = "rm -r " + trace_dir;
        system(rmCommand.c_str());
    }

    if (data_tracing) {
        // Make new trace directory
        std::string makeCommand = "mkdir -p " + trace_dir;
        system(makeCommand.c_str());

        patient_g3t1_1_filepath = trace_dir + "/patient_g3t1_1_oxigenation_trace.txt";
        fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();

        patient_g3t1_2_filepath = trace_dir + "/patient_g3t1_2_heart_rate_trace.txt";
        fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();

        patient_g3t1_3_filepath = trace_dir + "/patient_g3t1_3_temperature_trace.txt";
        fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();

        patient_g3t1_4_filepath = trace_dir + "/patient_g3t1_4_abps_trace.txt";
        fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();

        patient_g3t1_5_filepath = trace_dir + "/patient_g3t1_5_abpd_trace.txt";
        fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();

        patient_g3t1_6_filepath = trace_dir + "/patient_g3t1_6_glucose_trace.txt";
        fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::trunc);
        fp << "logicalTime(s),logicalTimestamp(ms),physicalTime(s),physicalTimestamp(ms),vitalSign,sensorFreq,sensorData\n";
        fp.close();
    }    
}

bsn::generator::DataGenerator PatientModule::configureDataGenerator(const std::string& vitalSign) {
    std::vector<std::string> t_probs;
    std::array<float, 25> transitions;
    std::array<bsn::range::Range,5> ranges;
    std::array<std::uniform_real_distribution<double>,5> valueGenerators;
    std::string s;
    ros::NodeHandle handle;

    for(uint32_t i = 0; i < transitions.size(); i++){
        for(uint32_t j = 0; j < 5; j++){
            nh.getParam("/patient/" + vitalSign + "_State" + std::to_string(j), s);
            t_probs = bsn::utils::split(s, ',');
            for(uint32_t k = 0; k < 5; k++){
                transitions[i++] = std::stod(t_probs[k]);
            }
        }
    }
    
    std::vector<std::string> lrs,mrs0,hrs0,mrs1,hrs1;

    nh.getParam("/patient/" + vitalSign + "_LowRisk", s);
    lrs = bsn::utils::split(s, ',');
    nh.getParam("/patient/" + vitalSign + "_MidRisk0", s);
    mrs0 = bsn::utils::split(s, ',');
    nh.getParam("/patient/" + vitalSign + "_HighRisk0", s);
    hrs0 = bsn::utils::split(s, ',');
    nh.getParam("/patient/" + vitalSign + "_MidRisk1", s);
    mrs1 = bsn::utils::split(s, ',');
    nh.getParam("/patient/" + vitalSign + "_HighRisk1", s);
    hrs1 = bsn::utils::split(s, ',');

    ranges[0] = bsn::range::Range(std::stod(hrs0[0]), std::stod(hrs0[1]));
    ranges[1] = bsn::range::Range(std::stod(mrs0[0]), std::stod(mrs0[1]));
    ranges[2] = bsn::range::Range(std::stod(lrs[0]), std::stod(lrs[1]));
    ranges[3] = bsn::range::Range(std::stod(mrs1[0]), std::stod(mrs1[1]));
    ranges[4] = bsn::range::Range(std::stod(hrs1[0]), std::stod(hrs1[1]));
  
    // State transition probability generator
    std::uniform_int_distribution<int> probabilityGenerator(1,100);

    // Value generators
    valueGenerators[0] = std::uniform_real_distribution<double> (ranges[0].getLowerBound(), ranges[0].getUpperBound());
    valueGenerators[1] = std::uniform_real_distribution<double> (ranges[1].getLowerBound(), ranges[1].getUpperBound());
    valueGenerators[2] = std::uniform_real_distribution<double> (ranges[2].getLowerBound(), ranges[2].getUpperBound());
    valueGenerators[3] = std::uniform_real_distribution<double> (ranges[3].getLowerBound(), ranges[3].getUpperBound());
    valueGenerators[4] = std::uniform_real_distribution<double> (ranges[4].getLowerBound(), ranges[4].getUpperBound());

    // Random  
    std::mt19937 rng;
    if (random_seed == -1) {
        std::random_device rd;
        rng.seed(rd());

    } else if (random_seed >= 0) {
        int dataSeed = 10000 + 1000*seed_count + random_seed;
        rng.seed(dataSeed);
    }
    seed_count += 1;

    bsn::generator::Markov markov(transitions, ranges, 2);
    bsn::generator::DataGenerator dataGenerator(markov, probabilityGenerator, valueGenerators, rng);

    return dataGenerator;
}

void PatientModule::tearDown() {}

bool PatientModule::getPatientData(services::PatientData::Request &request, 
                                   services::PatientData::Response &response) {

    // Request
    logicalTimestamps[request.vitalSign] = request.logicalTimestamp; 
    sensorFreqs[request.vitalSign] = request.sensorFreq; 

    // Response
    response.data = patientData[request.vitalSign].getValue();
    
    std::cout << "[t=" << request.logicalTimestamp << "] Send " + request.vitalSign + " data=" << response.data << std::endl;

    // Tracing   
    if (data_tracing) {
        physicalTimestamp = this->nowInMilliSecond() - time_ref;

        if (request.vitalSign == "oxigenation") {fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "heart_rate") {fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "temperature") {fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
        else if (request.vitalSign == "abps") {fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (request.vitalSign == "abpd") {fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
        else if (request.vitalSign == "glucose") {fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

        fp << ceil(request.logicalTimestamp/1000.0) << ",";
        fp << request.logicalTimestamp << ",";
        fp << ceil(physicalTimestamp/1000.0) << ",";
        fp << physicalTimestamp << ",";
        fp << request.vitalSign << ",";
        fp << request.sensorFreq << ",";     
        fp << response.data << "\n";            
        fp.close();         
    }

    return true;
}

void PatientModule::body() {
    for (auto &p : vitalSignsFrequencies) {
        int randomNumber = -1;

        double logicalSeconds = logicalTimestamps[p.first]/1000.0;
        if (logicalSeconds >= vitalSignsSeconds[p.first]) {
            randomNumber = patientData[p.first].nextState();
            vitalSignsSeconds[p.first] += vitalSignsOffsets[p.first];

            std::cout << "[t=" << logicalTimestamps[p.first] << "] Changed " + p.first + " state randomNumber=" << randomNumber << std::endl;

            // Tracing        
            if (data_tracing) {
                physicalTimestamp = this->nowInMilliSecond() - time_ref;

                if (p.first == "oxigenation") {fp.open(patient_g3t1_1_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "heart_rate") {fp.open(patient_g3t1_2_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "temperature") {fp.open(patient_g3t1_3_filepath, std::fstream::in | std::fstream::out | std::fstream::app);} 
                else if (p.first == "abps") {fp.open(patient_g3t1_4_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                else if (p.first == "abpd") {fp.open(patient_g3t1_5_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}
                else if (p.first == "glucose") {fp.open(patient_g3t1_6_filepath, std::fstream::in | std::fstream::out | std::fstream::app);}

                fp << ceil(logicalTimestamps[p.first]/1000.0) << ",";
                fp << logicalTimestamps[p.first] << ",";
                fp << ceil(physicalTimestamp/1000.0) << ",";
                fp << physicalTimestamp << ",";
                fp << randomNumber << ",";   
                fp << "Changed " + p.first + " state\n";         
                fp.close();    
            }
        } 
    }
}