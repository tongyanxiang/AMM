#ifndef RELIABILITYENGINE_HPP
#define RELIABILITYENGINE_HPP

#include "archlib/Strategy.h"

#include "engine/Engine.hpp"

class ReliabilityEngine : public Engine {
	
	public: 
		ReliabilityEngine(int &argc, char **argv, std::string name);
    	virtual ~ReliabilityEngine();

        void setUp();
    	void tearDown();
        
		std::string get_prefix();

		std::map<std::string, int> initialize_priority(std::vector<std::string>);
		std::map<std::string, double> initialize_strategy(std::vector<std::string>);

		void monitor();
    	void analyze();
		void plan();
    	void execute();

    private:
      	ReliabilityEngine(const ReliabilityEngine &);
    	ReliabilityEngine &operator=(const ReliabilityEngine &);

        double setpoint;
		double offset;
		double gain;
        double tolerance;

        int cycles;

		std::string prefix;

		ros::Publisher enact;
};

#endif 