#ifndef ENGINE_HPP
#define ENGINE_HPP

#include <fstream>
#include <sys/stat.h>

#include "ros/package.h"
#include "lepton/Lepton.h"

#include "archlib/DataAccessRequest.h"
#include "archlib/EngineRequest.h"
#include "archlib/Exception.h"

#include "libbsn/goalmodel/Node.hpp"
#include "libbsn/goalmodel/Goal.hpp"
#include "libbsn/goalmodel/Task.hpp"
#include "libbsn/goalmodel/Property.hpp"
#include "libbsn/goalmodel/LeafTask.hpp"
#include "libbsn/goalmodel/Context.hpp"
#include "libbsn/goalmodel/GoalTree.hpp"
#include "libbsn/model/Formula.hpp"
#include "libbsn/utils/utils.hpp"

#include "archlib/ROSComponent.hpp"

class Engine : public arch::ROSComponent {
	
	public: 
		Engine(int &argc, char **argv, std::string name);
    	virtual ~Engine();

        virtual void setUp();
    	virtual void tearDown();
		virtual void body();

		void receiveException(const archlib::Exception::ConstPtr& msg);
		bool sendAdaptationParameter(archlib::EngineRequest::Request &req, archlib::EngineRequest::Response &res);

		virtual std::string get_prefix() = 0;
		virtual std::map<std::string, int> initialize_priority(std::vector<std::string>) = 0;
		virtual std::map<std::string, double> initialize_strategy(std::vector<std::string>) = 0;
		std::string fetch_formula(std::string);
		void setUp_formula(std::string formula);

	  	double calculate_qos(bsn::model::Formula, std::map<std::string, double>);
	  	bool blacklisted(std::map<std::string,double> &);

		virtual void monitor() = 0;
    	virtual void analyze() = 0;
    	virtual void plan()    = 0;
    	virtual void execute() = 0;

		int monitor_freq;
		int actuation_freq;
		int time_window;

		bsn::model::Formula target_system_model;
		std::map<std::string, double> strategy;
		std::map<std::string, int> priority;
		std::map<std::string, int> deactivatedComponents;

		ros::ServiceServer enactor_server;

	private: 
	    Engine(const Engine &);
    	Engine &operator=(const Engine &);

		std::string qos_attribute;
};

#endif 