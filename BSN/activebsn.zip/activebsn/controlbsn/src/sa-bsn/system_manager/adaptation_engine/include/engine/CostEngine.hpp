#ifndef COSTENGINE_HPP
#define COSTENGINE_HPP

#include "archlib/Strategy.h"

#include "engine/Engine.hpp"

class CostEngine : public Engine {
	
	public: 
		CostEngine(int &argc, char **argv, std::string name);
    	virtual ~CostEngine();

        void setUp();
    	void tearDown();

		std::string get_prefix();

		std::map<std::string, int> initialize_priority(std::vector<std::string>);
		std::map<std::string, double> initialize_strategy(std::vector<std::string>);

		void monitor();
    	void analyze();
		void plan();
    	void execute();

		// Tracing
		bool data_tracing;

		std::fstream fp;
		std::string cost_engine_filepath;

	private: 
	    CostEngine(const CostEngine &);
    	CostEngine &operator=(const CostEngine &);

        double setpoint;
		double offset;
		double gain;
		double tolerance;

        int cycles;

		std::string prefix;

		ros::Publisher enact;
};

#endif 