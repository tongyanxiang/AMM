#ifndef OBSERVATION_HPP
#define OBSERVATION_HPP

class Observation {

    public:
        Observation(const std::string &name, const int &logicalTimestamp, const int &physicalTimestamp, const std::string &component, const double &freq_double, const int &freq, const double &cost) : name(name), logicalTimestamp(logicalTimestamp), physicalTimestamp(physicalTimestamp), component(component), freq_double(freq_double), freq(freq), cost(cost){};

        std::string getName() const { return this->name;};
        int getLogicalTimestamp() const {return this->logicalTimestamp;};
        int getPhysicalTimestamp() const {return this->physicalTimestamp;};
        std::string getComponent() const {return this->component;};
        double getFreqDouble() const {return this->freq_double;};
        int getFreq() const {return this->freq;};
        double getCost() const {return this->cost;};

    private:
        std::string name;
        int logicalTimestamp;
        int physicalTimestamp;
        std::string component;
        double freq_double;
        int freq;
        double cost;
};

#endif 