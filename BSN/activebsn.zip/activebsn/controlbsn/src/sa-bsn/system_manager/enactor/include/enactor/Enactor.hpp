#ifndef ENACTOR_HPP
#define ENACTOR_HPP

#include <deque>
#include <fstream>
#include <sys/stat.h>
#include <python3.8/Python.h>

#include "ros/package.h"

#include "archlib/Event.h"
#include "archlib/Status.h"
#include "archlib/Exception.h"
#include "archlib/Strategy.h"
#include "archlib/AdaptationCommand.h"
#include "archlib/DataPersistFinished.h"

#include "archlib/DataAccessRequest.h"
#include "archlib/EngineRequest.h"

#include "libbsn/utils/utils.hpp"
#include "archlib/ROSComponent.hpp"

#include "Observation.hpp"      

class Enactor : public arch::ROSComponent {
	
    public:
    	Enactor(int &argc, char **argv, std::string name);
    	virtual ~Enactor();	

        virtual void setUp() = 0;
    	virtual void tearDown();
		virtual void body();

	  	void receiveStatus();
	  	void receiveStrategy(const archlib::Strategy::ConstPtr& msg);
		void receiveAdaptationParameter();

	  	virtual void receiveEvent(const archlib::Event::ConstPtr& msg) = 0;
		virtual void apply_cost_strategy(const std::string &component) = 0;

		// General settings
		std::string sys_mode;  

        // Identification 
        int sampling_num;
        int sampling_cnt = 0;
		std::vector<int> temp_ident_freqs;
        std::vector<int> ident_g3t1_1_freqs, ident_g3t1_2_freqs, ident_g3t1_3_freqs, ident_g3t1_4_freqs, ident_g3t1_5_freqs, ident_g3t1_6_freqs;

        void loadSamplingFreqs();

		// Control
		int time_window; 

		double setpoint;
		std::map<std::string, double> nominal_B;
		double pole;

		int min_freq;
		int max_freq;
		int max_delta_freq;

		// Model deviation
		std::string deviation_mode;
		int deviation_B_index;
		std::string deviation_component;
		int deviation_start_timestamp;
		int deviation_end_timestamp;

		std::map<std::string, int> old_freq;
		std::map<std::string, int> deviation_freq;

		// Supervision 
        bool logging = false;
		std::string supervision_type; // AMM

       	PyObject *pInstance;
		std::string sup_components[6];
		int sup_freqs[6];
		double sup_costs[6];

		void AMMInterface(std::string sup_components[], int sup_freqs[], double sup_cost[]);
	
        // AMM
        std::string AS_trigger_mode; 
        std::string AS_design_mode; 
        int timing_interval; 
        int rnd_seed; 
		int alarm[6] = {0};

		// Auxiliary signal
		std::map<std::string, int> activeFlag;
		std::map<std::string, int> optAS;

		// Recovery auxiliary signal
		std::map<std::string, int> recoveryAS;
		std::map<std::string, int> timer;
		int stable_loop;

		// Tracing
		bool data_tracing;
		
		std::vector<Observation> g3t1_vec;

        std::fstream fp;
		std::string g3t1_plant_filepath;
		std::string g3t1_detector_filepath;
		std::string g3t1_1_plant_filepath, g3t1_2_plant_filepath, g3t1_3_plant_filepath, g3t1_4_plant_filepath, g3t1_5_plant_filepath, g3t1_6_plant_filepath;
		std::string g3t1_1_detector_filepath, g3t1_2_detector_filepath, g3t1_3_detector_filepath, g3t1_4_detector_filepath, g3t1_5_detector_filepath, g3t1_6_detector_filepath;

		void flush();

    private:
      	Enactor(const Enactor &);	
    	Enactor &operator=(const Enactor &);

	protected:
		ros::Publisher adapt;
		ros::Publisher except;
		
		// Receive the DataPersistFinished msg
		ros::Subscriber persistFinished;
		
		std::map<std::string, int> exception_buffer;
		std::map<std::string, double> freq_double;
		std::map<std::string, int> freq;
		std::map<std::string, double> curr_value;
		std::map<std::string, double> ref_value;
		std::map<std::string, int> replicate_task;

		int64_t cycles;
		double stability_margin;
		std::string adaptation_parameter;

		// Mark the data collection finishing of the sensors
		bool dataPersistFinished;

		// Mark the iteration
		int currentIteration;
		void receiveDataPersistFinished(const archlib::DataPersistFinished::ConstPtr& msg);
};

#endif 