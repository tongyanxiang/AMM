#ifndef ROSCOMPONENT_DESCRIPTOR_H
#define ROSCOMPONENT_DESCRIPTOR_H

#include "ros/ros.h"

namespace arch {
	class ROSComponentDescriptor {

		public:
			ROSComponentDescriptor();
			virtual ~ROSComponentDescriptor();

		private:
			ROSComponentDescriptor(const ROSComponentDescriptor &);
			ROSComponentDescriptor &operator=(const ROSComponentDescriptor &);

		public:
			void setName(const std::string &name);
			std::string getName() const;

			void setFreq(const double &freq);
			double getFreq() const;

			void setAccelerationFactor(const int &acceleration_factor);
			double getAccelerationFactor() const;

		private:
			std::string name;
			double freq;
			int acceleration_factor = 1; // simulation acceleration
	};
}

#endif