#ifndef NOISEGENERATOR_HPP
#define NOISEGENERATOR_HPP

#include <iostream>
#include <array> 
#include <random>
#include <stdint.h>

namespace bsn {
    namespace generator {
        class NoiseGenerator {
            public:
                NoiseGenerator();
                NoiseGenerator(const std::string &component, const double &offset, const double &amplitude,
                               const int &durationLow, const int &durationHigh, const int &ramp, const int &begin,
                               const std::array<std::normal_distribution<double>,2>& valGens, const std::mt19937& rng);
                ~NoiseGenerator();

                void nextStep();
                double gen_noise(int &timestamp);
                int getStepNum();
                
            private:
                std::string component;
                double offset;
                double amplitude;
                int durationLow;
                int durationHigh;
                int ramp;
                int begin;
   
                std::array<std::normal_distribution<double>,2> valueGenerators;
                std::mt19937 rng;

                bool initFlag = true;
                int stepNum = 0;

                int rampBegin;
                int rampEnd;
                double rampDelta;

                int period; 
                double value;  
        };
    }
}

#endif