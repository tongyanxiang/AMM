#ifndef DATAGENERATOR_HPP
#define DATAGENERATOR_HPP

#include <random>
#include <stdint.h>

#include "libbsn/generator/Markov.hpp"

namespace bsn {
    namespace generator {
        class DataGenerator {
            public:
                DataGenerator();
                DataGenerator(const Markov& markov, const std::uniform_int_distribution<int>& probGens, const std::array<std::uniform_real_distribution<double>,5>& valGens, const std::mt19937& rng);
                DataGenerator(const DataGenerator& obj);
                ~DataGenerator();

                DataGenerator& operator=(const DataGenerator& obj);
                
                double getValue();
                void setSeed();
                int nextState();

            private:
                double calculateValue();

                Markov markovChain;
                double value;

                std::uniform_int_distribution<int> probabilityGenerator;
                std::array<std::uniform_real_distribution<double>,5> valueGenerators;
                std::mt19937 rng;
        };
    }
}

#endif