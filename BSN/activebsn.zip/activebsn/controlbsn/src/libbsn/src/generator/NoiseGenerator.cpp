#include "libbsn/generator/NoiseGenerator.hpp"

namespace bsn {
    namespace generator {
        NoiseGenerator::NoiseGenerator() : component(), offset(), amplitude(), durationLow(), durationHigh(), ramp(), begin(), valueGenerators(), rng(){}
        
        NoiseGenerator::NoiseGenerator(const std::string &component, const double &offset, const double &amplitude,
                                       const int &durationLow, const int &durationHigh, const int &ramp, const int &begin,
                                       const std::array<std::normal_distribution<double>,2>& valGens, const std::mt19937& rng) : 
            component(component), 
            offset(offset),
            amplitude(amplitude),
            durationLow(durationLow),
            durationHigh(durationHigh),
            ramp(ramp),
            begin(begin),
            valueGenerators(valGens),
            rng(rng) {}

        NoiseGenerator::~NoiseGenerator() {}

        void NoiseGenerator::nextStep() {
            rampBegin = period;
            rampEnd = rampBegin + ramp;

            if (stepNum%2 == 0) {
                period += durationLow;
            } else if (stepNum%2 == 1) {
                period += durationHigh;
            }

            stepNum++;
            std::cout << "[nextStep] stepNum=" << stepNum << ", period=" << period << std::endl;
        }
        
        double NoiseGenerator::gen_noise(int &timestamp) {    
            // init
            if (initFlag) {
                rampBegin = begin;
                rampEnd = rampBegin + ramp;
                rampDelta = (amplitude - offset)/(ramp*1000);

                period = begin;
                initFlag = false;

                std::cout << "[init] stepNum=" << stepNum << ", rampBegin=" << rampBegin << ", rampEnd=" << rampEnd << ", period=" << period << std::endl;
            }

            // noise generation
            value = 0.0;
            if (timestamp <= begin*1000){
                value = valueGenerators[0](rng);
                std::cout << "[t=" << timestamp << "] begin stepNum=" << stepNum<< ", period=" << period << ", value=" << value << std::endl;

            } else {     
                if (timestamp > period*1000) {
                    nextStep();
                }

                if (timestamp <= period*1000 && stepNum%2 == 0) {
                    if (timestamp >= rampBegin*1000 && timestamp < rampEnd*1000) {
                        value = valueGenerators[1](rng) - rampDelta*(timestamp - rampBegin*1000);
                    } else {
                        value = valueGenerators[0](rng);
                    }

                } else if (timestamp <= period*1000 && stepNum%2 == 1) {
                    if (timestamp >= rampBegin*1000 && timestamp < rampEnd*1000) {
                        value = valueGenerators[0](rng) + rampDelta*(timestamp - rampBegin*1000);
                    } else {
                        value = valueGenerators[1](rng);
                    }
                } 

                std::cout << "[t=" << timestamp << "] stepNum=" << stepNum << ", period=" << period << ", value=" << value << std::endl;
            }

            return value;
        }

        int NoiseGenerator::getStepNum() {
            return stepNum;
        }
        
    } // namespace generator
} // namespace bsn