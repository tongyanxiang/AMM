#include "libbsn/generator/DataGenerator.hpp"
#include "libbsn/range/Range.hpp"

namespace bsn {
    namespace generator {
        DataGenerator::DataGenerator() : markovChain(), probabilityGenerator(), valueGenerators(), rng() {}

        DataGenerator::DataGenerator(const Markov& markov, const std::uniform_int_distribution<int>& probGens, const std::array<std::uniform_real_distribution<double>,5>& valGens, const std::mt19937& rng) : 
            markovChain(markov),
            probabilityGenerator(probGens),
            valueGenerators(valGens),
            rng(rng) {}

        DataGenerator::DataGenerator(const DataGenerator& obj) :
            markovChain(obj.markovChain),
            probabilityGenerator(obj.probabilityGenerator),
            valueGenerators(obj.valueGenerators),
            rng(obj.rng) {}

        DataGenerator::~DataGenerator() {}

        DataGenerator& DataGenerator::operator=(const DataGenerator& obj) {
            markovChain = obj.markovChain;
            probabilityGenerator = obj.probabilityGenerator;
            valueGenerators = obj.valueGenerators;
            rng = obj.rng;
            return (*this);
        }

        int DataGenerator::nextState() {
            int randomNumber = probabilityGenerator(rng);
       
            int offset = markovChain.currentState * 5;
            
            if (randomNumber <= markovChain.transitions[offset]) {
                markovChain.currentState = 0;                        
            }    
            else if (randomNumber <= markovChain.transitions[offset + 1]) {
                markovChain.currentState = 1;             
            }    
            else if (randomNumber <= markovChain.transitions[offset + 2]) {
                markovChain.currentState = 2;
            }     
            else if (randomNumber <= markovChain.transitions[offset + 3]) {
                markovChain.currentState = 3;        
            }    
            else if (randomNumber <= markovChain.transitions[offset + 4]) {
                markovChain.currentState = 4;
            }

            return randomNumber;
        }

        double DataGenerator::calculateValue() {
            if (markovChain.currentState > 4 || markovChain.currentState < 0){
                throw std::out_of_range("current state is out of bounds");
            }

            if (markovChain.currentState == 0) {
                value = valueGenerators[0](rng);

            } else if (markovChain.currentState == 1) {
                value = valueGenerators[1](rng);

            } else if (markovChain.currentState == 2) {
                value = valueGenerators[2](rng);

            } else if (markovChain.currentState == 3) {
                value = valueGenerators[3](rng);

            } else if (markovChain.currentState == 4) {
                value = valueGenerators[4](rng);
                
            } else {
                value = 0.0;
            }

            return value;
        }

        double DataGenerator::getValue() {
            return calculateValue();
        }
    }
    
} // namespace bs 