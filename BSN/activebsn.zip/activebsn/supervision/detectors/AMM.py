import random
import numpy as np

from sklearn.linear_model import LinearRegression
from scipy import stats
from cvxopt import matrix, solvers

np.set_printoptions(suppress=True, precision=10, threshold=2000, linewidth=150)
solvers.options['maxiters'] = 10
solvers.options['show_progress'] = False


def degradation_detector(index, delta):
    # error sigma
    var = np.array([[0.0905, 0.0, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0950, 0.0, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.1010, 0.0, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 0.0912, 0.0, 0.0],
                    [0.0, 0.0, 0.0, 0.0, 0.0936, 0.0],
                    [0.0, 0.0, 0.0, 0.0, 0.0, 0.0972]])

    # alarm if the derived probability that model parameter value
    # falls into safe region does not exceed the probability threshold
    prob_6sigma = 0.999999981  # 6sigma
    loc = 0.0
    scale = np.sqrt(var[index][index])

    if delta <= loc:
        cdf = stats.norm.cdf(delta, loc, scale)
    else:
        cdf = 1.0 - stats.norm.cdf(delta, loc, scale)

    alarm = 0
    if cdf < (1.0 - prob_6sigma) / 2:
        alarm = 1

    return alarm


class AMM:
    # Active Monitoring Mechanism

    def __init__(self, logging, auxiliary_signal_trigger_mode, auxiliary_signal_design_mode):

        self.logging = logging
        self.counting = 0

        # "combine_trigger"/"prior_trigger"/"posterior_trigger"/"timing_trigger"
        self.auxiliary_signal_trigger_mode = auxiliary_signal_trigger_mode

        # "optimal_design"/"random_design"
        self.auxiliary_signal_design_mode = auxiliary_signal_design_mode

        # ****************************  knowledge section ****************************
        # nominal model parameters
        # x(k) = A*x(k-1) + B*u(k-1)
        # y(k) = C*x(k)
        self.A = np.zeros((6, 6))

        self.B = np.array([[0.15, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.15, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.15, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.15, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.15, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 0.15]])
          
        self.C = 1.0 * np.eye(6)

        # deviated model parameter
        self.B_k_prior = np.copy(self.B)  # using copy to avoid B_k_prior and B_k_posterior change together
        self.P_k_prior = 1.0e-05 * np.eye(6)  # estimate uncertainty
        self.B_k_posterior = np.copy(self.B)
        self.P_k_posterior = 1.0e-05 * np.eye(6)
        self.B_k_predict = np.copy(self.B)
        self.P_k_predict = 1.0e-05 * np.eye(6)

        # system state
        self.delta_state_prior = np.zeros((6, 6))
        self.delta_state_var_prior = np.zeros((6, 6))
        self.delta_state_posterior = np.zeros((6, 6))
        self.delta_state_var_posterior = np.zeros((6, 6))

        # uncertainty of model parameter value (process noise)
        self.Q = np.array([[6.0e-06, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 7.0e-06, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 6.0e-06, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 7.0e-06, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 6.0e-06, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 7.0e-06]])
        
        # uncertainty compensation terms
        # x(k) = A*x(k-1) + B*u(k-1) + w(k)
        # y(k) = C*x(k) + v(k)
        # -->
        # y(k) = C*A*x(k-1) + C*B*u(k-1) + C*w(k) + v(k)
        self.gamma = np.zeros((6, 6))

        self.W = np.zeros((6, 6))  # measurement error of environment input
        
        self.V = np.array([[8.0e-06, 0.0, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 8.0e-06, 0.0, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 8.0e-06, 0.0, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 8.0e-06, 0.0, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 8.0e-06, 0.0],
                           [0.0, 0.0, 0.0, 0.0, 0.0, 8.0e-06]])
         
        # **************************** passive decision section ****************************
        # safe region of model parameter values
        self.pole = 0.6
        self.safe_region = np.array([[0.0, 1.0 / (1 - self.pole) * self.B[0][0]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[1][1]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[2][2]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[3][3]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[4][4]],
                                     [0.0, 1.0 / (1 - self.pole) * self.B[5][5]]])
        # print("safe_region:\n{}\n".format(self.safe_region))
        
        # probability threshold
        self.prob_threshold = 0.999999998  # 6sigma
        
        self.setpoint = 0.9

        # alarm signal
        self.alarm = np.zeros(6)

        # historical measurements
        self.list_u = []  # historical controller output
        self.list_y = []  # historical managed system output

        # **************************** auxiliary signal trigger section ****************************
        # index range
        self.index_range = [0, 6]

        # active flag
        self.active_flag = np.zeros(6)
        
        # 1) auxiliary_signal_trigger_mode = "combine_trigger"/"prior_trigger"/"posterior_trigger"
        self.prediction_sw = 2

        # use for model prediction
        self.list_B_k_posterior = [[self.B_k_posterior[0][0]], [self.B_k_posterior[1][1]],
                                   [self.B_k_posterior[2][2]], [self.B_k_posterior[3][3]],
                                   [self.B_k_posterior[4][4]], [self.B_k_posterior[5][5]]]

        self.list_P_k_posterior = [[self.P_k_posterior[0][0]], [self.P_k_posterior[1][1]],
                                   [self.P_k_posterior[2][2]], [self.P_k_posterior[3][3]],
                                   [self.P_k_posterior[4][4]], [self.P_k_posterior[5][5]]]

        self.list_B_k_predict = [[self.B_k_posterior[0][0]], [self.B_k_posterior[1][1]],
                                 [self.B_k_posterior[2][2]], [self.B_k_posterior[3][3]],
                                 [self.B_k_posterior[4][4]], [self.B_k_posterior[5][5]]]

        self.list_P_k_predict = [[self.P_k_posterior[0][0]], [self.P_k_posterior[1][1]],
                                 [self.P_k_posterior[2][2]], [self.P_k_posterior[3][3]],
                                 [self.P_k_posterior[4][4]], [self.P_k_posterior[5][5]]]

        self.prediction_B_model = [[1.02802], [1.02155], [1.02678], [1.01877], [1.02749], [1.02501]]
        self.prediction_P_model = [[0.95764], [0.96291], [0.95982], [0.96494], [0.95764], [0.96870]]

        self.active_trigger_threshold = 0.999999998  # 6sigma

        # 2) auxiliary_signal_trigger_mode = "timing_trigger"
        self.supervision_time_interval = 1.0
        self.timing_interval = 10
        self.timer = np.zeros(6)

        # **************************** auxiliary signal design section ****************************
        # 1) auxiliary_signal_design_mode = "optimal_design"
        # constraints
        self.safety_n_sigma = 6
        self.U_constraint = [[1, 20], [1, 20], [1, 20], [1, 20], [1, 20], [1, 20]]
        self.Y_constraint = [[0.0, 1.4], [0.0, 1.4], [0.0, 1.4], [0.0, 1.4], [0.0, 1.4], [0.0, 1.4]]

        # safety auxiliary signal constraints
        self.safety_AS = [[-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19], [-19, 19]]
        
        # action function parameters of the auxiliary signal
        self.T = 1.0
        self.r_C = [1.5, 1.5,
                    1.5, 1.5,
                    1.5, 1.5]

        # safety function parameters of auxiliary signal: 2.0/(Y_low + Y_high)
        self.r_S = [2.0 / (self.Y_constraint[0][0] + self.Y_constraint[0][1]), 2.0 / (self.Y_constraint[1][0] + self.Y_constraint[1][1]),
                    2.0 / (self.Y_constraint[2][0] + self.Y_constraint[2][1]), 2.0 / (self.Y_constraint[3][0] + self.Y_constraint[3][1]),
                    2.0 / (self.Y_constraint[4][0] + self.Y_constraint[4][1]), 2.0 / (self.Y_constraint[5][0] + self.Y_constraint[5][1])]

        # accuracy enhancement function parameters of auxiliary signal
        self.r_D = [1.0 / abs(self.B[0][0]), 1.0 / abs(self.B[1][1]),
                    1.0 / abs(self.B[2][2]), 1.0 / abs(self.B[3][3]),
                    1.0 / abs(self.B[4][4]), 1.0 / abs(self.B[5][5])]

        # optimal auxiliary control signal
        self.opt_AS = np.zeros(6)

        # 2) auxiliary_signal_design_mode = "random_design"
        self.rnd_seed = 1

    def deviation_detector(self, u_1_str, y_str):

        self.counting = self.counting + 1

        # convert string to array
        # 6,6,6,6,6,6
        # 0.9,0.9,0.9,0.9,0.9,0.9
        U_str = u_1_str.strip().split(",")
        Y_str = y_str.strip().split(",")

        u_1 = np.array([[int(U_str[0]), 0.0, 0.0, 0.0, 0.0, 0.0],
                        [0.0, int(U_str[1]), 0.0, 0.0, 0.0, 0.0],
                        [0.0, 0.0, int(U_str[2]), 0.0, 0.0, 0.0],
                        [0.0, 0.0, 0.0, int(U_str[3]), 0.0, 0.0],
                        [0.0, 0.0, 0.0, 0.0, int(U_str[4]), 0.0],
                        [0.0, 0.0, 0.0, 0.0, 0.0, int(U_str[5])]])

        y = np.array([[float(Y_str[0]), 0.0, 0.0, 0.0, 0.0, 0.0],
                      [0.0, float(Y_str[1]), 0.0, 0.0, 0.0, 0.0],
                      [0.0, 0.0, float(Y_str[2]), 0.0, 0.0, 0.0],
                      [0.0, 0.0, 0.0, float(Y_str[3]), 0.0, 0.0],
                      [0.0, 0.0, 0.0, 0.0, float(Y_str[4]), 0.0],
                      [0.0, 0.0, 0.0, 0.0, 0.0, float(Y_str[5])]])
        # print(u_1, y)

        if len(self.list_u) < 3:                            
            self.list_u.append(u_1)
            self.list_y.append(y)
        else:
            self.list_u.append(u_1)
            self.list_y.append(y)

            if self.logging:
                print("********** deviation_detector k=" + str(self.counting) + " **********")

            # state estimation
            # input: time series observation
            #    [0]     [1]     [2]    [3]
            #  u(k-4), u(k-3), u(k-2), u(k-1)
            #  y(k-3), y(k-2), y(k-1), y(k)
            delta_y_2 = self.list_y[1] - self.list_y[0]
            delta_u_2 = self.list_u[2] - self.list_u[1]

            # output: delta_state_prior, delta_state_var_prior
            self.delta_state_posterior, \
            self.delta_state_var_posterior, \
            self.delta_state_prior, \
            self.delta_state_var_prior = self.observer(self.B_k_posterior,
                                                       self.delta_state_prior,
                                                       self.delta_state_var_prior,
                                                       delta_y_2, delta_u_2)
            
            # model parameter estimation and deviation detection
            # input: time series observation
            u_1 = self.list_u[3]
            y_0 = self.list_y[3]
            delta_u_1 = self.list_u[3] - self.list_u[2]
            delta_y_0 = self.list_y[3] - self.list_y[2]

            # output: B_k_posterior, P_k_posterior
            self.B_k_prior, \
            self.P_k_prior, \
            self.B_k_posterior, \
            self.P_k_posterior = self.estimator(self.delta_state_prior,
                                                self.delta_state_var_prior,
                                                self.B_k_prior,
                                                self.P_k_prior,
                                                self.B_k_posterior,
                                                self.P_k_posterior,
                                                delta_u_1, delta_y_0)

            for index in range(self.index_range[0], self.index_range[1]):
                if abs(delta_u_1[index][index]) > 0.0:
                    # passive decision
                    self.alarm[index] = self.passive_alarmer(index,
                                                             self.B_k_posterior[index][index],
                                                             self.P_k_posterior[index][index])

                    # reset auxiliary signal trigger and design
                    self.active_flag[index] = 0
                    self.opt_AS[index] = 0

                    if self.logging:
                        print("\n********** passive decision **********")
                        print("delta_u_1[{}]:{}".format(index, delta_u_1[index][index]))
                        print("delta_y_0[{}]:{}".format(index, delta_y_0[index][index]))
                        print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                        print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))
                        print("B_k_posterior[{}]:{}".format(index, self.B_k_posterior[index][index]))
                        print("P_k_posterior[{}]:{}".format(index, self.P_k_posterior[index][index]))
                        print("alarm[{}]:{}\n".format(index, self.alarm[index]))

                    if abs(delta_u_1[index][index]) > 0:
                        # store historical model parameters
                        self.list_B_k_posterior[index].append(self.B_k_posterior[index][index])
                        self.list_P_k_posterior[index].append(self.P_k_posterior[index][index])
                        self.list_B_k_predict[index].append(self.B_k_posterior[index][index])
                        self.list_P_k_predict[index].append(self.P_k_posterior[index][index])

                        # remove first point
                        if len(self.list_B_k_posterior[index]) > 2.0 * (self.prediction_sw - 1):
                            del (self.list_B_k_posterior[index][0])
                            del (self.list_P_k_posterior[index][0])

                        if len(self.list_B_k_predict[index]) > 2.0 * (self.prediction_sw - 1):
                            del (self.list_B_k_predict[index][0])
                            del (self.list_P_k_predict[index][0])

                else:
                    # when no alarm, continue active part
                    if np.all(self.alarm == 0):
                        # auxiliary signal trigger
                        if self.auxiliary_signal_trigger_mode != "timing_trigger":
                            
                            if self.logging:
                                print("\n********** optimal_trigger index={" + str(index) + "} **********")

                            if len(self.list_B_k_posterior[index]) >= 2.0 * (self.prediction_sw - 1):
                                self.update_prediction_model(index)

                                if self.logging:
                                    print("update_prediction_model...")
                                    print("list_B_k_predict[{}]:{}".format(index, self.list_B_k_predict[index]))
                                    print("list_P_k_predict[{}]:{}".format(index, self.list_P_k_predict[index]))
                                    print("prediction_B_model[{}]:{}".format(index, self.prediction_B_model[index]))
                                    print("prediction_P_model[{}]:{}\n".format(index, self.prediction_P_model[index]))

                            self.active_flag[index] = \
                                self.activate_optimal_trigger(index,
                                                              self.auxiliary_signal_trigger_mode,
                                                              self.B_k_prior[index][index],
                                                              self.P_k_prior[index][index],
                                                              self.prediction_B_model[index],
                                                              self.prediction_P_model[index])
                                
                            if self.logging:
                                print("activate_combine_trigger...")
                                print("delta_u_1[{}]:{}".format(index, delta_u_1[index][index]))
                                print("delta_y_0[{}]:{}".format(index, delta_y_0[index][index]))
                                print("B_k_prior[{}]:{}".format(index, self.B_k_prior[index][index]))
                                print("P_k_prior[{}]:{}".format(index, self.P_k_prior[index][index]))
                                print("B_k_predict[{}]:{}".format(index, self.B_k_predict[index][index]))
                                print("P_k_predict[{}]:{}".format(index, self.P_k_predict[index][index]))
                                print("active_flag[{}]:{}\n".format(index, self.active_flag[index]))

                        elif self.auxiliary_signal_trigger_mode == "timing_trigger":
                            self.active_flag[index] = self.activate_timing_trigger(index)

                            if self.logging:
                                print("\n********** timing_trigger index={" + str(index) + "} **********")
                                print("active_flag[{}]:{}\n".format(index, self.active_flag[index]))
                                
                        # auxiliary signal design
                        if self.active_flag[index] == 1:
                            # safety auxiliary signal
                            self.safety_AS[index] = self.calculate_safety_AS(index, 
                                                                             u_1[index][index],
                                                                             y_0[index][index],
                                                                             self.B_k_prior[index][index],
                                                                             self.P_k_prior[index][index])

                            # optimal auxiliary signal
                            if self.auxiliary_signal_design_mode == "optimal_design":
                                self.opt_AS[index] = self.calculate_optimal_AS(index, self.B_k_posterior[index][index])

                                if self.logging:
                                    print("\n********** optimal_design index={" + str(index) + "} **********")
                                    print("safety_AS[{}]:{}".format(index, self.safety_AS[index]))
                                    print("opt_AS[{}]:{}\n".format(index, self.opt_AS[index]))

                            elif self.auxiliary_signal_design_mode == "random_design":
                                self.opt_AS[index] = self.calculate_random_AS(index)

                                if self.logging:
                                    print("\n********** random_design index={" + str(index) + "} **********")
                                    print("safety_AS[{}]:{}".format(index, self.safety_AS[index]))
                                    print("opt_AS[{}]:{}\n".format(index, self.opt_AS[index]))                                               

                    else:
                        self.opt_AS[index] = 0

            # degradation detector
            for index in range(0, 6):
                if u_1[index][index] == 0 and self.alarm[index] == 0:
                    delta = y_0[index][index] - self.setpoint
                    self.alarm[index] = degradation_detector(index, delta)

            # update historical measurements
            self.list_u.remove(self.list_u[0])
            self.list_y.remove(self.list_y[0])
            
        # transfer with strings
        B_k_prior_str, P_k_prior_str, \
        B_k_posterior_str, P_k_posterior_str, \
        B_k_predict_str, P_k_predict_str, \
        alarm_str, active_flag_str, opt_AS_str = self.transferToString(self.B_k_prior, self.P_k_prior, 
                                                                       self.B_k_posterior, self.P_k_posterior, 
                                                                       self.B_k_predict, self.P_k_predict, 
                                                                       self.alarm, self.active_flag, self.opt_AS)                         
           
        return B_k_prior_str, P_k_prior_str, B_k_posterior_str, P_k_posterior_str, \
               B_k_predict_str, P_k_predict_str, alarm_str, active_flag_str, opt_AS_str

    def observer(self, B_k_posterior, delta_state_prior, delta_state_var_prior, delta_y_2, delta_u_2):
        # refined nominal model
        # delta_y(k-2) = C*delta_x(k-2) + v(k-2)
        # delta_x(k-1) = A*delta_x(k-2) + B*delta_u(k-2) + w(k-1)

        # update process
        # observation model which maps the true state space into the observed space
        H = self.C

        # measurement pre-fit residual
        R_k = delta_y_2 - np.dot(H, delta_state_prior)

        # pre-fit residual variance
        S_k = np.dot(np.dot(H, delta_state_var_prior), H.T) + self.V

        # updated Kalman gain
        K = np.dot(np.dot(delta_state_var_prior, H.T), np.linalg.inv(S_k))

        # updated (a posteriori) state estimate
        delta_state_posterior = delta_state_prior + np.dot(K, R_k)

        # updated (a posteriori) delta_state estimate variance
        delta_state_var_posterior = np.dot((np.eye(len(delta_state_var_prior)) - np.dot(K, H)), delta_state_var_prior)

        # prediction process
        # predicted (a priori) state estimate
        delta_state_prior = np.dot(self.A, delta_state_posterior) + \
                            np.dot(B_k_posterior.T, delta_u_2)

        # predicted (a priori) state estimate variance
        delta_state_var_prior = np.dot(np.dot(self.A, delta_state_var_posterior), self.A) + self.W

        return delta_state_posterior, delta_state_var_posterior, delta_state_prior, delta_state_var_prior

    def estimator(self, delta_state_prior, delta_state_var_prior,
                  B_k_prior, P_k_prior, B_k_posterior, P_k_posterior, delta_u_1, delta_y_0):
        # refined nominal model
        # B(k) = B(k-1) + q(k)
        # delta_y(k) = C*A*delta_x(k) + C*B(k)*delta_u(k-1) + C*w(k) + v(k)

        # prediction process
        for index in range(0, 6):
            if abs(delta_u_1[index][index]) > 0.0:
                # predicted (a priori) model parameter estimate
                B_k_prior[index][index] = B_k_posterior[index][index]

                # predicted (a priori) model parameter estimate variance
                P_k_prior[index][index] = P_k_posterior[index][index] + self.Q[index][index]

            else:
                # keep last B_prior
                B_k_prior[index][index] = B_k_prior[index][index]

                # enlarge P_k_prior as time goes on
                P_k_prior[index][index] = P_k_prior[index][index] + self.Q[index][index]

        # update process
        # observation model which maps the true model parameter space into the observed space
        H = np.dot(self.C, delta_u_1.T)
        # print("H:\n{}".format(H))

        # measurement pre-fit residual
        error = delta_y_0 - (np.dot(np.dot(self.C, self.A), delta_state_prior) + np.dot(H, B_k_prior))
        # print("error:\n{}".format(error))

        # pre-fit residual variance
        S_k = np.dot(np.dot(np.dot(self.C, self.A), delta_state_var_prior), np.dot(self.C, self.A).T) + \
              np.dot(np.dot(H, P_k_prior), H.T) + \
              np.dot(np.dot(self.C, self.W), self.C.T) + self.V
        # print("S_k:\n{}".format(S_k))

        # updated Kalman gain
        K = np.dot(np.dot(P_k_prior, H.T), np.linalg.inv(S_k))
        # print("K:\n{}".format(K))

        # updated (a posteriori) model parameter estimate and its variance or keep the last values
        for index in range(0, 6):

            if abs(delta_u_1[index][index]) > 0.0:
                # updated (a posteriori) model parameter estimate
                B_k_posterior[index][index] = B_k_prior[index][index] + \
                                                       K[index][index] * error[index][index]

                # updated (a posteriori) model parameter estimate variance
                P_k_posterior[index][index] = (1.0 - np.dot(K, H)[index][index]) * P_k_prior[index][index]

            else:
                # keep the last model parameter estimate and its variance
                B_k_posterior[index][index] = B_k_posterior[index][index]
                P_k_posterior[index][index] = P_k_posterior[index][index]

        return B_k_prior, P_k_prior, B_k_posterior, P_k_posterior

    def passive_alarmer(self, index, B_k_posterior, P_k_posterior):
        # alarm if the derived probability that model parameter value
        # falls into safe region exceeds the probability threshold
        loc = B_k_posterior
        scale = np.sqrt(P_k_posterior)

        cdf = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
              stats.norm.cdf(self.safe_region[index][0], loc, scale)

        passive_alarm = 0
        if cdf < self.prob_threshold:
            passive_alarm = 1

        return passive_alarm

    def update_prediction_model(self, index):

        list_B_k_posterior_i = self.list_B_k_posterior[index]
        list_P_k_posterior_i = self.list_P_k_posterior[index]
        sliding_window = self.prediction_sw

        X1 = []
        X2 = []
        Y1 = []
        Y2 = []
        data_slot_num = int(len(list_B_k_posterior_i) / sliding_window)
        for n in range(0, data_slot_num):
            X1.append([])
            X2.append([])

            for i in range(0, self.prediction_sw - 1):
                B_k = list_B_k_posterior_i[sliding_window * n + i]
                P_k = list_P_k_posterior_i[sliding_window * n + i]
                X1[n].append(B_k)
                X2[n].append(P_k)

            B_k = list_B_k_posterior_i[sliding_window * n + sliding_window - 1]
            P_k = list_P_k_posterior_i[sliding_window * n + sliding_window - 1]
            Y1.append(B_k)
            Y2.append(P_k)

        # print("X1: {}".format(X1))
        # print("Y1: {}".format(Y1))
        # print("X2: {}".format(X2))
        # print("Y2: {}".format(Y2))

        model_B_k = LinearRegression(fit_intercept=False)
        model_B_k.fit(X1, Y1)

        list_a_i = []
        for i in range(0, sliding_window - 1):
            a_i = round(model_B_k.coef_[0], 5)
            list_a_i.append(a_i)
            # print("a_{}: {}".format(i + 1, a_i))

        model_P_k = LinearRegression(fit_intercept=False)
        model_P_k.fit(X2, Y2)

        list_b_i = []
        for i in range(0, sliding_window - 1):
            b_i = round(model_P_k.coef_[0], 5)
            list_b_i.append(b_i)
            # print("b_{}: {}".format(i + 1, b_i))

        self.prediction_B_model[index] = list_a_i
        self.prediction_P_model[index] = list_b_i
        
        if self.logging:
            print("update_prediction_model...")
            print("prediction_B_model[{}]: {}".format(index, self.prediction_B_model[index]))
            print("prediction_P_model[{}]: {}\n".format(index, self.prediction_P_model[index]))

    def activate_optimal_trigger(self, index, trigger_mode,
                                 B_k_prior_i, P_k_prior_i, prediction_B_model, prediction_P_model):
        
        prior_active_flag = 0
        if trigger_mode == "prior_trigger" or trigger_mode == "combine_trigger":
            # calculate the probability of model parameter value falls into safe region
            loc = B_k_prior_i
            scale = np.sqrt(P_k_prior_i)
            prior_trigger_indicator = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
                                      stats.norm.cdf(self.safe_region[index][0], loc, scale)

            if prior_trigger_indicator < self.active_trigger_threshold:
                prior_active_flag = 1

        predict_active_flag = 0
        if trigger_mode == "posterior_trigger" or trigger_mode == "combine_trigger":
            if len(self.list_B_k_predict[index]) > 0 and len(self.list_P_k_predict[index]) > 0:
                B_k_predict_i = 0.0
                end_i = len(self.list_B_k_predict[index]) - 1
                for i in range(0, len(prediction_B_model)):
                    B_k_predict_i = B_k_predict_i + prediction_B_model[i] * self.list_B_k_predict[index][end_i - i]

                P_k_predict_i = 0.0
                for i in range(0, len(prediction_P_model)):
                    P_k_predict_i = P_k_predict_i + prediction_P_model[i] * self.list_P_k_predict[index][end_i - i]

                # update predicted B, P and add to list
                self.B_k_predict[index] = B_k_predict_i
                self.P_k_predict[index] = P_k_predict_i
                self.list_B_k_predict[index].append(B_k_predict_i)
                self.list_P_k_predict[index].append(P_k_predict_i)

                if len(self.list_B_k_predict[index]) > 2.0 * (self.prediction_sw - 1):
                    del (self.list_B_k_predict[index][0])
                    del (self.list_P_k_predict[index][0])

                # calculate the probability of model parameter value falls into safe region
                loc = B_k_predict_i
                scale = np.sqrt(P_k_predict_i)
                predict_trigger_indicator = stats.norm.cdf(self.safe_region[index][1], loc, scale) - \
                                            stats.norm.cdf(self.safe_region[index][0], loc, scale)

                if predict_trigger_indicator < self.active_trigger_threshold:
                    predict_active_flag = 1

        active_flag = 0
        if trigger_mode == "prior_trigger":
            active_flag = prior_active_flag
        elif trigger_mode == "posterior_trigger":
            active_flag = predict_active_flag
        elif trigger_mode == "combine_trigger":
            active_flag = prior_active_flag or predict_active_flag

        return active_flag

    def activate_timing_trigger(self, index):
        # update timer
        self.timer[index] = self.timer[index] + self.supervision_time_interval
        # print("timer: {}".format(self.timer[i]))

        active_flag = 0
        if self.timer[index] >= self.timing_interval:
            active_flag = 1

            # reset timer
            self.timer[index] = 0.0

        return active_flag

    def calculate_safety_AS(self, index, u_i, y_i, B_k_prior_i, P_k_prior_i):
        # y(k) = C*B_k*u(k-1) + C*w(k) + v(k)
        # -->
        # u_as_1 = (Y_constraint[0] - y(k) + v(k) + C*w(k))/(C*B_k)
        # u_as_2 = (Y_constraint[1] - y(k) - v(k) - C*w(k))/(C*B_k)

        # model parameter
        C_i = self.C[index][index]
        # print("C_i: {}".format(C_i))

        # max deviation model parameter
        if B_k_prior_i > 0:
            max_B_k = B_k_prior_i + self.safety_n_sigma * np.sqrt(P_k_prior_i)
        else:
            max_B_k = B_k_prior_i - self.safety_n_sigma * np.sqrt(P_k_prior_i)
        # print("max_B_k: {}".format(max_B_k))

        # possible max measurement error
        max_uncertainty = self.safety_n_sigma * np.sqrt(self.V[index][index]) + \
                          C_i * self.safety_n_sigma * np.sqrt(self.W[index][index])
        # print("max_uncertainty: {}".format(max_uncertainty))

        # cost constraint
        Y_constraint_i = self.Y_constraint[index]
        # print("Y_constraint_i: {}".format(Y_constraint_i))

        # compute safety auxiliary signal
        # if cost exceed Y_constraint
        if y_i < Y_constraint_i[0]:
            y_i = Y_constraint_i[0]
        elif y_i > Y_constraint_i[1]:
            y_i = Y_constraint_i[1]
            
        # consider max_B_k>0 or max_B_k<=0
        if max_B_k > 0:
            u_as_1 = (Y_constraint_i[0] - y_i + max_uncertainty) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[1] - y_i - max_uncertainty) / (C_i * max_B_k)
        else:
            u_as_1 = (Y_constraint_i[1] - y_i - max_uncertainty) / (C_i * max_B_k)
            u_as_2 = (Y_constraint_i[0] - y_i + max_uncertainty) / (C_i * max_B_k)
        # print("u_as_1[{}]: {}".format(index, u_as_1))
        # print("u_as_2[{}]: {}".format(index, u_as_2))

        AS_constraint_low_i = self.U_constraint[index][0] - u_i
        AS_constraint_upper_i = self.U_constraint[index][1] - u_i
        # print("AS_constraint_low_i[{}]: {}".format(index, AS_constraint_low_i))
        # print("AS_constraint_upper_i[{}]: {}".format(index, AS_constraint_upper_i))
        
        u_safety_low = max(np.ceil(u_as_1), AS_constraint_low_i)
        u_safety_high = min(np.floor(u_as_2), AS_constraint_upper_i)
        safety_AS_i = [u_safety_low, u_safety_high]
        # print("safety_AS_i: {}".format(safety_AS_i))
        
        return safety_AS_i

    def calculate_optimal_AS(self, index, B_k_posterior_i):
        # multi-objective optimization:
        # 1) minimize operational cost of auxiliary signal
        #          f_C = T*r_C*u'(k)^2
        # 2) maximize system safety under auxiliary signal
        #          f_U = r_S*(0.5*(y_u+y_L)-y'(k+1))^2
        # 3) maximize expected detection improvement
        #          f_D = r_D*y'(k+1)^2
        # subject to: 1) u'(k) ∈ [safety_AS_min, safety_AS_max]
        #             2) y'(k+1) = C*B(k+1)*u'(k)
        # ->
        # max(u') f = f_D + f_U - f_C
        #           = r_D*y'(k+1)^2 + r_S*y'(k+1)^2 - r_S*(y_u+y_L)*y'(k+1) + 0.25*r_S*(y_u+y_L)^2 - T*r_C*u'(k)^2
        #           = (r_D*C^2*B(k+1)^2 + r_S*C^2*B(k+1)^2 - T*r_C)*u'(k)^2 - r_S*(y_u+y_L)*C*B(k+1)*u'(k+1) + 0.25*r_S*(y_u+y_L)^2
        # subject to: u'(k) ∈ [safety_AS_min, safety_AS_max]
        #
        # convert to the standard form of a QP following CVXOPT
        # min(u') 0.5*(-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + 2.0*T*r_C)*u'(k)^2 + r_S*(y_u+y_L)*C*B(k+1)*u'(k+1)
        # subject to: -u'(k) >= safety_AS_min
        #              u'(k) <= safety_AS_max

        # function parameters
        T = self.T
        r_C_i = self.r_C[index]
        r_S_i = self.r_S[index]
        r_D_i = self.r_D[index]
        # print("r_C[{}]: {}".format(index, r_C_i))
        # print("r_S[{}]: {}".format(index, r_S_i))
        # print("r_D[{}]: {}".format(index, r_D_i))
        
        # model parameters
        C_i = self.C[index][index]
        # print("C[{}]: {}".format(index, C_i))
        
        # safety auxiliary signal
        safety_AS_min = self.safety_AS[index][0]
        safety_AS_max = self.safety_AS[index][1]
        # print("safety_AS: [{}, {}]".format(safety_AS_min, safety_AS_max))
        
        # optimization matrices
        # x = [u'(k)]
        # P = [-2.0*r_D*C^2*B(k+1)^2 - 2.0*r_S*C^2*B(k+1)^2 + T*r_C]
        P_0_0 = -2.0 * r_D_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) \
                - 2.0 * r_S_i * pow(C_i, 2) * pow(B_k_posterior_i, 2) + T * r_C_i

        P = matrix(np.array([P_0_0]), tc='d')
        # print("P_0_0: {}".format(P_0_0))
        
        # x = [u'(k)]
        # q = [r_S*(y_u+y_L)*C*B(k+1)]
        y_L = self.Y_constraint[index][0]
        y_U = self.Y_constraint[index][1]
        q_0_0 = r_S_i * (y_U + y_L) * C_i * B_k_posterior_i

        q = matrix(np.array([q_0_0]), tc='d')
        # print("q_0_0: {}".format(q_0_0))
        
        # inequality matrix
        if abs(safety_AS_min) > 0 and abs(safety_AS_max) > 0:
            # Tips: elements of h to be close to 1.0
            # x = [u'(k)]
            # G = [-1.0/safety_AS_min; 1.0/safety_AS_max], h = [1.0; 1.0]
            G = matrix(np.array([[-1.0/safety_AS_min], [1.0/safety_AS_max]]), tc='d')
            h = matrix(np.array([[1.0], [1.0]]), tc='d')
        else:
            # x = [u'(k)]
            # G = [-1.0; 1.0], h = [safety_AS_min; safety_AS_max]
            G = matrix(np.array([[-1.0], [1.0]]), tc='d')
            h = matrix(np.array([[safety_AS_min], [safety_AS_max]]), tc='d')

        try:
            # cvxopt solver
            # minimize (1/2)*x*P*x + q*x
            # subject to: G*x < h
            sol = solvers.qp(P, q, G, h)
            
        except:            
            # discrete control parameter
            opt_AS_i = 0
            if self.logging:
                print("opt_AS_i: {}\n".format(opt_AS_i))
        
        else:
            # extract optimal value and solution
            status = sol['status']
            opt_AS_i = sol['x'][0]
            costFunction = sol['primal objective']
            if self.logging:
                print("status({}): {}".format(index, status))
                print("opt_AS_i({}): {}".format(index, opt_AS_i))
                print("costFunction({}): {}\n".format(index, costFunction))
        
            # discrete control parameter
            if status == "optimal":
                opt_AS_i = min(max(int(np.floor(opt_AS_i)), int(safety_AS_min)), int(safety_AS_max))
            else:
                opt_AS_i = 0
                
            if self.logging:
                print("opt_AS_i: {}\n".format(opt_AS_i))
            
        # handling opt_AS = 0 with active_flag = 1
        if self.active_flag[index] > 0 and opt_AS_i == 0:
            # reset auxiliary signal trigger
            self.active_flag[index] = 0

            # reset B_k_prior and P_k_prior
            self.B_k_prior[index][index] = self.B_k_posterior[index][index]
            self.P_k_prior[index][index] = self.P_k_posterior[index][index]

            # reset B_k_predict and P_k_predict
            self.B_k_predict[index][index] = self.B_k_posterior[index][index]
            self.P_k_predict[index][index] = self.P_k_posterior[index][index]      
            
        return opt_AS_i

    def calculate_random_AS(self, index):
        # safety auxiliary signal
        safety_AS_min_i = self.safety_AS[index][0]
        safety_AS_max_i = self.safety_AS[index][1]

        # random select auxiliary signal
        random_AS_i = random.uniform(safety_AS_min_i, safety_AS_max_i)

        # discrete control parameter
        random_AS_i = round(random_AS_i)
        
        # handling random_AS_i = 0 with active_flag = 1
        if self.active_flag[index] > 0 and random_AS_i == 0:
            # reset auxiliary signal trigger
            self.active_flag[index] = 0

            # reset B_k_prior and P_k_prior
            self.B_k_prior[index][index] = self.B_k_posterior[index][index]
            self.P_k_prior[index][index] = self.P_k_posterior[index][index]

            # reset B_k_predict and P_k_predict
            self.B_k_predict[index][index] = self.B_k_posterior[index][index]
            self.P_k_predict[index][index] = self.P_k_posterior[index][index]      
            
        return random_AS_i

    def set_timing_interval(self, timing_interval):
        self.timing_interval = timing_interval

    def set_rnd_seed(self, rnd_seed):
        self.rnd_seed = rnd_seed
        random.seed(self.rnd_seed)

    def get_B_k_prior(self):
        return self.B_k_prior

    def get_P_k_prior(self):
        return self.P_k_prior

    def get_B_k_posterior(self):
        return self.B_k_posterior

    def get_P_k_posterior(self):
        return self.P_k_posterior

    def get_B_k_predict(self):
        return self.B_k_predict

    def get_P_k_predict(self):
        return self.P_k_predict

    def get_prior_active_flag(self):
        return self.prior_active_flag

    def get_predict_active_flag(self):
        return self.prior_active_flag

    def get_active_flag(self):
        return self.active_flag

    def get_opt_AS(self):
        return self.opt_AS
    
    def transferToString(self, B_k_prior, P_k_prior, B_k_posterior, P_k_posterior, 
                         B_k_predict, P_k_predict, alarm, active_flag, opt_AS):
        B_k_prior_str = ""
        for index in range(0, 6):
            B_k_prior_str = B_k_prior_str + str(B_k_prior[index][index]) + ","
        B_k_prior_str = B_k_prior_str + str(B_k_prior[5][5])   
        
        P_k_prior_str = ""
        for index in range(0, 6):
            P_k_prior_str = P_k_prior_str + str(P_k_prior[index][index]) + ","
        P_k_prior_str = P_k_prior_str + str(P_k_prior[5][5])   
        
        B_k_posterior_str = ""
        for index in range(0, 6):
            B_k_posterior_str = B_k_posterior_str + str(B_k_posterior[index][index]) + ","
        B_k_posterior_str = B_k_posterior_str + str(B_k_posterior[5][5])  

        P_k_posterior_str = ""
        for index in range(0, 6):
            P_k_posterior_str = P_k_posterior_str + str(P_k_posterior[index][index]) + ","
        P_k_posterior_str = P_k_posterior_str + str(P_k_posterior[5][5])    
        
        B_k_predict_str = ""
        for index in range(0, 6):
            B_k_predict_str = B_k_predict_str + str(B_k_predict[index][index]) + ","
        B_k_predict_str = B_k_predict_str + str(B_k_predict[5][5])     
        
        P_k_predict_str = ""
        for index in range(0, 6):
            P_k_predict_str = P_k_predict_str + str(P_k_predict[index][index]) + ","
        P_k_predict_str = P_k_predict_str + str(P_k_predict[5][5])     
        
        alarm_str = ""
        for index in range(0, 6):
            alarm_str = alarm_str + str(int(alarm[index])) + ","
        alarm_str = alarm_str + str(int(alarm[5]))        
 
        active_flag_str = ""
        for index in range(0, 6):
            active_flag_str = active_flag_str + str(int(active_flag[index])) + ","
        active_flag_str = active_flag_str + str(int(active_flag[5]))            
      
        opt_AS_str = ""
        for index in range(0, 6):
            opt_AS_str = opt_AS_str + str(int(opt_AS[index])) + ","
        opt_AS_str = opt_AS_str + str(int(opt_AS[5]))            
               
        return B_k_prior_str, P_k_prior_str, B_k_posterior_str, P_k_posterior_str, \
               B_k_predict_str, P_k_predict_str, alarm_str, active_flag_str, opt_AS_str 


if __name__ == "__main__":
    print("AMM...")
    # "combine_trigger"/"prior_trigger"/"posterior_trigger"/"timing_trigger"
    # "optimal_design"/"random_design"
    detector = AMM(False, "combine_trigger", "optimal_design")

    n = 200
    freq = 5
    for k in range(0, n):
        U_str = str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq) + "," + str(freq)
        Y_str = "0.991508,0.996441,0.992127,0.978251,0.996470,0.921172"
        print("k={}, U_str={}, Y_str={}".format(k, U_str, Y_str))

        B_k_prior_str, P_k_prior_str, B_k_posterior_str, P_k_posterior_str, \
        B_k_predict_str, P_k_predict_str, \
        alarm_str, active_flag_str, opt_AS_str = detector.deviation_detector(U_str, Y_str)

        print("B_k_prior_str={}".format(B_k_prior_str))
        print("P_k_prior_str={}".format(P_k_prior_str))
        print("B_k_posterior_str={}".format(B_k_posterior_str))
        print("P_k_posterior_str={}".format(P_k_posterior_str))
        print("B_k_predict_str={}".format(B_k_predict_str))
        print("P_k_predict_str={}".format(P_k_predict_str))
        print("alarm_str={}".format(alarm_str))
        print("active_flag_str={}".format(active_flag_str))
        print("opt_AS_str={}\n".format(opt_AS_str))